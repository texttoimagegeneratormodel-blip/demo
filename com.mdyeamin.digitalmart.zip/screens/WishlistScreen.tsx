
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useApp } from '../context/AppContext';

const WishlistScreen: React.FC = () => {
  const navigate = useNavigate();
  const { templates, wishlist, toggleWishlist, cart, addToCart } = useApp();

  const wishlistItems = templates.filter(t => wishlist.includes(t.id));

  const handleAddToCart = (e: React.MouseEvent, template: any) => {
    e.stopPropagation();
    addToCart(template);
  };

  return (
    <div className="flex flex-col min-h-screen bg-background-light dark:bg-background-dark font-display pb-24">
      {/* Header */}
      <div className="flex items-center bg-background-light/95 dark:bg-background-dark/95 backdrop-blur-sm p-4 sticky top-0 z-10 border-b border-slate-200 dark:border-slate-800">
        <h1 className="text-xl font-bold text-slate-900 dark:text-white flex-1">My Wishlist</h1>
        <div className="flex items-center gap-2">
           <span className="text-sm font-medium text-slate-500 dark:text-slate-400">
             {wishlistItems.length} {wishlistItems.length === 1 ? 'Item' : 'Items'}
           </span>
        </div>
      </div>

      {/* Content */}
      <div className="p-4">
        {wishlistItems.length === 0 ? (
          <div className="flex flex-col items-center justify-center pt-20 text-slate-500 dark:text-slate-400">
            <div className="size-20 bg-slate-100 dark:bg-slate-800 rounded-full flex items-center justify-center mb-4">
               <span className="material-symbols-outlined text-4xl opacity-50">favorite</span>
            </div>
            <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-1">Your wishlist is empty</h3>
            <p className="text-sm text-center max-w-xs mb-6">Save items you want to buy later by tapping the heart icon.</p>
            <button 
              onClick={() => navigate('/home')}
              className="px-6 py-3 bg-primary text-white rounded-xl font-bold shadow-lg shadow-primary/20 hover:bg-primary/90 transition-transform active:scale-95"
            >
              Explore Templates
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-4">
            {wishlistItems.map((item) => (
              <div 
                key={item.id} 
                onClick={() => navigate(`/details/${item.id}`)}
                className="flex gap-4 p-3 bg-white dark:bg-slate-800/50 rounded-2xl shadow-sm border border-slate-200 dark:border-slate-700 cursor-pointer group transition-transform active:scale-[0.99]"
              >
                <div 
                  className="size-28 rounded-xl bg-cover bg-center shrink-0"
                  style={{ backgroundImage: `url("${item.thumbnail}")` }}
                ></div>
                
                <div className="flex flex-col flex-1 min-w-0">
                  <div className="flex justify-between items-start">
                    <h3 className="font-bold text-slate-900 dark:text-white truncate pr-2 text-base">{item.title}</h3>
                    <button 
                      onClick={(e) => {
                        e.stopPropagation();
                        toggleWishlist(item.id);
                      }}
                      className="text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 p-1.5 rounded-full -mr-2 -mt-2 transition-colors"
                    >
                      <span className="material-symbols-outlined filled text-[20px]">favorite</span>
                    </button>
                  </div>
                  
                  <p className="text-xs text-slate-500 dark:text-slate-400 mb-auto mt-1">by {item.creator.name}</p>
                  
                  <div className="flex items-center justify-between mt-3">
                    <p className="font-bold text-slate-900 dark:text-white text-lg">${item.price.toFixed(2)}</p>
                    
                    <button 
                      onClick={(e) => handleAddToCart(e, item)}
                      className="flex items-center gap-1.5 bg-slate-900 dark:bg-white text-white dark:text-slate-900 px-3 py-1.5 rounded-lg text-sm font-bold shadow-md active:scale-90 transition-transform"
                    >
                      <span className="material-symbols-outlined text-[18px]">shopping_cart</span>
                      Add
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default WishlistScreen;
