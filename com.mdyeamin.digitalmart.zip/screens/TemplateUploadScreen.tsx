
import React, { useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { useApp } from '../context/AppContext';

const TemplateUploadScreen: React.FC = () => {
  const navigate = useNavigate();
  const { showToast } = useApp();
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState('Websites');
  const [price, setPrice] = useState('');
  const [tags, setTags] = useState<string[]>(['minimal', 'business']);
  const [tagInput, setTagInput] = useState('');
  
  // New state for images
  const [previewImages, setPreviewImages] = useState<string[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // New state for Template File
  const [templateFile, setTemplateFile] = useState<File | null>(null);
  const templateFileInputRef = useRef<HTMLInputElement>(null);

  // New state for Video Preview
  const [previewVideo, setPreviewVideo] = useState<File | null>(null);
  const [previewVideoUrl, setPreviewVideoUrl] = useState<string | null>(null);
  const videoInputRef = useRef<HTMLInputElement>(null);

  const handleAddTag = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && tagInput.trim()) {
      e.preventDefault();
      setTags([...tags, tagInput.trim()]);
      setTagInput('');
    }
  };

  const removeTag = (tagToRemove: string) => {
    setTags(tags.filter(tag => tag !== tagToRemove));
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const newImages = Array.from(e.target.files).map(file => URL.createObjectURL(file as Blob));
      setPreviewImages(prev => [...prev, ...newImages]);
    }
  };

  const removeImage = (index: number) => {
    setPreviewImages(prev => prev.filter((_, i) => i !== index));
  };

  const triggerImageUpload = () => {
    fileInputRef.current?.click();
  };

  // Template File Handlers
  const handleTemplateFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setTemplateFile(e.target.files[0]);
    }
  };

  const triggerTemplateUpload = () => {
    templateFileInputRef.current?.click();
  };

  const removeTemplateFile = (e: React.MouseEvent) => {
    e.stopPropagation();
    setTemplateFile(null);
    if (templateFileInputRef.current) {
      templateFileInputRef.current.value = '';
    }
  };

  // Video Upload Handlers
  const handleVideoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const file = e.target.files[0];
      if (file.type.startsWith('video/')) {
        setPreviewVideo(file);
        setPreviewVideoUrl(URL.createObjectURL(file));
      } else {
        showToast('Please upload a valid video file.', 'error');
      }
    }
  };

  const triggerVideoUpload = () => {
    videoInputRef.current?.click();
  };

  const removeVideo = () => {
    setPreviewVideo(null);
    if (previewVideoUrl) {
      URL.revokeObjectURL(previewVideoUrl);
      setPreviewVideoUrl(null);
    }
    if (videoInputRef.current) {
      videoInputRef.current.value = '';
    }
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const handleSubmit = () => {
    // Validation
    if (!title || !price) {
      showToast('Please fill in at least the Title and Price.', 'error');
      return;
    }
    if (!templateFile) {
        showToast('Please upload the template file.', 'error');
        return;
    }
    if (previewImages.length === 0) {
      showToast('Please upload at least one preview image.', 'info');
      return;
    }
    
    // In a real app, you would post data to backend here
    showToast('Template submitted successfully!');
    navigate('/dashboard');
  };

  return (
    <div className="flex flex-col min-h-screen bg-background-light dark:bg-background-dark font-display pb-28">
      {/* Top App Bar */}
      <div className="flex items-center p-4 pb-2 justify-between bg-background-light/95 dark:bg-background-dark/95 backdrop-blur-sm sticky top-0 z-10 border-b border-transparent dark:border-slate-800 transition-colors">
        <button onClick={() => navigate('/dashboard')} className="flex size-12 shrink-0 items-center justify-start text-zinc-900 dark:text-white hover:text-primary transition-colors cursor-pointer">
          <span className="material-symbols-outlined !text-2xl">arrow_back_ios_new</span>
        </button>
        <h2 className="text-zinc-900 dark:text-white text-lg font-bold leading-tight tracking-[-0.015em] flex-1 text-center">Upload Template</h2>
        <div className="flex w-12 items-center justify-end">
          <button onClick={() => navigate('/dashboard')} className="text-primary text-base font-bold leading-normal tracking-[0.015em] shrink-0 hover:text-primary/80">Cancel</button>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 px-4">
        {/* Title Field */}
        <div className="flex flex-col py-3">
          <label className="flex flex-col w-full">
            <p className="text-zinc-900 dark:text-white text-base font-medium leading-normal pb-2">Title</p>
            <input 
              className="w-full rounded-xl bg-zinc-100 dark:bg-zinc-800 border-none p-4 text-base text-zinc-900 dark:text-white placeholder:text-zinc-400 focus:ring-2 focus:ring-primary/50 transition-shadow" 
              placeholder="Enter template title" 
              value={title}
              onChange={(e) => setTitle(e.target.value)}
            />
          </label>
        </div>

        {/* Description Field */}
        <div className="flex flex-col py-3">
          <label className="flex flex-col w-full">
            <p className="text-zinc-900 dark:text-white text-base font-medium leading-normal pb-2">Description</p>
            <textarea 
              className="w-full rounded-xl bg-zinc-100 dark:bg-zinc-800 border-none p-4 text-base text-zinc-900 dark:text-white placeholder:text-zinc-400 focus:ring-2 focus:ring-primary/50 min-h-[140px] resize-none transition-shadow" 
              placeholder="Describe your template in detail..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
            ></textarea>
          </label>
        </div>

        {/* List Items for Category & Price */}
        <div className="space-y-3 py-3">
          {/* Category Selector */}
          <div className="flex items-center justify-between gap-4 rounded-xl bg-zinc-100 dark:bg-zinc-800 p-4">
            <div className="flex items-center gap-4">
              <div className="flex size-10 shrink-0 items-center justify-center rounded-lg bg-primary/20 text-primary">
                <span className="material-symbols-outlined">category</span>
              </div>
              <p className="text-zinc-900 dark:text-white text-base font-normal leading-normal flex-1 truncate">Category</p>
            </div>
            <div className="flex items-center gap-2 relative">
              <select 
                value={category} 
                onChange={(e) => setCategory(e.target.value)}
                className="appearance-none bg-transparent border-none text-zinc-500 dark:text-zinc-400 text-base font-normal text-right pr-6 focus:ring-0 cursor-pointer"
              >
                <option>Websites</option>
                <option>Presentations</option>
                <option>Logos</option>
                <option>Social</option>
                <option>Resumes</option>
              </select>
               <span className="material-symbols-outlined absolute right-0 text-zinc-400 pointer-events-none text-sm">expand_more</span>
            </div>
          </div>

          {/* Price Input */}
          <div className="flex items-center justify-between gap-4 rounded-xl bg-zinc-100 dark:bg-zinc-800 p-4">
            <div className="flex items-center gap-4">
              <div className="flex size-10 shrink-0 items-center justify-center rounded-lg bg-primary/20 text-primary">
                <span className="material-symbols-outlined">monetization_on</span>
              </div>
              <p className="text-zinc-900 dark:text-white text-base font-normal leading-normal flex-1 truncate">Price</p>
            </div>
            <div className="flex items-center gap-1">
              <span className="text-zinc-500 dark:text-zinc-400 text-base font-normal">$</span>
              <input 
                className="w-24 bg-transparent border-none p-0 text-right text-base font-normal text-zinc-900 dark:text-white placeholder:text-zinc-500 focus:ring-0" 
                placeholder="0.00" 
                type="number"
                value={price}
                onChange={(e) => setPrice(e.target.value)}
              />
            </div>
          </div>
        </div>

        {/* Tags Input */}
        <div className="py-3">
          <label className="flex flex-col">
            <p className="text-zinc-900 dark:text-white text-base font-medium leading-normal pb-2">Tags</p>
            <div className="flex min-h-[56px] w-full flex-wrap items-center gap-2 rounded-xl bg-zinc-100 dark:bg-zinc-800 p-3 text-base text-zinc-900 dark:text-white focus-within:ring-2 focus-within:ring-primary/50 transition-shadow">
              {tags.map(tag => (
                <span key={tag} className="flex items-center gap-1 rounded-full bg-primary/20 px-3 py-1 text-sm text-primary font-medium">
                  {tag} 
                  <button onClick={() => removeTag(tag)} className="flex items-center justify-center rounded-full hover:bg-primary/20 p-0.5 transition-colors">
                      <span className="material-symbols-outlined !text-[16px]">close</span>
                  </button>
                </span>
              ))}
              <input 
                className="flex-1 bg-transparent border-none p-0 text-zinc-900 dark:text-white placeholder:text-zinc-400 focus:ring-0 min-w-[100px]" 
                placeholder={tags.length === 0 ? "Add tags..." : ""}
                value={tagInput}
                onChange={(e) => setTagInput(e.target.value)}
                onKeyDown={handleAddTag}
              />
            </div>
          </label>
        </div>

        {/* File Upload Section */}
        <div className="space-y-4 py-3">
          {/* Template File Upload */}
          <div>
            <p className="text-zinc-900 dark:text-white text-base font-medium leading-normal pb-2">Template File</p>
            
            <input 
              type="file" 
              className="hidden" 
              ref={templateFileInputRef} 
              onChange={handleTemplateFileChange} 
              // Accept common template formats
              accept=".zip,.rar,.pdf,.sketch,.fig,.xd,.ai,.psd" 
            />

            {!templateFile ? (
              <div 
                onClick={triggerTemplateUpload}
                className="flex flex-col items-center justify-center gap-2 rounded-xl border-2 border-dashed border-zinc-300 dark:border-zinc-700 p-8 text-center bg-zinc-50 dark:bg-zinc-800/30 hover:bg-zinc-100 dark:hover:bg-zinc-800/50 transition-colors cursor-pointer group"
              >
                <div className="flex size-12 items-center justify-center rounded-full bg-primary/10 text-primary group-hover:scale-110 transition-transform">
                  <span className="material-symbols-outlined !text-3xl">upload_file</span>
                </div>
                <div>
                  <p className="font-semibold text-zinc-900 dark:text-white">Tap to upload your template file</p>
                  <p className="text-sm text-zinc-500 dark:text-zinc-400 mt-1">Supports ZIP, PDF, FIG, SKETCH (Max 500MB)</p>
                </div>
              </div>
            ) : (
              <div 
                className="flex items-center justify-between gap-4 rounded-xl border border-zinc-200 dark:border-zinc-700 p-4 bg-white dark:bg-zinc-800 animate-fade-in cursor-pointer hover:bg-zinc-50 dark:hover:bg-zinc-700/50 transition-colors"
                onClick={triggerTemplateUpload}
              >
                <div className="flex items-center gap-4 overflow-hidden">
                   <div className="flex size-12 shrink-0 items-center justify-center rounded-lg bg-green-100 text-green-600 dark:bg-green-500/20 dark:text-green-400">
                     <span className="material-symbols-outlined !text-2xl">description</span>
                   </div>
                   <div className="flex flex-col min-w-0">
                     <p className="font-semibold text-zinc-900 dark:text-white truncate">{templateFile.name}</p>
                     <p className="text-sm text-zinc-500 dark:text-zinc-400">{formatFileSize(templateFile.size)}</p>
                   </div>
                </div>
                <button 
                  onClick={removeTemplateFile}
                  className="size-8 flex items-center justify-center rounded-full hover:bg-red-50 dark:hover:bg-red-900/20 text-zinc-400 hover:text-red-500 transition-colors shrink-0"
                >
                  <span className="material-symbols-outlined">close</span>
                </button>
              </div>
            )}
          </div>

          {/* Preview Images Upload */}
          <div>
            <div className="flex justify-between items-center pb-2">
              <p className="text-zinc-900 dark:text-white text-base font-medium leading-normal">Preview Images</p>
              {previewImages.length > 0 && (
                <span className="text-xs text-zinc-500 dark:text-zinc-400">{previewImages.length} images selected</span>
              )}
            </div>
            
            {/* Image Grid */}
            {previewImages.length > 0 && (
              <div className="grid grid-cols-3 gap-3 mb-3 animate-fade-in">
                {previewImages.map((img, idx) => (
                  <div key={idx} className="relative aspect-square rounded-xl overflow-hidden group border border-zinc-200 dark:border-zinc-700">
                    <img src={img} alt={`Preview ${idx}`} className="w-full h-full object-cover" />
                    <button 
                      onClick={() => removeImage(idx)}
                      className="absolute top-1 right-1 size-6 bg-black/50 text-white rounded-full flex items-center justify-center backdrop-blur-sm hover:bg-red-500 transition-colors"
                    >
                      <span className="material-symbols-outlined text-sm">close</span>
                    </button>
                  </div>
                ))}
              </div>
            )}

            {/* Upload Area */}
            <div 
              onClick={triggerImageUpload}
              className="flex flex-col items-center justify-center gap-2 rounded-xl border-2 border-dashed border-zinc-300 dark:border-zinc-700 p-8 text-center bg-zinc-50 dark:bg-zinc-800/30 hover:bg-zinc-100 dark:hover:bg-zinc-800/50 transition-colors cursor-pointer group"
            >
              <input 
                type="file" 
                multiple 
                accept="image/*" 
                className="hidden" 
                ref={fileInputRef} 
                onChange={handleImageUpload} 
              />
              <div className="flex size-12 items-center justify-center rounded-full bg-primary/10 text-primary group-hover:scale-110 transition-transform">
                <span className="material-symbols-outlined !text-3xl">add_photo_alternate</span>
              </div>
              <div>
                 <p className="font-semibold text-zinc-900 dark:text-white">Tap to upload images</p>
                 <p className="text-sm text-zinc-500 dark:text-zinc-400 mt-1">Supports JPG, PNG (Max 5MB)</p>
              </div>
            </div>
          </div>

          {/* Video Preview Upload (New Section) */}
          <div>
            <p className="text-zinc-900 dark:text-white text-base font-medium leading-normal pb-2">Video Preview (Optional)</p>
            
            {!previewVideo ? (
              <div 
                onClick={triggerVideoUpload}
                className="flex flex-col items-center justify-center gap-2 rounded-xl border-2 border-dashed border-zinc-300 dark:border-zinc-700 p-8 text-center bg-zinc-50 dark:bg-zinc-800/30 hover:bg-zinc-100 dark:hover:bg-zinc-800/50 transition-colors cursor-pointer group"
              >
                <input 
                  type="file" 
                  accept="video/*" 
                  className="hidden" 
                  ref={videoInputRef} 
                  onChange={handleVideoUpload} 
                />
                <div className="flex size-12 items-center justify-center rounded-full bg-primary/10 text-primary group-hover:scale-110 transition-transform">
                  <span className="material-symbols-outlined !text-3xl">movie</span>
                </div>
                <div>
                   <p className="font-semibold text-zinc-900 dark:text-white">Tap to upload video preview</p>
                   <p className="text-sm text-zinc-500 dark:text-zinc-400 mt-1">Supports MP4, MOV (Max 50MB)</p>
                </div>
              </div>
            ) : (
              <div className="relative rounded-xl overflow-hidden bg-black aspect-video animate-fade-in border border-zinc-200 dark:border-zinc-700 group">
                <video 
                  src={previewVideoUrl || undefined} 
                  controls 
                  className="w-full h-full object-contain"
                />
                <button 
                  onClick={removeVideo}
                  className="absolute top-2 right-2 size-8 bg-black/60 text-white rounded-full flex items-center justify-center backdrop-blur-md hover:bg-red-500 transition-colors"
                >
                  <span className="material-symbols-outlined">close</span>
                </button>
                <div className="absolute bottom-2 left-2 px-2 py-1 bg-black/60 rounded text-xs text-white backdrop-blur-md pointer-events-none">
                  {previewVideo.name}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Live Preview Section */}
        <div className="pt-4 pb-4">
           <div className="h-px bg-zinc-200 dark:bg-zinc-800 mb-6"></div>
           <h3 className="text-zinc-900 dark:text-white text-base font-bold leading-normal pb-4">Live Preview</h3>
           
           <div className="flex justify-center">
             <div className="w-48 group cursor-default">
                <div className="relative w-full aspect-[3/4] rounded-2xl overflow-hidden mb-3 shadow-sm bg-slate-100 dark:bg-slate-800 border border-zinc-200 dark:border-zinc-700">
                  {previewImages.length > 0 ? (
                     <div 
                        className="absolute inset-0 bg-cover bg-center"
                        style={{ backgroundImage: `url("${previewImages[0]}")` }}
                     ></div>
                  ) : (
                     <div className="absolute inset-0 flex items-center justify-center text-zinc-400">
                        <span className="material-symbols-outlined text-4xl">image</span>
                     </div>
                  )}
                  <div className="absolute top-2 right-2 size-8 bg-black/20 text-white rounded-full flex items-center justify-center backdrop-blur-md">
                    <span className="material-symbols-outlined text-[18px]">favorite</span>
                  </div>
                </div>
                
                <h3 className="text-slate-900 dark:text-white font-bold text-sm truncate">
                  {title || 'Template Title'}
                </h3>
                
                <div className="flex items-center gap-1 mt-0.5">
                   <span className="material-symbols-outlined text-yellow-400 text-[14px] filled">star</span>
                   <span className="text-xs font-medium text-slate-700 dark:text-slate-300">New</span>
                </div>

                <div className="flex justify-between items-center mt-1">
                  <p className="text-slate-500 dark:text-slate-400 text-xs truncate max-w-[80px]">
                    {category}
                  </p>
                  <span className="text-primary font-bold text-sm">
                    ${price ? parseFloat(price).toFixed(2) : '0.00'}
                  </span>
                </div>
             </div>
           </div>
           
           <p className="text-center text-xs text-zinc-500 dark:text-zinc-400 mt-4">
             This is how your template will appear in the marketplace.
           </p>
        </div>

      </div>

      {/* Floating Action Button */}
      <div className="fixed bottom-0 left-0 right-0 p-4 bg-background-light/90 dark:bg-background-dark/90 backdrop-blur-lg border-t border-slate-200 dark:border-slate-800 z-20 max-w-lg mx-auto">
        <button 
          onClick={handleSubmit}
          className="w-full rounded-xl bg-primary py-4 text-center text-base font-bold text-white shadow-lg shadow-primary/25 hover:bg-primary/90 transition-transform active:scale-[0.98]"
        >
          Submit Template
        </button>
      </div>
    </div>
  );
};

export default TemplateUploadScreen;
