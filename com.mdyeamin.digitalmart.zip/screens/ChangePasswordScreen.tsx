
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const ChangePasswordScreen: React.FC = () => {
  const navigate = useNavigate();
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  
  const [showCurrent, setShowCurrent] = useState(false);
  const [showNew, setShowNew] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);

  const handleSubmit = () => {
    if (!currentPassword || !newPassword || !confirmPassword) {
      alert("Please fill in all fields.");
      return;
    }
    if (newPassword !== confirmPassword) {
      alert("New passwords do not match.");
      return;
    }
    // Mock success
    alert("Password changed successfully.");
    navigate('/account-security');
  };

  return (
    <div className="relative flex h-auto min-h-screen w-full flex-col bg-background-light dark:bg-background-dark font-display overflow-x-hidden">
      <div className="flex-1">
        {/* TopAppBar */}
        <div className="flex items-center bg-background-light dark:bg-background-dark p-4 pb-2 justify-between sticky top-0 z-10">
          <button 
            onClick={() => navigate('/account-security')}
            className="text-slate-800 dark:text-white flex size-12 shrink-0 items-center justify-start hover:text-primary transition-colors cursor-pointer"
          >
            <span className="material-symbols-outlined text-2xl">arrow_back_ios_new</span>
          </button>
          <h2 className="text-slate-900 dark:text-white text-lg font-bold leading-tight tracking-[-0.015em] flex-1 text-center pr-12">Change Password</h2>
        </div>

        <div className="flex flex-col gap-4 p-4">
          {/* Current Password TextField */}
          <div className="flex max-w-full flex-wrap items-end gap-4 py-2">
            <label className="flex flex-col min-w-40 flex-1">
              <p className="text-slate-800 dark:text-white text-base font-medium leading-normal pb-2">Current Password</p>
              <div className="flex w-full flex-1 items-stretch rounded-xl relative group">
                <input 
                  className="form-input flex w-full min-w-0 flex-1 resize-none overflow-hidden rounded-xl text-slate-900 dark:text-white focus:outline-0 focus:ring-2 focus:ring-primary/50 border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800/50 focus:border-primary h-14 placeholder:text-slate-400 dark:placeholder:text-slate-500 p-[15px] pr-12 text-base font-normal leading-normal transition-shadow" 
                  placeholder="Enter your current password" 
                  type={showCurrent ? "text" : "password"}
                  value={currentPassword}
                  onChange={(e) => setCurrentPassword(e.target.value)}
                />
                <button 
                  onClick={() => setShowCurrent(!showCurrent)}
                  className="absolute right-0 top-0 bottom-0 text-slate-400 dark:text-slate-500 flex items-center justify-center px-4 rounded-r-xl hover:text-slate-600 dark:hover:text-slate-300 transition-colors"
                >
                  <span className="material-symbols-outlined text-2xl">
                    {showCurrent ? 'visibility' : 'visibility_off'}
                  </span>
                </button>
              </div>
            </label>
          </div>

          {/* MetaText (Forgot Password) */}
          <button onClick={() => alert("Forgot password flow triggered")} className="text-primary text-sm font-medium leading-normal pb-3 pt-1 px-0 underline cursor-pointer text-left w-fit">
            Forgot your current password?
          </button>

          {/* New Password TextField */}
          <div className="flex max-w-full flex-wrap items-end gap-4 py-2">
            <label className="flex flex-col min-w-40 flex-1">
              <p className="text-slate-800 dark:text-white text-base font-medium leading-normal pb-2">New Password</p>
              <div className="flex w-full flex-1 items-stretch rounded-xl relative">
                <input 
                  className="form-input flex w-full min-w-0 flex-1 resize-none overflow-hidden rounded-xl text-slate-900 dark:text-white focus:outline-0 focus:ring-2 focus:ring-primary/50 border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800/50 focus:border-primary h-14 placeholder:text-slate-400 dark:placeholder:text-slate-500 p-[15px] pr-12 text-base font-normal leading-normal transition-shadow" 
                  placeholder="Enter your new password" 
                  type={showNew ? "text" : "password"} 
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                />
                <button 
                  onClick={() => setShowNew(!showNew)}
                  className="absolute right-0 top-0 bottom-0 text-slate-400 dark:text-slate-500 flex items-center justify-center px-4 rounded-r-xl hover:text-slate-600 dark:hover:text-slate-300 transition-colors"
                >
                  <span className="material-symbols-outlined text-2xl">
                    {showNew ? 'visibility' : 'visibility_off'}
                  </span>
                </button>
              </div>
            </label>
          </div>

          {/* BodyText (Password Requirements) */}
          <p className="text-slate-600 dark:text-slate-400 text-sm font-normal leading-normal pb-3 pt-1 px-0">
            Must be at least 8 characters, include a number, and a special character.
          </p>

          {/* Confirm New Password TextField */}
          <div className="flex max-w-full flex-wrap items-end gap-4 py-2">
            <label className="flex flex-col min-w-40 flex-1">
              <p className="text-slate-800 dark:text-white text-base font-medium leading-normal pb-2">Confirm New Password</p>
              <div className="flex w-full flex-1 items-stretch rounded-xl relative">
                <input 
                  className="form-input flex w-full min-w-0 flex-1 resize-none overflow-hidden rounded-xl text-slate-900 dark:text-white focus:outline-0 focus:ring-2 focus:ring-primary/50 border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800/50 focus:border-primary h-14 placeholder:text-slate-400 dark:placeholder:text-slate-500 p-[15px] pr-12 text-base font-normal leading-normal transition-shadow" 
                  placeholder="Confirm your new password" 
                  type={showConfirm ? "text" : "password"} 
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                />
                <button 
                  onClick={() => setShowConfirm(!showConfirm)}
                  className="absolute right-0 top-0 bottom-0 text-slate-400 dark:text-slate-500 flex items-center justify-center px-4 rounded-r-xl hover:text-slate-600 dark:hover:text-slate-300 transition-colors"
                >
                  <span className="material-symbols-outlined text-2xl">
                    {showConfirm ? 'visibility' : 'visibility_off'}
                  </span>
                </button>
              </div>
            </label>
          </div>
        </div>
      </div>

      {/* CTA Button */}
      <div className="p-4 pb-8 sticky bottom-0 bg-background-light dark:bg-background-dark border-t border-transparent dark:border-slate-800/50">
        <button 
          onClick={handleSubmit}
          className="flex w-full items-center justify-center rounded-xl bg-primary h-14 shadow-lg shadow-primary/25 hover:bg-primary/90 transition-all active:scale-[0.98]"
        >
          <span className="text-white text-base font-bold leading-normal">Change Password</span>
        </button>
      </div>
    </div>
  );
};

export default ChangePasswordScreen;
