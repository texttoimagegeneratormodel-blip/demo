
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useApp } from '../context/AppContext';

const UserProfileScreen: React.FC = () => {
  const navigate = useNavigate();
  const { user, logout } = useApp();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  if (!user) {
      return (
          <div className="flex flex-col items-center justify-center min-h-screen p-4 text-center">
              <p className="mb-4">You are not logged in.</p>
              <button onClick={() => navigate('/login')} className="text-primary font-bold">Log In</button>
          </div>
      )
  }

  const menuItems = [
    { icon: 'dashboard', label: 'My Dashboard', path: '/dashboard', color: 'bg-blue-500' },
    { icon: 'shopping_bag', label: 'My Purchases', path: '/dashboard', color: 'bg-purple-500' }, // Redirect to dashboard for now or new screen
    { icon: 'favorite', label: 'Wishlist', path: '/wishlist', color: 'bg-red-500' },
    { icon: 'settings', label: 'Settings', path: '/settings', color: 'bg-slate-500' },
  ];

  return (
    <div className="flex flex-col min-h-screen bg-background-light dark:bg-background-dark font-display pb-24">
      {/* Header */}
      <div className="bg-background-light dark:bg-background-dark p-4 sticky top-0 z-10 border-b border-slate-200 dark:border-slate-800">
         <h1 className="text-xl font-bold text-slate-900 dark:text-white text-center">My Account</h1>
      </div>

      <div className="p-4 flex flex-col items-center">
        {/* Avatar */}
        <div className="relative mb-4 cursor-pointer" onClick={() => navigate('/profile-info')}>
            <div 
                className="size-24 rounded-full bg-cover bg-center ring-4 ring-white dark:ring-slate-800 shadow-lg"
                style={{ backgroundImage: `url("${user.avatar}")` }}
            ></div>
            <button className="absolute bottom-0 right-0 bg-primary text-white p-1.5 rounded-full shadow-md border-2 border-white dark:border-slate-800 hover:scale-110 transition-transform">
                <span className="material-symbols-outlined text-[16px]">edit</span>
            </button>
        </div>
        
        <h2 className="text-2xl font-bold text-slate-900 dark:text-white">{user.name}</h2>
        <p className="text-slate-500 dark:text-slate-400 text-sm mb-6">{user.email}</p>

        {/* Stats Card */}
        <div className="w-full grid grid-cols-3 gap-2 mb-8">
            <div className="bg-white dark:bg-slate-800 p-3 rounded-xl border border-slate-200 dark:border-slate-700 text-center shadow-sm">
                <span className="block text-xl font-bold text-slate-900 dark:text-white">12</span>
                <span className="text-xs text-slate-500 dark:text-slate-400">Orders</span>
            </div>
            <div className="bg-white dark:bg-slate-800 p-3 rounded-xl border border-slate-200 dark:border-slate-700 text-center shadow-sm">
                <span className="block text-xl font-bold text-slate-900 dark:text-white">5</span>
                <span className="text-xs text-slate-500 dark:text-slate-400">Reviews</span>
            </div>
            <div className="bg-white dark:bg-slate-800 p-3 rounded-xl border border-slate-200 dark:border-slate-700 text-center shadow-sm">
                <span className="block text-xl font-bold text-slate-900 dark:text-white">2</span>
                <span className="text-xs text-slate-500 dark:text-slate-400">Selling</span>
            </div>
        </div>

        {/* Menu */}
        <div className="w-full flex flex-col gap-3">
            {menuItems.map((item, idx) => (
                <button 
                    key={idx}
                    onClick={() => navigate(item.path)}
                    className="flex items-center gap-4 bg-white dark:bg-slate-800 p-4 rounded-xl shadow-sm border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-750 transition-colors"
                >
                    <div className={`${item.color} size-10 rounded-lg flex items-center justify-center text-white shrink-0`}>
                        <span className="material-symbols-outlined">{item.icon}</span>
                    </div>
                    <span className="flex-1 text-left font-bold text-slate-900 dark:text-white">{item.label}</span>
                    <span className="material-symbols-outlined text-slate-400">chevron_right</span>
                </button>
            ))}

            <button 
                 onClick={() => navigate('/help-support')}
                 className="flex items-center gap-4 bg-white dark:bg-slate-800 p-4 rounded-xl shadow-sm border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-750 transition-colors mt-2"
            >
                <div className="bg-green-500 size-10 rounded-lg flex items-center justify-center text-white shrink-0">
                    <span className="material-symbols-outlined">support_agent</span>
                </div>
                <span className="flex-1 text-left font-bold text-slate-900 dark:text-white">Help & Support</span>
                <span className="material-symbols-outlined text-slate-400">chevron_right</span>
            </button>
        </div>

        <button 
            onClick={handleLogout}
            className="mt-8 text-red-500 font-bold py-3 px-6 rounded-xl hover:bg-red-50 dark:hover:bg-red-900/10 transition-colors w-full"
        >
            Log Out
        </button>
      </div>
    </div>
  );
};

export default UserProfileScreen;
