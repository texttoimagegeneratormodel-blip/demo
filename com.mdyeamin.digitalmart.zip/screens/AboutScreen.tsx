
import React from 'react';
import { useNavigate } from 'react-router-dom';

const AboutScreen: React.FC = () => {
  const navigate = useNavigate();

  return (
    <div className="relative flex h-auto min-h-screen w-full flex-col bg-background-light dark:bg-background-dark font-display overflow-x-hidden">
      {/* Top App Bar */}
      <div className="flex items-center bg-background-light dark:bg-background-dark p-4 pb-2 justify-between sticky top-0 z-10">
        <button 
          onClick={() => navigate('/settings')}
          className="text-slate-800 dark:text-white flex size-12 shrink-0 items-center justify-start hover:text-primary transition-colors cursor-pointer"
        >
          <span className="material-symbols-outlined text-2xl">arrow_back_ios_new</span>
        </button>
        <h2 className="text-slate-900 dark:text-white text-lg font-bold leading-tight tracking-[-0.015em] flex-1 text-center pr-12">About</h2>
      </div>

      <div className="flex flex-col items-center justify-center p-8 flex-1">
        <div className="flex size-24 shrink-0 items-center justify-center rounded-2xl bg-primary shadow-xl shadow-primary/30 mb-6">
            <span className="material-symbols-outlined text-white text-5xl">layers</span>
        </div>
        
        <h1 className="text-2xl font-bold text-slate-900 dark:text-white mb-2">DigitalMart</h1>
        <p className="text-slate-500 dark:text-slate-400 text-sm font-medium mb-8">Version 1.0.0</p>

        <div className="w-full max-w-sm bg-slate-200/50 dark:bg-slate-800/40 rounded-xl p-6 mb-8 text-center">
            <p className="text-slate-600 dark:text-slate-300 leading-relaxed">
                DigitalMart is the premier marketplace for digital creatives. Discover, buy, and sell high-quality templates, UI kits, and design assets.
            </p>
        </div>

        <div className="flex flex-col gap-2 text-center text-sm text-slate-500 dark:text-slate-400">
            <p>© 2024 DigitalMart Inc.</p>
            <p>All rights reserved.</p>
        </div>
      </div>
    </div>
  );
};

export default AboutScreen;
