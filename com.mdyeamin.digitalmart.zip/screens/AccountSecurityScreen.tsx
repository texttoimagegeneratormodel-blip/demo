
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const AccountSecurityScreen: React.FC = () => {
  const navigate = useNavigate();
  // Default to false so user sees the setup flow when they toggle it
  const [twoFactor, setTwoFactor] = useState(false);
  const [showDisableConfirm, setShowDisableConfirm] = useState(false);

  const handleToggleTwoFactor = () => {
    if (!twoFactor) {
      // If turning on, go to setup
      navigate('/two-factor-setup');
    } else {
      // If turning off, show confirmation bottom sheet
      setShowDisableConfirm(true);
    }
  };

  const handleConfirmDisable = () => {
    setTwoFactor(false);
    setShowDisableConfirm(false);
  };

  return (
    <div className="relative flex h-auto min-h-screen w-full flex-col bg-background-light dark:bg-background-dark font-display overflow-x-hidden">
      {/* Top App Bar */}
      <div className="flex items-center bg-background-light dark:bg-background-dark p-4 pb-2 justify-between sticky top-0 z-10">
        <button
          onClick={() => navigate('/settings')}
          className="flex size-12 shrink-0 items-center justify-start text-slate-800 dark:text-white cursor-pointer hover:opacity-70 transition-opacity"
        >
          <span className="material-symbols-outlined">arrow_back_ios_new</span>
        </button>
        <h2 className="text-slate-900 dark:text-white text-lg font-bold leading-tight tracking-[-0.015em] flex-1 text-center">Account Security</h2>
        <div className="flex size-12 shrink-0 items-center"></div>
      </div>

      <div className="flex-grow p-4">
        {/* Authentication Section */}
        <div className="space-y-2">
          <div className="overflow-hidden rounded-xl bg-white dark:bg-[#1a2632] shadow-sm">
            {/* Two-Factor Authentication */}
            <div className="flex items-center gap-4 px-4 min-h-[72px] py-2 justify-between border-b border-slate-200 dark:border-slate-700/50">
              <div className="flex items-center gap-4">
                <div className="text-white flex items-center justify-center rounded-lg bg-blue-500 shrink-0 size-10">
                  <span className="material-symbols-outlined">shield</span>
                </div>
                <div className="flex flex-col justify-center">
                  <p className="text-slate-900 dark:text-white text-base font-medium leading-normal line-clamp-1">Two-Factor Authentication</p>
                </div>
              </div>
              <div className="shrink-0">
                <label className={`relative flex h-[31px] w-[51px] cursor-pointer items-center rounded-full border-none p-0.5 transition-colors ${twoFactor ? 'bg-primary justify-end' : 'bg-slate-200 dark:bg-slate-700 justify-start'}`}>
                  <div className="h-full w-[27px] rounded-full bg-white shadow-sm"></div>
                  <input
                    type="checkbox"
                    className="invisible absolute"
                    checked={twoFactor}
                    onChange={handleToggleTwoFactor}
                  />
                </label>
              </div>
            </div>
            {/* Change Password */}
            <div
              className="flex items-center gap-4 px-4 min-h-[56px] py-2 justify-between cursor-pointer hover:bg-slate-50 dark:hover:bg-white/5 transition-colors"
              onClick={() => navigate('/change-password')}
            >
              <div className="flex items-center gap-4">
                <div className="text-white flex items-center justify-center rounded-lg bg-slate-500 shrink-0 size-10">
                  <span className="material-symbols-outlined">key</span>
                </div>
                <p className="text-slate-900 dark:text-white text-base font-normal leading-normal flex-1 truncate">Change Password</p>
              </div>
              <div className="shrink-0">
                <div className="text-slate-400 dark:text-slate-500 flex size-7 items-center justify-center">
                  <span className="material-symbols-outlined">chevron_right</span>
                </div>
              </div>
            </div>
          </div>
          <p className="text-slate-500 dark:text-slate-400 text-xs font-normal leading-normal px-4">Add an extra layer of security to your account. We recommend enabling Two-Factor Authentication.</p>
        </div>

        {/* Spacer */}
        <div className="h-8"></div>

        {/* Active Sessions Section */}
        <div className="space-y-2">
          <h3 className="text-slate-900 dark:text-white text-lg font-bold leading-tight tracking-[-0.015em] px-4">Active Sessions</h3>
          <div className="overflow-hidden rounded-xl bg-white dark:bg-[#1a2632] shadow-sm">
            {/* Manage Active Sessions */}
            <div
              className="flex items-center gap-4 px-4 min-h-[72px] py-2 justify-between cursor-pointer hover:bg-slate-50 dark:hover:bg-white/5 transition-colors"
              onClick={() => navigate('/manage-sessions')}
            >
              <div className="flex items-center gap-4">
                <div className="text-white flex items-center justify-center rounded-lg bg-green-500 shrink-0 size-10">
                  <span className="material-symbols-outlined">devices</span>
                </div>
                <div className="flex flex-col justify-center">
                  <p className="text-slate-900 dark:text-white text-base font-medium leading-normal line-clamp-1">Manage Active Sessions</p>
                </div>
              </div>
              <div className="shrink-0">
                <div className="text-slate-400 dark:text-slate-500 flex size-7 items-center justify-center">
                  <span className="material-symbols-outlined">chevron_right</span>
                </div>
              </div>
            </div>
          </div>
          <p className="text-slate-500 dark:text-slate-400 text-xs font-normal leading-normal px-4">See all devices currently logged into your account and log out from sessions you don't recognize.</p>
        </div>
      </div>

      {/* Disable 2FA Confirmation Bottom Sheet */}
      {showDisableConfirm && (
        <div className="fixed inset-0 z-50 flex flex-col justify-end">
          {/* Dimmed Background */}
          <div 
            className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            onClick={() => setShowDisableConfirm(false)}
          ></div>
          
          {/* Bottom Sheet Container */}
          <div className="relative flex w-full flex-col justify-end items-stretch animate-slide-up">
            <div className="flex flex-col items-stretch bg-background-light dark:bg-[#1C1C1E] rounded-t-xl pb-6 shadow-2xl">
              {/* BottomSheetHandle */}
              <div className="flex h-5 w-full items-center justify-center pt-3 pb-2">
                <div className="h-1 w-9 rounded-full bg-slate-300 dark:bg-slate-600"></div>
              </div>
              
              {/* Warning Icon */}
              <div className="flex justify-center items-center pt-6 pb-4">
                <div className="flex items-center justify-center w-16 h-16 rounded-full bg-red-500/10 dark:bg-red-500/20">
                  <span className="material-symbols-outlined text-red-500 !text-4xl">gpp_bad</span>
                </div>
              </div>
              
              {/* HeadlineText */}
              <h1 className="text-slate-900 dark:text-white tracking-tight text-[28px] font-bold leading-tight px-6 text-center pb-2">Are you sure?</h1>
              
              {/* BodyText */}
              <p className="text-slate-600 dark:text-slate-400 text-base font-normal leading-normal pb-6 pt-1 px-6 text-center">
                Disabling Two-Factor Authentication will reduce your account's security.
              </p>
              
              {/* ButtonGroup */}
              <div className="flex justify-center">
                <div className="flex flex-1 gap-3 max-w-[480px] flex-col items-stretch px-4 py-3">
                  <button 
                    onClick={handleConfirmDisable}
                    className="flex min-w-[84px] max-w-[480px] cursor-pointer items-center justify-center overflow-hidden rounded-lg h-12 px-5 bg-red-500 text-white text-base font-bold leading-normal tracking-[0.015em] w-full hover:bg-red-600 transition-colors"
                  >
                    <span className="truncate">Disable 2FA</span>
                  </button>
                  <button 
                    onClick={() => setShowDisableConfirm(false)}
                    className="flex min-w-[84px] max-w-[480px] cursor-pointer items-center justify-center overflow-hidden rounded-lg h-12 px-5 bg-slate-200 dark:bg-[#2C2C2E] text-slate-900 dark:text-white text-base font-bold leading-normal tracking-[0.015em] w-full hover:bg-slate-300 dark:hover:bg-[#3A3A3C] transition-colors"
                  >
                    <span className="truncate">Cancel</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AccountSecurityScreen;
