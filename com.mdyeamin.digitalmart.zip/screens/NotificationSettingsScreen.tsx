
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const NotificationSettingsScreen: React.FC = () => {
  const navigate = useNavigate();
  
  // State for toggles
  const [settings, setSettings] = useState({
    pushNotifications: true,
    newMessages: true,
    messageReplies: false,
    salesNotifications: true,
    newReviews: true,
    itemComments: false,
    newFollower: false,
    appUpdates: true,
    promotionalOffers: false,
    emailNewMessages: true,
    emailSecurityUpdates: true,
    emailPromotions: false,
  });

  const toggleSetting = (key: keyof typeof settings) => {
    setSettings(prev => ({ ...prev, [key]: !prev[key] }));
  };

  return (
    <div className="relative flex h-auto min-h-screen w-full flex-col font-display bg-background-light dark:bg-background-dark">
      {/* Top App Bar */}
      <div className="flex items-center bg-background-light dark:bg-background-dark p-4 pb-2 justify-between sticky top-0 z-10 border-b border-white/10">
        <button 
          type="button"
          onClick={() => navigate('/settings')}
          className="text-slate-900 dark:text-white flex size-12 shrink-0 items-center justify-start cursor-pointer"
        >
          <span className="material-symbols-outlined text-slate-400 dark:text-white">arrow_back_ios_new</span>
        </button>
        <h2 className="text-slate-900 dark:text-white text-lg font-bold leading-tight tracking-[-0.015em] flex-1 text-center">Notifications</h2>
        <div className="flex size-12 shrink-0 items-center"></div>
      </div>

      <div className="flex flex-col p-4 space-y-4 pb-12">
        {/* Master Toggle */}
        <div className="flex items-center gap-4 bg-slate-200 dark:bg-slate-800/50 px-4 min-h-14 justify-between rounded-lg">
          <div className="flex items-center gap-4">
            <div className="text-white flex items-center justify-center rounded-lg bg-primary/20 text-primary shrink-0 size-10">
              <span className="material-symbols-outlined">notifications</span>
            </div>
            <p className="text-slate-900 dark:text-white text-base font-medium leading-normal flex-1 truncate">Push Notifications</p>
          </div>
          <div className="shrink-0">
            <label className={`relative flex h-[31px] w-[51px] cursor-pointer items-center rounded-full border-none p-0.5 transition-colors ${settings.pushNotifications ? 'bg-primary justify-end' : 'bg-slate-300 dark:bg-slate-700 justify-start'}`}>
              <div className="h-full w-[27px] rounded-full bg-white shadow-sm"></div>
              <input 
                type="checkbox" 
                className="invisible absolute" 
                checked={settings.pushNotifications}
                onChange={() => toggleSetting('pushNotifications')}
              />
            </label>
          </div>
        </div>

        {/* Messages Section */}
        <h3 className="text-slate-500 dark:text-slate-400 text-sm font-bold uppercase tracking-wider px-4 pb-2 pt-4">Messages</h3>
        <div className="bg-slate-200 dark:bg-slate-800/50 rounded-lg overflow-hidden">
          {/* New Messages */}
          <div className="flex items-center gap-4 px-4 min-h-[72px] py-2 justify-between">
            <div className="flex items-center gap-4">
              <div className="text-slate-900 dark:text-white flex items-center justify-center rounded-lg bg-slate-300 dark:bg-slate-700 shrink-0 size-12">
                <span className="material-symbols-outlined">forward_to_inbox</span>
              </div>
              <div className="flex flex-col justify-center">
                <p className="text-slate-900 dark:text-white text-base font-medium leading-normal line-clamp-1">New Messages</p>
                <p className="text-slate-600 dark:text-slate-400 text-sm font-normal leading-normal line-clamp-2">Get notified when you receive a new message</p>
              </div>
            </div>
            <div className="shrink-0">
              <label className={`relative flex h-[31px] w-[51px] cursor-pointer items-center rounded-full border-none p-0.5 transition-colors ${settings.newMessages ? 'bg-primary justify-end' : 'bg-slate-300 dark:bg-slate-700 justify-start'}`}>
                <div className="h-full w-[27px] rounded-full bg-white shadow-sm"></div>
                <input 
                  type="checkbox" 
                  className="invisible absolute"
                  checked={settings.newMessages}
                  onChange={() => toggleSetting('newMessages')}
                />
              </label>
            </div>
          </div>
          <hr className="border-slate-300 dark:border-slate-700/50 ml-20"/>
          
          {/* Message Replies */}
          <div className="flex items-center gap-4 px-4 min-h-[72px] py-2 justify-between">
            <div className="flex items-center gap-4">
              <div className="text-slate-900 dark:text-white flex items-center justify-center rounded-lg bg-slate-300 dark:bg-slate-700 shrink-0 size-12">
                <span className="material-symbols-outlined">reply</span>
              </div>
              <div className="flex flex-col justify-center">
                <p className="text-slate-900 dark:text-white text-base font-medium leading-normal line-clamp-1">Message Replies</p>
                <p className="text-slate-600 dark:text-slate-400 text-sm font-normal leading-normal line-clamp-2">Get notified for replies to your messages</p>
              </div>
            </div>
            <div className="shrink-0">
              <label className={`relative flex h-[31px] w-[51px] cursor-pointer items-center rounded-full border-none p-0.5 transition-colors ${settings.messageReplies ? 'bg-primary justify-end' : 'bg-slate-300 dark:bg-slate-700 justify-start'}`}>
                <div className="h-full w-[27px] rounded-full bg-white shadow-sm"></div>
                <input 
                  type="checkbox" 
                  className="invisible absolute"
                  checked={settings.messageReplies}
                  onChange={() => toggleSetting('messageReplies')}
                />
              </label>
            </div>
          </div>
        </div>

        {/* Marketplace Activity Section */}
        <h3 className="text-slate-500 dark:text-slate-400 text-sm font-bold uppercase tracking-wider px-4 pb-2 pt-4">Marketplace Activity</h3>
        <div className="bg-slate-200 dark:bg-slate-800/50 rounded-lg overflow-hidden">
          {/* Sales Notifications */}
          <div className="flex items-center gap-4 px-4 min-h-[72px] py-2 justify-between">
            <div className="flex items-center gap-4">
              <div className="text-slate-900 dark:text-white flex items-center justify-center rounded-lg bg-slate-300 dark:bg-slate-700 shrink-0 size-12">
                <span className="material-symbols-outlined">monetization_on</span>
              </div>
              <div className="flex flex-col justify-center">
                <p className="text-slate-900 dark:text-white text-base font-medium leading-normal line-clamp-1">Sales Notifications</p>
                <p className="text-slate-600 dark:text-slate-400 text-sm font-normal leading-normal line-clamp-2">When an item you listed sells</p>
              </div>
            </div>
            <div className="shrink-0">
              <label className={`relative flex h-[31px] w-[51px] cursor-pointer items-center rounded-full border-none p-0.5 transition-colors ${settings.salesNotifications ? 'bg-primary justify-end' : 'bg-slate-300 dark:bg-slate-700 justify-start'}`}>
                <div className="h-full w-[27px] rounded-full bg-white shadow-sm"></div>
                <input 
                  type="checkbox" 
                  className="invisible absolute"
                  checked={settings.salesNotifications}
                  onChange={() => toggleSetting('salesNotifications')}
                />
              </label>
            </div>
          </div>
          <hr className="border-slate-300 dark:border-slate-700/50 ml-20"/>

          {/* New Reviews */}
          <div className="flex items-center gap-4 px-4 min-h-[72px] py-2 justify-between">
            <div className="flex items-center gap-4">
              <div className="text-slate-900 dark:text-white flex items-center justify-center rounded-lg bg-slate-300 dark:bg-slate-700 shrink-0 size-12">
                <span className="material-symbols-outlined">star_rate</span>
              </div>
              <div className="flex flex-col justify-center">
                <p className="text-slate-900 dark:text-white text-base font-medium leading-normal line-clamp-1">New Reviews</p>
                <p className="text-slate-600 dark:text-slate-400 text-sm font-normal leading-normal line-clamp-2">When a buyer leaves you a review</p>
              </div>
            </div>
            <div className="shrink-0">
              <label className={`relative flex h-[31px] w-[51px] cursor-pointer items-center rounded-full border-none p-0.5 transition-colors ${settings.newReviews ? 'bg-primary justify-end' : 'bg-slate-300 dark:bg-slate-700 justify-start'}`}>
                <div className="h-full w-[27px] rounded-full bg-white shadow-sm"></div>
                <input 
                  type="checkbox" 
                  className="invisible absolute"
                  checked={settings.newReviews}
                  onChange={() => toggleSetting('newReviews')}
                />
              </label>
            </div>
          </div>
          <hr className="border-slate-300 dark:border-slate-700/50 ml-20"/>

          {/* Item Comments */}
          <div className="flex items-center gap-4 px-4 min-h-[72px] py-2 justify-between">
            <div className="flex items-center gap-4">
              <div className="text-slate-900 dark:text-white flex items-center justify-center rounded-lg bg-slate-300 dark:bg-slate-700 shrink-0 size-12">
                <span className="material-symbols-outlined">chat_bubble</span>
              </div>
              <div className="flex flex-col justify-center">
                <p className="text-slate-900 dark:text-white text-base font-medium leading-normal line-clamp-1">Item Comments</p>
                <p className="text-slate-600 dark:text-slate-400 text-sm font-normal leading-normal line-clamp-2">When someone comments on your item</p>
              </div>
            </div>
            <div className="shrink-0">
              <label className={`relative flex h-[31px] w-[51px] cursor-pointer items-center rounded-full border-none p-0.5 transition-colors ${settings.itemComments ? 'bg-primary justify-end' : 'bg-slate-300 dark:bg-slate-700 justify-start'}`}>
                <div className="h-full w-[27px] rounded-full bg-white shadow-sm"></div>
                <input 
                  type="checkbox" 
                  className="invisible absolute"
                  checked={settings.itemComments}
                  onChange={() => toggleSetting('itemComments')}
                />
              </label>
            </div>
          </div>
        </div>

        {/* Community & Updates Section */}
        <h3 className="text-slate-500 dark:text-slate-400 text-sm font-bold uppercase tracking-wider px-4 pb-2 pt-4">Community &amp; Updates</h3>
        <div className="bg-slate-200 dark:bg-slate-800/50 rounded-lg overflow-hidden">
          {/* New Follower */}
          <div className="flex items-center gap-4 px-4 min-h-[72px] py-2 justify-between">
            <div className="flex items-center gap-4">
              <div className="text-slate-900 dark:text-white flex items-center justify-center rounded-lg bg-slate-300 dark:bg-slate-700 shrink-0 size-12">
                <span className="material-symbols-outlined">person_add</span>
              </div>
              <div className="flex flex-col justify-center">
                <p className="text-slate-900 dark:text-white text-base font-medium leading-normal line-clamp-1">New Follower</p>
                <p className="text-slate-600 dark:text-slate-400 text-sm font-normal leading-normal line-clamp-2">When a new user follows you</p>
              </div>
            </div>
            <div className="shrink-0">
              <label className={`relative flex h-[31px] w-[51px] cursor-pointer items-center rounded-full border-none p-0.5 transition-colors ${settings.newFollower ? 'bg-primary justify-end' : 'bg-slate-300 dark:bg-slate-700 justify-start'}`}>
                <div className="h-full w-[27px] rounded-full bg-white shadow-sm"></div>
                <input 
                  type="checkbox" 
                  className="invisible absolute"
                  checked={settings.newFollower}
                  onChange={() => toggleSetting('newFollower')}
                />
              </label>
            </div>
          </div>
          <hr className="border-slate-300 dark:border-slate-700/50 ml-20"/>

          {/* App Updates */}
          <div className="flex items-center gap-4 px-4 min-h-[72px] py-2 justify-between">
            <div className="flex items-center gap-4">
              <div className="text-slate-900 dark:text-white flex items-center justify-center rounded-lg bg-slate-300 dark:bg-slate-700 shrink-0 size-12">
                <span className="material-symbols-outlined">system_update</span>
              </div>
              <div className="flex flex-col justify-center">
                <p className="text-slate-900 dark:text-white text-base font-medium leading-normal line-clamp-1">App Updates</p>
                <p className="text-slate-600 dark:text-slate-400 text-sm font-normal leading-normal line-clamp-2">News on features and updates</p>
              </div>
            </div>
            <div className="shrink-0">
              <label className={`relative flex h-[31px] w-[51px] cursor-pointer items-center rounded-full border-none p-0.5 transition-colors ${settings.appUpdates ? 'bg-primary justify-end' : 'bg-slate-300 dark:bg-slate-700 justify-start'}`}>
                <div className="h-full w-[27px] rounded-full bg-white shadow-sm"></div>
                <input 
                  type="checkbox" 
                  className="invisible absolute"
                  checked={settings.appUpdates}
                  onChange={() => toggleSetting('appUpdates')}
                />
              </label>
            </div>
          </div>
          <hr className="border-slate-300 dark:border-slate-700/50 ml-20"/>

          {/* Promotional Offers */}
          <div className="flex items-center gap-4 px-4 min-h-[72px] py-2 justify-between">
            <div className="flex items-center gap-4">
              <div className="text-slate-900 dark:text-white flex items-center justify-center rounded-lg bg-slate-300 dark:bg-slate-700 shrink-0 size-12">
                <span className="material-symbols-outlined">campaign</span>
              </div>
              <div className="flex flex-col justify-center">
                <p className="text-slate-900 dark:text-white text-base font-medium leading-normal line-clamp-1">Promotional Offers</p>
                <p className="text-slate-600 dark:text-slate-400 text-sm font-normal leading-normal line-clamp-2">Receive special offers and discounts</p>
              </div>
            </div>
            <div className="shrink-0">
              <label className={`relative flex h-[31px] w-[51px] cursor-pointer items-center rounded-full border-none p-0.5 transition-colors ${settings.promotionalOffers ? 'bg-primary justify-end' : 'bg-slate-300 dark:bg-slate-700 justify-start'}`}>
                <div className="h-full w-[27px] rounded-full bg-white shadow-sm"></div>
                <input 
                  type="checkbox" 
                  className="invisible absolute"
                  checked={settings.promotionalOffers}
                  onChange={() => toggleSetting('promotionalOffers')}
                />
              </label>
            </div>
          </div>
        </div>

        {/* Email Alerts Section */}
        <h3 className="text-slate-500 dark:text-slate-400 text-sm font-bold uppercase tracking-wider px-4 pb-2 pt-4">Email Alerts</h3>
        <div className="bg-slate-200 dark:bg-slate-800/50 rounded-lg overflow-hidden">
          {/* Email: New Messages */}
          <div className="flex items-center gap-4 px-4 min-h-[72px] py-2 justify-between">
            <div className="flex items-center gap-4">
              <div className="text-slate-900 dark:text-white flex items-center justify-center rounded-lg bg-slate-300 dark:bg-slate-700 shrink-0 size-12">
                <span className="material-symbols-outlined">mail</span>
              </div>
              <div className="flex flex-col justify-center">
                <p className="text-slate-900 dark:text-white text-base font-medium leading-normal line-clamp-1">New Messages</p>
                <p className="text-slate-600 dark:text-slate-400 text-sm font-normal leading-normal line-clamp-2">Get emails when you receive a message</p>
              </div>
            </div>
            <div className="shrink-0">
              <label className={`relative flex h-[31px] w-[51px] cursor-pointer items-center rounded-full border-none p-0.5 transition-colors ${settings.emailNewMessages ? 'bg-primary justify-end' : 'bg-slate-300 dark:bg-slate-700 justify-start'}`}>
                <div className="h-full w-[27px] rounded-full bg-white shadow-sm"></div>
                <input 
                  type="checkbox" 
                  className="invisible absolute"
                  checked={settings.emailNewMessages}
                  onChange={() => toggleSetting('emailNewMessages')}
                />
              </label>
            </div>
          </div>
          <hr className="border-slate-300 dark:border-slate-700/50 ml-20"/>

          {/* Email: Account Security */}
          <div className="flex items-center gap-4 px-4 min-h-[72px] py-2 justify-between">
            <div className="flex items-center gap-4">
              <div className="text-slate-900 dark:text-white flex items-center justify-center rounded-lg bg-slate-300 dark:bg-slate-700 shrink-0 size-12">
                <span className="material-symbols-outlined">security</span>
              </div>
              <div className="flex flex-col justify-center">
                <p className="text-slate-900 dark:text-white text-base font-medium leading-normal line-clamp-1">Account Security</p>
                <p className="text-slate-600 dark:text-slate-400 text-sm font-normal leading-normal line-clamp-2">Alerts for suspicious logins or changes</p>
              </div>
            </div>
            <div className="shrink-0">
              <label className={`relative flex h-[31px] w-[51px] cursor-pointer items-center rounded-full border-none p-0.5 transition-colors ${settings.emailSecurityUpdates ? 'bg-primary justify-end' : 'bg-slate-300 dark:bg-slate-700 justify-start'}`}>
                <div className="h-full w-[27px] rounded-full bg-white shadow-sm"></div>
                <input 
                  type="checkbox" 
                  className="invisible absolute"
                  checked={settings.emailSecurityUpdates}
                  onChange={() => toggleSetting('emailSecurityUpdates')}
                />
              </label>
            </div>
          </div>
          <hr className="border-slate-300 dark:border-slate-700/50 ml-20"/>

          {/* Email: Promotional Offers */}
          <div className="flex items-center gap-4 px-4 min-h-[72px] py-2 justify-between">
            <div className="flex items-center gap-4">
              <div className="text-slate-900 dark:text-white flex items-center justify-center rounded-lg bg-slate-300 dark:bg-slate-700 shrink-0 size-12">
                <span className="material-symbols-outlined">local_offer</span>
              </div>
              <div className="flex flex-col justify-center">
                <p className="text-slate-900 dark:text-white text-base font-medium leading-normal line-clamp-1">Promotional Offers</p>
                <p className="text-slate-600 dark:text-slate-400 text-sm font-normal leading-normal line-clamp-2">Receive emails about sales and deals</p>
              </div>
            </div>
            <div className="shrink-0">
              <label className={`relative flex h-[31px] w-[51px] cursor-pointer items-center rounded-full border-none p-0.5 transition-colors ${settings.emailPromotions ? 'bg-primary justify-end' : 'bg-slate-300 dark:bg-slate-700 justify-start'}`}>
                <div className="h-full w-[27px] rounded-full bg-white shadow-sm"></div>
                <input 
                  type="checkbox" 
                  className="invisible absolute"
                  checked={settings.emailPromotions}
                  onChange={() => toggleSetting('emailPromotions')}
                />
              </label>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default NotificationSettingsScreen;
