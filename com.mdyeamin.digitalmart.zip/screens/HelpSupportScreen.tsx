
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

interface Topic {
  title: string;
  icon: string;
  path: string;
  color: string;
}

const HelpSupportScreen: React.FC = () => {
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState('');

  const topics: Topic[] = [
    { title: 'Getting Started', icon: 'rocket_launch', path: '/faq', color: 'bg-slate-300 dark:bg-slate-800' },
    { title: 'Account & Profile', icon: 'person', path: '/faq', color: 'bg-slate-300 dark:bg-slate-800' },
    { title: 'Buying Templates', icon: 'shopping_cart', path: '/faq', color: 'bg-slate-300 dark:bg-slate-800' },
    { title: 'Selling Templates', icon: 'upload', path: '/faq', color: 'bg-slate-300 dark:bg-slate-800' },
    { title: 'Troubleshooting (FAQ)', icon: 'build', path: '/faq', color: 'bg-slate-300 dark:bg-slate-800' },
  ];

  const resources = [
      { title: 'User Guides & Tutorials', icon: 'book_4', path: '/faq' },
      { title: 'Terms of Service', icon: 'gavel', path: '/terms-privacy' },
      { title: 'Community Forum', icon: 'forum', path: '/contact-us' },
  ];

  const contactOptions = [
      { title: 'Live Chat', icon: 'chat_bubble', subtitle: 'Available 9am-5pm', path: '/contact-us', iconBg: 'bg-[#34C759]' },
      { title: 'Email Support', icon: 'mail', subtitle: '', path: '/contact-us', iconBg: 'bg-primary' },
  ];

  const filteredTopics = topics.filter(t => t.title.toLowerCase().includes(searchTerm.toLowerCase()));
  const filteredResources = resources.filter(r => r.title.toLowerCase().includes(searchTerm.toLowerCase()));
  
  // If searching, show a unified list
  const isSearching = searchTerm.length > 0;

  const handleBack = () => {
    navigate('/settings');
  };

  return (
    <div className="relative flex h-auto min-h-screen w-full flex-col font-display bg-background-light dark:bg-background-dark">
      {/* Top App Bar - Fixed Layout */}
      <div className="flex items-center bg-background-light dark:bg-background-dark p-4 pb-2 sticky top-0 z-20 border-b border-transparent dark:border-slate-800">
        <button 
          onClick={handleBack}
          className="flex size-10 shrink-0 items-center justify-center rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer text-slate-900 dark:text-white"
        >
          <span className="material-symbols-outlined text-xl">arrow_back_ios_new</span>
        </button>
        
        <h1 className="flex-1 text-center text-slate-900 dark:text-white text-lg font-bold leading-tight">Help & Support</h1>

        <div className="size-10 shrink-0"></div>
      </div>

      {/* Search Bar */}
      <div className="px-4 py-3">
        <label className="flex flex-col min-w-40 h-12 w-full">
          <div className="flex w-full flex-1 items-stretch rounded-lg h-full">
            <div className="text-slate-500 dark:text-slate-400 flex bg-slate-200 dark:bg-slate-800/50 items-center justify-center pl-4 rounded-l-lg border-r-0">
              <span className="material-symbols-outlined">search</span>
            </div>
            <input 
              className="flex w-full min-w-0 flex-1 resize-none overflow-hidden rounded-r-lg text-slate-900 dark:text-white focus:outline-0 focus:ring-0 border-none bg-slate-200 dark:bg-slate-800/50 focus:border-none h-full placeholder:text-slate-500 dark:placeholder:text-slate-400 px-4 pl-2 text-base font-normal leading-normal" 
              placeholder="Search FAQs & articles"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
            {searchTerm && (
                <button onClick={() => setSearchTerm('')} className="bg-slate-200 dark:bg-slate-800/50 flex items-center justify-center px-3 rounded-r-lg text-slate-500">
                    <span className="material-symbols-outlined text-sm">close</span>
                </button>
            )}
          </div>
        </label>
      </div>

      <div className="px-4">
        <div className="h-px w-full bg-slate-200 dark:bg-slate-800"></div>
      </div>

      {isSearching ? (
          <div className="flex flex-col p-4 animate-fade-in">
              <h2 className="text-slate-900 dark:text-white text-sm font-bold uppercase tracking-wider pb-2">Search Results</h2>
              <div className="flex flex-col bg-slate-200/50 dark:bg-slate-900/50 rounded-xl overflow-hidden">
                  {[...filteredTopics, ...filteredResources].map((item, idx) => (
                       <div 
                        key={idx}
                        onClick={() => navigate(item.path)}
                        className={`flex items-center gap-4 px-4 min-h-14 justify-between cursor-pointer hover:bg-slate-200 dark:hover:bg-slate-800/50 transition-colors ${idx !== 0 ? 'border-t border-slate-300 dark:border-slate-800/70' : ''}`}
                      >
                        <div className="flex items-center gap-4">
                          <div className={`text-slate-800 dark:text-white flex items-center justify-center rounded-lg bg-slate-300 dark:bg-slate-800 shrink-0 size-10`}>
                            <span className="material-symbols-outlined">{item.icon}</span>
                          </div>
                          <p className="text-slate-900 dark:text-white text-base font-normal leading-normal flex-1 truncate">{item.title}</p>
                        </div>
                        <span className="material-symbols-outlined text-slate-400">chevron_right</span>
                      </div>
                  ))}
                  {[...filteredTopics, ...filteredResources].length === 0 && (
                      <div className="p-8 text-center text-slate-500">No results found.</div>
                  )}
              </div>
          </div>
      ) : (
        <>
            {/* Common Topics Section */}
            <div className="flex flex-col">
                <h2 className="text-slate-900 dark:text-white text-lg font-bold leading-tight tracking-[-0.015em] px-4 pb-2 pt-6">Common Topics</h2>
                <div className="flex flex-col bg-slate-200/50 dark:bg-slate-900/50 rounded-xl mx-4 overflow-hidden">
                    {topics.map((topic, index) => (
                        <div key={index}>
                            <div 
                                onClick={() => navigate(topic.path)}
                                className="flex items-center gap-4 px-4 min-h-14 justify-between cursor-pointer hover:bg-slate-200 dark:hover:bg-slate-800/50 transition-colors"
                            >
                                <div className="flex items-center gap-4">
                                <div className={`text-slate-800 dark:text-white flex items-center justify-center rounded-lg ${topic.color} shrink-0 size-10`}>
                                    <span className="material-symbols-outlined">{topic.icon}</span>
                                </div>
                                <p className="text-slate-900 dark:text-white text-base font-normal leading-normal flex-1 truncate">{topic.title}</p>
                                </div>
                                <div className="shrink-0">
                                <div className="text-slate-400 dark:text-slate-500 flex size-7 items-center justify-center">
                                    <span className="material-symbols-outlined">chevron_right</span>
                                </div>
                                </div>
                            </div>
                            {index < topics.length - 1 && <div className="h-px bg-slate-300 dark:bg-slate-800/70 ml-16"></div>}
                        </div>
                    ))}
                </div>
            </div>

            {/* Contact Us Section */}
            <div className="flex flex-col mt-4">
                <h2 className="text-slate-900 dark:text-white text-lg font-bold leading-tight tracking-[-0.015em] px-4 pb-2 pt-4">Contact Us</h2>
                <div className="flex flex-col bg-slate-200/50 dark:bg-slate-900/50 rounded-xl mx-4 overflow-hidden">
                    {contactOptions.map((option, index) => (
                        <div key={index}>
                             <div 
                                onClick={() => navigate(option.path)}
                                className="flex items-center gap-4 px-4 min-h-14 justify-between cursor-pointer hover:bg-slate-200 dark:hover:bg-slate-800/50 transition-colors"
                            >
                                <div className="flex items-center gap-4">
                                <div className={`text-white flex items-center justify-center rounded-lg ${option.iconBg} shrink-0 size-10`}>
                                    <span className="material-symbols-outlined">{option.icon}</span>
                                </div>
                                <div className="flex flex-col">
                                    <p className="text-slate-900 dark:text-white text-base font-normal leading-normal">{option.title}</p>
                                    {option.subtitle && <p className="text-slate-500 dark:text-slate-400 text-sm">{option.subtitle}</p>}
                                </div>
                                </div>
                                <div className="shrink-0">
                                <div className="text-slate-400 dark:text-slate-500 flex size-7 items-center justify-center">
                                    <span className="material-symbols-outlined">chevron_right</span>
                                </div>
                                </div>
                            </div>
                            {index < contactOptions.length - 1 && <div className="h-px bg-slate-300 dark:bg-slate-800/70 ml-16"></div>}
                        </div>
                    ))}
                </div>
            </div>

            {/* More Resources Section */}
            <div className="flex flex-col mt-4">
                <h2 className="text-slate-900 dark:text-white text-lg font-bold leading-tight tracking-[-0.015em] px-4 pb-2 pt-4">More Resources</h2>
                <div className="flex flex-col bg-slate-200/50 dark:bg-slate-900/50 rounded-xl mx-4 overflow-hidden">
                    {resources.map((res, index) => (
                        <div key={index}>
                            <div 
                                onClick={() => navigate(res.path)}
                                className="flex items-center gap-4 px-4 min-h-14 justify-between cursor-pointer hover:bg-slate-200 dark:hover:bg-slate-800/50 transition-colors"
                            >
                                <div className="flex items-center gap-4">
                                <div className="text-slate-800 dark:text-white flex items-center justify-center rounded-lg bg-slate-300 dark:bg-slate-800 shrink-0 size-10">
                                    <span className="material-symbols-outlined">{res.icon}</span>
                                </div>
                                <p className="text-slate-900 dark:text-white text-base font-normal leading-normal flex-1 truncate">{res.title}</p>
                                </div>
                                <div className="shrink-0">
                                <div className="text-slate-400 dark:text-slate-500 flex size-7 items-center justify-center">
                                    <span className="material-symbols-outlined">chevron_right</span>
                                </div>
                                </div>
                            </div>
                            {index < resources.length - 1 && <div className="h-px bg-slate-300 dark:bg-slate-800/70 ml-16"></div>}
                        </div>
                    ))}
                </div>
            </div>
        </>
      )}
      <div className="h-10"></div>
    </div>
  );
};

export default HelpSupportScreen;
