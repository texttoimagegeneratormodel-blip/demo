
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useApp } from '../context/AppContext';

const HomeScreen: React.FC = () => {
  const navigate = useNavigate();
  const { user, templates, toggleWishlist, isInWishlist } = useApp();
  const [searchTerm, setSearchTerm] = useState('');
  const [activeCategory, setActiveCategory] = useState('All');

  const categories = [
    { name: 'All', icon: 'apps' },
    { name: 'Websites', icon: 'public' },
    { name: 'Presentations', icon: 'slideshow' },
    { name: 'Logos', icon: 'draw' },
    { name: 'Social', icon: 'group' },
    { name: 'Resumes', icon: 'description' },
  ];

  // Filter Logic
  const filteredTemplates = templates.filter(t => {
    const matchesSearch = t.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          t.creator.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = activeCategory === 'All' || t.category === activeCategory;
    return matchesSearch && matchesCategory;
  });

  const featured = templates.filter(t => t.rating >= 4.7).slice(0, 5);

  return (
    <div className="flex flex-col pb-24">
      {/* Top App Bar */}
      <header className="sticky top-0 z-20 bg-background-light/80 dark:bg-background-dark/80 backdrop-blur-md px-4 py-3 flex items-center justify-between border-b border-transparent dark:border-slate-800/50 transition-all">
        <div className="flex items-center gap-3">
          <div 
            className="size-10 rounded-full bg-cover bg-center ring-2 ring-white dark:ring-slate-700 cursor-pointer"
            style={{ backgroundImage: `url("${user?.avatar || 'https://via.placeholder.com/150'}")` }}
            onClick={() => navigate('/login')}
          ></div>
          <div>
            <h2 className="text-slate-900 dark:text-white text-sm font-medium opacity-70">Welcome back</h2>
            <h1 className="text-slate-900 dark:text-white text-lg font-bold leading-none">{user?.name || 'Guest'}</h1>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button 
            onClick={() => navigate('/messages')}
            className="size-10 flex items-center justify-center rounded-full bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white shadow-sm hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors"
          >
            <span className="material-symbols-outlined">chat</span>
          </button>
          <button 
            onClick={() => navigate('/cart')}
            className="size-10 flex items-center justify-center rounded-full bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white shadow-sm hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors"
          >
            <span className="material-symbols-outlined">shopping_cart</span>
          </button>
        </div>
      </header>

      {/* Search Bar */}
      <div className="px-4 py-2 mt-2">
        <div className="relative flex items-center">
          <div className="absolute left-4 text-slate-400">
            <span className="material-symbols-outlined">search</span>
          </div>
          <input 
            className="w-full bg-white dark:bg-slate-800 h-12 pl-12 pr-12 rounded-2xl border-none focus:ring-2 focus:ring-primary/50 text-slate-900 dark:text-white placeholder:text-slate-400 shadow-sm transition-all"
            placeholder="Search for templates..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
          {searchTerm && (
            <button 
              onClick={() => setSearchTerm('')}
              className="absolute right-4 text-slate-400 hover:text-slate-600"
            >
              <span className="material-symbols-outlined text-[20px]">close</span>
            </button>
          )}
        </div>
      </div>

      {/* Categories Chips */}
      <div className="flex gap-3 px-4 py-4 overflow-x-auto no-scrollbar">
        {categories.map((cat, index) => (
          <button 
            key={index}
            onClick={() => setActiveCategory(cat.name)}
            className={`flex items-center gap-2 h-10 px-4 rounded-xl whitespace-nowrap transition-all duration-300 ${
              activeCategory === cat.name 
                ? 'bg-primary text-white shadow-lg shadow-primary/30 scale-105' 
                : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-700'
            }`}
          >
            <span className="material-symbols-outlined text-[20px]">{cat.icon}</span>
            <span className="text-sm font-semibold">{cat.name}</span>
          </button>
        ))}
      </div>

      {/* Featured Section (Only show if no search/filter active) */}
      {!searchTerm && activeCategory === 'All' && (
        <div className="mt-2 animate-fade-in">
          <div className="flex items-center justify-between px-4 mb-3">
            <h2 className="text-slate-900 dark:text-white text-xl font-bold">Featured</h2>
            <button className="text-primary text-sm font-semibold">See All</button>
          </div>
          <div className="flex gap-4 px-4 overflow-x-auto no-scrollbar pb-4">
            {featured.map((item) => (
              <div 
                key={item.id} 
                onClick={() => navigate(`/details/${item.id}`)}
                className="min-w-[300px] flex-shrink-0 group cursor-pointer"
              >
                <div 
                  className="w-full aspect-[16/9] rounded-2xl bg-cover bg-center shadow-md mb-3 transition-transform group-hover:scale-[1.02] relative overflow-hidden"
                  style={{ backgroundImage: `url("${item.thumbnail}")` }}
                >
                  <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-colors"></div>
                  <div className="absolute bottom-2 right-2 bg-black/40 backdrop-blur-md rounded-lg px-2 py-1 flex items-center gap-1">
                      <span className="material-symbols-outlined text-yellow-400 text-[16px] filled">star</span>
                      <span className="text-white text-xs font-bold">{item.rating}</span>
                  </div>
                </div>
                <h3 className="text-slate-900 dark:text-white font-bold text-lg">{item.title}</h3>
                <p className="text-slate-500 dark:text-slate-400 text-sm">by {item.creator.name}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Main Grid Section */}
      <div className="mt-4 px-4">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-slate-900 dark:text-white text-xl font-bold">
            {searchTerm ? 'Search Results' : 'Trending Now'}
          </h2>
        </div>
        
        {filteredTemplates.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-10 text-slate-500">
            <span className="material-symbols-outlined text-4xl mb-2">search_off</span>
            <p>No templates found.</p>
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-4">
            {filteredTemplates.map((item) => (
              <div key={item.id} onClick={() => navigate(`/details/${item.id}`)} className="cursor-pointer group">
                <div className="relative w-full aspect-[3/4] rounded-2xl overflow-hidden mb-3 shadow-sm bg-slate-100 dark:bg-slate-800">
                  <div 
                    className="absolute inset-0 bg-cover bg-center transition-transform duration-500 group-hover:scale-110"
                    style={{ backgroundImage: `url("${item.thumbnail}")` }}
                  ></div>
                  <button 
                    onClick={(e) => {
                      e.stopPropagation();
                      toggleWishlist(item.id);
                    }}
                    className={`absolute top-2 right-2 size-8 backdrop-blur-md rounded-full flex items-center justify-center transition-all hover:scale-110 ${
                      isInWishlist(item.id) 
                        ? 'bg-red-500 text-white shadow-red-500/50' 
                        : 'bg-black/20 text-white hover:bg-black/40'
                    }`}
                  >
                    <span className={`material-symbols-outlined text-[18px] ${isInWishlist(item.id) ? 'filled' : ''}`}>favorite</span>
                  </button>
                </div>
                <h3 className="text-slate-900 dark:text-white font-bold text-sm truncate">{item.title}</h3>
                
                {/* Rating Row */}
                <div className="flex items-center gap-1 mt-0.5">
                   <span className="material-symbols-outlined text-yellow-400 text-[14px] filled">star</span>
                   <span className="text-xs font-medium text-slate-700 dark:text-slate-300">{item.rating}</span>
                   <span className="text-xs text-slate-400 ml-1">({Math.floor(item.sales / 10)})</span>
                </div>

                <div className="flex justify-between items-center mt-1">
                  <p className="text-slate-500 dark:text-slate-400 text-xs truncate max-w-[80px]">by {item.creator.name}</p>
                  <span className="text-primary font-bold text-sm">${item.price.toFixed(2)}</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default HomeScreen;
