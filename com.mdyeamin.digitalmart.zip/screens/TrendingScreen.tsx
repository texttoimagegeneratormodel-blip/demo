
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useApp } from '../context/AppContext';

const TrendingScreen: React.FC = () => {
  const navigate = useNavigate();
  const { templates, toggleWishlist, isInWishlist } = useApp();
  const [activeTab, setActiveTab] = useState('This Week');

  // Sort templates by sales/popularity for demo simulation
  const trendingTemplates = [...templates].sort((a, b) => b.sales - a.sales);

  return (
    <div className="flex flex-col min-h-screen bg-background-light dark:bg-background-dark font-display pb-4">
      {/* Header */}
      <div className="flex items-center justify-between p-4 sticky top-0 z-10 bg-background-light/95 dark:bg-background-dark/95 backdrop-blur-sm">
        <button
          onClick={() => navigate(-1)}
          className="text-slate-800 dark:text-white flex size-10 shrink-0 items-center justify-center hover:bg-slate-100 dark:hover:bg-slate-800 rounded-full transition-colors"
        >
          <span className="material-symbols-outlined text-2xl">arrow_back_ios_new</span>
        </button>
        <h1 className="text-lg font-bold text-slate-900 dark:text-white">Trending</h1>
        <button className="text-slate-800 dark:text-white flex size-10 shrink-0 items-center justify-center hover:bg-slate-100 dark:hover:bg-slate-800 rounded-full transition-colors">
          <span className="material-symbols-outlined text-2xl">search</span>
        </button>
      </div>

      {/* Filter Tabs */}
      <div className="px-4 mb-6">
        <div className="flex p-1 bg-slate-200 dark:bg-[#1b2227] rounded-xl border border-slate-200 dark:border-slate-800">
          {['This Week', 'This Month', 'All Time'].map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`flex-1 py-2.5 text-xs font-bold rounded-lg transition-all ${
                activeTab === tab
                  ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-sm'
                  : 'text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200'
              }`}
            >
              {tab}
            </button>
          ))}
        </div>
      </div>

      {/* Grid */}
      <div className="grid grid-cols-2 gap-4 px-4">
        {trendingTemplates.map((item) => (
          <div
            key={item.id}
            onClick={() => navigate(`/details/${item.id}`)}
            className="group cursor-pointer"
          >
            <div className="relative w-full aspect-[3/4] rounded-2xl overflow-hidden mb-3 bg-slate-200 dark:bg-slate-800 border border-slate-200 dark:border-slate-800 shadow-sm">
              <div
                className="absolute inset-0 bg-cover bg-center transition-transform duration-500 group-hover:scale-110"
                style={{ backgroundImage: `url("${item.thumbnail}")` }}
              ></div>
              {/* Bookmark Icon */}
              <button
                onClick={(e) => {
                    e.stopPropagation();
                    toggleWishlist(item.id);
                }}
                className="absolute top-2 right-2 size-8 bg-black/40 text-white rounded-full flex items-center justify-center backdrop-blur-md hover:bg-black/60 transition-colors"
              >
                <span className={`material-symbols-outlined text-[20px] ${isInWishlist(item.id) ? 'filled' : ''}`}>
                    {isInWishlist(item.id) ? 'bookmark' : 'bookmark'}
                </span>
              </button>
            </div>

            <h3 className="text-slate-900 dark:text-white font-bold text-sm truncate">{item.title}</h3>
            <p className="text-slate-500 dark:text-slate-400 text-xs mt-1 mb-1">by {item.creator.name}</p>
            
            {/* Downloads Stat */}
            <div className="flex items-center gap-1.5 text-orange-500">
                <span className="material-symbols-outlined text-[18px] filled">local_fire_department</span>
                <span className="text-xs font-bold text-slate-600 dark:text-slate-300">
                    {item.sales >= 1000 ? (item.sales / 1000).toFixed(1) + 'k' : item.sales} Downloads
                </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default TrendingScreen;
