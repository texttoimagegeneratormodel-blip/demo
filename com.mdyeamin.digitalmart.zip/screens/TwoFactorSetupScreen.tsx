
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const TwoFactorSetupScreen: React.FC = () => {
  const navigate = useNavigate();
  const [method, setMethod] = useState<'app' | 'sms'>('app');
  const [code, setCode] = useState('');

  const handleCopyKey = () => {
    navigator.clipboard.writeText("ABCD 1234 EFGH 5678");
    alert("Setup key copied to clipboard!");
  };

  const handleVerify = () => {
    // Mock verification
    alert("Two-Factor Authentication Enabled Successfully!");
    navigate('/account-security');
  };

  return (
    <div className="relative flex h-auto min-h-screen w-full flex-col overflow-x-hidden bg-background-light dark:bg-background-dark font-display">
      {/* TopAppBar */}
      <div className="flex items-center bg-background-light dark:bg-background-dark p-4 pb-2 justify-between sticky top-0 z-10">
        <button 
          onClick={() => navigate('/account-security')}
          className="text-slate-800 dark:text-white flex size-12 shrink-0 items-center justify-start -ml-2 hover:text-primary transition-colors"
        >
          <span className="material-symbols-outlined text-2xl">arrow_back_ios_new</span>
        </button>
        <h2 className="text-slate-900 dark:text-white text-lg font-bold leading-tight tracking-[-0.015em] flex-1 text-center">Two-Factor Authentication</h2>
        <div className="flex w-12 items-center justify-end">
          <button 
            onClick={() => navigate('/account-security')}
            className="text-primary text-base font-bold leading-normal tracking-[0.015em] hover:text-primary/80 transition-colors"
          >
            Cancel
          </button>
        </div>
      </div>

      <div className="flex flex-col p-4 pb-32">
        {/* HeadlineText */}
        <div className="flex flex-col items-center text-center pt-2 pb-2">
          <div className="flex items-center justify-center h-20 w-20 rounded-full bg-primary/20 mb-4">
            <span className="material-symbols-outlined text-primary text-5xl">shield_lock</span>
          </div>
          <h1 className="text-slate-900 dark:text-white tracking-tight text-[32px] font-bold leading-tight text-center pb-2">Add an Extra Layer of Security</h1>
          {/* BodyText */}
          <p className="text-slate-600 dark:text-slate-400 text-base font-normal leading-normal text-center max-w-sm">
            2FA protects your account by requiring an additional code when you log in, even if someone knows your password.
          </p>
        </div>

        {/* TitleText */}
        <h1 className="text-slate-900 dark:text-white text-[22px] font-bold leading-tight tracking-[-0.015em] text-left pb-3 pt-8">Choose your verification method</h1>

        {/* RadioList */}
        <div className="flex flex-col gap-3">
          <label className={`flex cursor-pointer items-center gap-4 rounded-xl border border-solid p-[15px] flex-row-reverse transition-all ${
            method === 'app' 
              ? 'border-primary bg-primary/10 dark:bg-primary/20' 
              : 'border-slate-200 dark:border-slate-800 bg-slate-100/50 dark:bg-slate-800/20'
          }`}>
            <input 
              checked={method === 'app'} 
              onChange={() => setMethod('app')}
              className="h-5 w-5 border-2 border-slate-300 dark:border-slate-700 bg-transparent text-primary focus:ring-primary focus:ring-offset-background-dark checked:bg-primary" 
              name="verification_method" 
              type="radio"
            />
            <div className="flex grow flex-col">
              <p className="text-slate-900 dark:text-white text-base font-medium leading-normal">Authenticator App</p>
              <p className="text-slate-500 dark:text-slate-400 text-sm font-normal leading-normal">Use an app like Google Authenticator or Authy.</p>
            </div>
          </label>

          <label className={`flex cursor-pointer items-center gap-4 rounded-xl border border-solid p-[15px] flex-row-reverse transition-all ${
            method === 'sms' 
              ? 'border-primary bg-primary/10 dark:bg-primary/20' 
              : 'border-slate-200 dark:border-slate-800 bg-slate-100/50 dark:bg-slate-800/20'
          }`}>
            <input 
              checked={method === 'sms'} 
              onChange={() => setMethod('sms')}
              className="h-5 w-5 border-2 border-slate-300 dark:border-slate-700 bg-transparent text-primary focus:ring-primary focus:ring-offset-background-dark checked:bg-primary" 
              name="verification_method" 
              type="radio"
            />
            <div className="flex grow flex-col">
              <p className="text-slate-900 dark:text-white text-base font-medium leading-normal">SMS Verification</p>
              <p className="text-slate-500 dark:text-slate-400 text-sm font-normal leading-normal">Receive codes via text message.</p>
            </div>
          </label>
        </div>

        {/* Authenticator App Setup Flow */}
        {method === 'app' && (
          <div className="mt-8 flex flex-col gap-4 animate-fade-in">
            <p className="text-slate-600 dark:text-slate-400 text-sm">1. Scan this QR code with your authenticator app.</p>
            <div className="flex justify-center p-6 bg-white rounded-xl shadow-sm border border-slate-200 dark:border-slate-700">
              <img 
                alt="QR code for two-factor authentication setup" 
                src="https://lh3.googleusercontent.com/aida-public/AB6AXuBw7VG-6ylXf-3esXdktIZLKda8b1hDPX8KTJ2C2ykoVilCu9TzVqIS7WdVxB2suRW99vPKZSbnyFPzeTzEayBUfpK5Kw9YGOfwoV5crqGNG7sQyrFH4cmF7UQ_W097hR6taTuOL-Ct8vz7CKn0dmzvXwYKnpa2dPWZrdm3QyilDfHk5iOcE9QlsuW_TLkerebZKm6PfhEU3CIwwKyGSarITdZ8HTCl0JLWTaij8YnN3f5DsM8zQC5RYLWKU0i0xN9Yz9Bdfp5FC3M2"
                className="mix-blend-multiply"
              />
            </div>
            <button 
              onClick={handleCopyKey}
              className="w-full justify-center flex items-center gap-2 rounded-lg py-2.5 text-sm font-medium text-primary bg-primary/10 hover:bg-primary/20 active:bg-primary/30 transition-colors"
            >
              <span className="material-symbols-outlined text-base">content_copy</span>
              Copy Setup Key
            </button>
            
            <p className="text-slate-600 dark:text-slate-400 text-sm pt-2">2. Enter the 6-digit code from your app below.</p>
            {/* Verification Code Input */}
            <div>
              <label className="sr-only" htmlFor="verification-code">Verification Code</label>
              <input 
                id="verification-code"
                className="w-full rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-100/50 dark:bg-slate-900/40 p-4 text-center text-xl font-medium tracking-[0.5em] text-slate-900 dark:text-white placeholder:text-slate-400 dark:placeholder:text-slate-600 focus:border-primary focus:ring-primary focus:outline-none transition-shadow" 
                inputMode="numeric" 
                maxLength={6} 
                pattern="[0-9]*" 
                placeholder="––– –––" 
                type="text"
                value={code}
                onChange={(e) => setCode(e.target.value)}
              />
            </div>
          </div>
        )}

        {method === 'sms' && (
           <div className="mt-8 flex flex-col gap-4 animate-fade-in">
             <p className="text-slate-600 dark:text-slate-400 text-sm">Enter your phone number to receive a verification code.</p>
             <input 
                className="w-full rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-100/50 dark:bg-slate-900/40 p-4 text-base text-slate-900 dark:text-white placeholder:text-slate-400 dark:placeholder:text-slate-600 focus:border-primary focus:ring-primary focus:outline-none" 
                type="tel" 
                placeholder="+1 (555) 000-0000"
              />
              <button className="w-full justify-center flex items-center gap-2 rounded-lg py-3 text-sm font-bold text-white bg-primary hover:bg-primary/90 transition-colors">
                Send Code
              </button>
              
              <div className="pt-4 opacity-50 pointer-events-none">
                 <p className="text-slate-600 dark:text-slate-400 text-sm pb-2">Enter the 6-digit code sent to your phone.</p>
                 <input 
                  className="w-full rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-100/50 dark:bg-slate-900/40 p-4 text-center text-xl font-medium tracking-[0.5em] text-slate-900 dark:text-white" 
                  placeholder="––– –––" 
                  disabled
                />
              </div>
           </div>
        )}
      </div>

      {/* Sticky Footer with Button */}
      <div className="sticky bottom-0 mt-auto w-full bg-background-light dark:bg-background-dark p-4 border-t border-slate-200 dark:border-slate-800 backdrop-blur-sm z-20">
        <button 
          onClick={handleVerify}
          disabled={code.length < 6 && method === 'app'}
          className="w-full rounded-xl bg-primary py-4 px-4 text-base font-bold text-white shadow-[0_4px_14px_0_rgba(37,157,244,0.3)] hover:bg-opacity-90 disabled:opacity-50 disabled:shadow-none transition-all active:scale-[0.98]"
        >
          Verify & Activate
        </button>
        <p className="text-center text-xs text-slate-500 dark:text-slate-400 pt-3">
          Having trouble? <button className="font-medium text-primary hover:underline">Get Help</button>
        </p>
      </div>
    </div>
  );
};

export default TwoFactorSetupScreen;
