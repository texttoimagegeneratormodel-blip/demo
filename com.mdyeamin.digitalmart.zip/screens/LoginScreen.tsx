
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useApp } from '../context/AppContext';

const LoginScreen: React.FC = () => {
  const navigate = useNavigate();
  const { login } = useApp();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleLogin = () => {
    if (email) {
      login(email);
      navigate('/home');
    } else {
      // Just for demo, allow empty login but prefer email
      login('demo@example.com');
      navigate('/home');
    }
  };

  return (
    <div className="flex flex-col min-h-screen bg-background-light dark:bg-background-dark px-6">
      {/* Header: Logo */}
      <div className="flex items-center justify-center pt-12 pb-8">
        <div className="flex items-center gap-3">
          <div className="flex size-12 shrink-0 items-center justify-center rounded-xl bg-primary shadow-lg shadow-primary/30">
            <span className="material-symbols-outlined text-white text-3xl">layers</span>
          </div>
          <p className="text-2xl font-bold text-slate-800 dark:text-white">DigitalMart</p>
        </div>
      </div>

      {/* Headline */}
      <div className="text-center mb-8">
        <h1 className="text-slate-800 dark:text-white tracking-tight text-3xl font-bold mb-2">Let's sign you in</h1>
        <p className="text-slate-600 dark:text-slate-400 text-base">Welcome back, you've been missed!</p>
      </div>

      {/* Form Fields */}
      <div className="flex flex-col gap-5 w-full max-w-md mx-auto">
        <label className="flex flex-col w-full">
          <p className="text-slate-700 dark:text-slate-300 text-sm font-semibold mb-2 ml-1">Email</p>
          <div className="relative">
            <input 
              className="w-full rounded-xl bg-white dark:bg-[#1b2227] border border-slate-200 dark:border-slate-700 h-14 px-4 text-slate-800 dark:text-white focus:outline-none focus:ring-2 focus:ring-primary/50 transition-all placeholder:text-slate-400"
              placeholder="Enter your email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
          </div>
        </label>

        <label className="flex flex-col w-full">
          <p className="text-slate-700 dark:text-slate-300 text-sm font-semibold mb-2 ml-1">Password</p>
          <div className="relative flex items-center">
            <input 
              className="w-full rounded-xl bg-white dark:bg-[#1b2227] border border-slate-200 dark:border-slate-700 h-14 px-4 pr-12 text-slate-800 dark:text-white focus:outline-none focus:ring-2 focus:ring-primary/50 transition-all placeholder:text-slate-400"
              placeholder="Enter your password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleLogin()}
            />
            <button className="absolute right-4 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200">
              <span className="material-symbols-outlined">visibility_off</span>
            </button>
          </div>
        </label>

        <div className="flex justify-end">
          <button className="text-primary text-sm font-semibold hover:underline">Forgot Password?</button>
        </div>

        {/* CTA Button */}
        <button 
          onClick={handleLogin}
          className="w-full rounded-xl h-14 bg-primary text-white text-base font-bold shadow-lg shadow-primary/25 mt-2 transition-transform active:scale-95 hover:bg-primary/90"
        >
          Sign In
        </button>
      </div>

      {/* Don't have an account */}
      <div className="flex items-center justify-center gap-1 py-6">
        <p className="text-slate-600 dark:text-slate-400 text-sm">Don't have an account?</p>
        <button 
          onClick={() => navigate('/register')}
          className="text-primary text-sm font-bold hover:underline"
        >
          Create account
        </button>
      </div>

      {/* Social Login Separator */}
      <div className="flex items-center gap-4 py-4 w-full max-w-md mx-auto">
        <hr className="flex-grow border-slate-200 dark:border-slate-700" />
        <span className="text-slate-500 dark:text-slate-400 text-xs font-medium uppercase tracking-wider">OR</span>
        <hr className="flex-grow border-slate-200 dark:border-slate-700" />
      </div>

      {/* Social Login Buttons */}
      <div className="flex flex-col gap-3 w-full max-w-md mx-auto pb-8">
        <button onClick={handleLogin} className="flex w-full items-center justify-center rounded-xl h-14 bg-white dark:bg-[#1b2227] border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-white gap-3 font-semibold transition-colors hover:bg-slate-50 dark:hover:bg-slate-800">
           <div className="w-5 h-5 rounded-full bg-gradient-to-tr from-yellow-400 via-red-500 to-blue-500"></div>
          <span>Continue with Google</span>
        </button>
        <button onClick={handleLogin} className="flex w-full items-center justify-center rounded-xl h-14 bg-black text-white gap-3 font-semibold transition-opacity hover:opacity-90">
           <span className="material-symbols-outlined text-[20px]">star</span> 
           <span>Continue with Apple</span>
        </button>
      </div>
    </div>
  );
};

export default LoginScreen;
