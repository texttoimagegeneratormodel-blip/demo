
import React, { useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { useApp } from '../context/AppContext';

const ProfileInfoScreen: React.FC = () => {
  const navigate = useNavigate();
  const { user, updateUser, showToast } = useApp();
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Form State
  const [name, setName] = useState(user?.name || '');
  const [bio, setBio] = useState(user?.bio || '');
  const [avatar, setAvatar] = useState(user?.avatar || '');
  
  // Social Links State
  const [website, setWebsite] = useState(user?.socialLinks?.website || '');
  const [instagram, setInstagram] = useState(user?.socialLinks?.instagram || '');
  const [dribbble, setDribbble] = useState(user?.socialLinks?.dribbble || '');

  if (!user) {
    navigate('/login');
    return null;
  }

  const handleAvatarChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const url = URL.createObjectURL(e.target.files[0]);
      setAvatar(url);
    }
  };

  const handleSave = () => {
    if (!name.trim()) {
      showToast('Name is required', 'error');
      return;
    }

    updateUser({
      name,
      bio,
      avatar,
      socialLinks: {
        website,
        instagram,
        dribbble
      }
    });
    
    navigate(-1);
  };

  return (
    <div className="flex flex-col min-h-screen bg-background-light dark:bg-background-dark font-display pb-20">
      {/* Top App Bar */}
      <div className="flex items-center justify-between p-4 sticky top-0 bg-background-light/95 dark:bg-background-dark/95 backdrop-blur-sm z-20 border-b border-slate-200 dark:border-slate-800">
        <button 
          onClick={() => navigate(-1)}
          className="flex size-10 shrink-0 items-center justify-center rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer text-slate-900 dark:text-white"
        >
          <span className="material-symbols-outlined text-2xl">arrow_back_ios_new</span>
        </button>
        <h1 className="text-lg font-bold text-slate-900 dark:text-white">Edit Profile</h1>
        <button 
          onClick={handleSave}
          className="text-primary font-bold text-sm px-2 py-1 rounded-lg hover:bg-primary/10 transition-colors"
        >
          Save
        </button>
      </div>

      <div className="flex-1 p-4">
        {/* Avatar Upload */}
        <div className="flex flex-col items-center mb-8">
          <div className="relative group cursor-pointer" onClick={() => fileInputRef.current?.click()}>
            <div 
              className="size-28 rounded-full bg-cover bg-center border-4 border-white dark:border-slate-700 shadow-lg"
              style={{ backgroundImage: `url("${avatar}")` }}
            ></div>
            <div className="absolute inset-0 bg-black/40 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
              <span className="material-symbols-outlined text-white text-3xl">photo_camera</span>
            </div>
            <div className="absolute bottom-0 right-0 bg-primary text-white p-2 rounded-full shadow-md border-2 border-white dark:border-slate-800">
               <span className="material-symbols-outlined text-sm">edit</span>
            </div>
          </div>
          <input 
            type="file" 
            ref={fileInputRef} 
            className="hidden" 
            accept="image/*"
            onChange={handleAvatarChange} 
          />
          <p className="mt-3 text-sm text-primary font-bold cursor-pointer hover:underline" onClick={() => fileInputRef.current?.click()}>
            Change Profile Photo
          </p>
        </div>

        {/* Basic Info */}
        <div className="space-y-5">
          <h3 className="text-sm font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">Personal Details</h3>
          
          <label className="flex flex-col gap-2">
            <span className="text-sm font-medium text-slate-900 dark:text-white">Full Name</span>
            <input 
              className="w-full bg-slate-100 dark:bg-slate-800 rounded-xl px-4 h-12 border-none focus:ring-2 focus:ring-primary/50 text-slate-900 dark:text-white placeholder:text-slate-400"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Enter your name"
            />
          </label>

          <label className="flex flex-col gap-2">
            <span className="text-sm font-medium text-slate-900 dark:text-white">Bio</span>
            <textarea 
              className="w-full bg-slate-100 dark:bg-slate-800 rounded-xl p-4 h-32 border-none focus:ring-2 focus:ring-primary/50 text-slate-900 dark:text-white placeholder:text-slate-400 resize-none"
              value={bio}
              onChange={(e) => setBio(e.target.value)}
              placeholder="Tell us a little about yourself..."
            ></textarea>
          </label>

          <label className="flex flex-col gap-2 opacity-70">
            <span className="text-sm font-medium text-slate-900 dark:text-white">Email Address</span>
            <input 
              className="w-full bg-slate-200 dark:bg-slate-900/50 rounded-xl px-4 h-12 border-none text-slate-500 dark:text-slate-400 cursor-not-allowed"
              value={user.email}
              readOnly
            />
            <p className="text-xs text-slate-500">To change your email, please contact support.</p>
          </label>
        </div>

        <hr className="my-8 border-slate-200 dark:border-slate-800" />

        {/* Social Links */}
        <div className="space-y-5">
          <h3 className="text-sm font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">Social Links</h3>
          
          <label className="flex flex-col gap-2">
            <span className="text-sm font-medium text-slate-900 dark:text-white">Website</span>
            <div className="relative">
              <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 material-symbols-outlined text-[20px]">language</span>
              <input 
                className="w-full bg-slate-100 dark:bg-slate-800 rounded-xl pl-12 pr-4 h-12 border-none focus:ring-2 focus:ring-primary/50 text-slate-900 dark:text-white placeholder:text-slate-400"
                value={website}
                onChange={(e) => setWebsite(e.target.value)}
                placeholder="https://yourwebsite.com"
              />
            </div>
          </label>

          <label className="flex flex-col gap-2">
            <span className="text-sm font-medium text-slate-900 dark:text-white">Instagram</span>
            <div className="relative">
              <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 material-symbols-outlined text-[20px]">alternate_email</span>
              <input 
                className="w-full bg-slate-100 dark:bg-slate-800 rounded-xl pl-12 pr-4 h-12 border-none focus:ring-2 focus:ring-primary/50 text-slate-900 dark:text-white placeholder:text-slate-400"
                value={instagram}
                onChange={(e) => setInstagram(e.target.value)}
                placeholder="@username"
              />
            </div>
          </label>

          <label className="flex flex-col gap-2">
            <span className="text-sm font-medium text-slate-900 dark:text-white">Dribbble</span>
            <div className="relative">
              <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 material-symbols-outlined text-[20px]">sports_basketball</span>
              <input 
                className="w-full bg-slate-100 dark:bg-slate-800 rounded-xl pl-12 pr-4 h-12 border-none focus:ring-2 focus:ring-primary/50 text-slate-900 dark:text-white placeholder:text-slate-400"
                value={dribbble}
                onChange={(e) => setDribbble(e.target.value)}
                placeholder="@username"
              />
            </div>
          </label>
        </div>
      </div>
    </div>
  );
};

export default ProfileInfoScreen;
