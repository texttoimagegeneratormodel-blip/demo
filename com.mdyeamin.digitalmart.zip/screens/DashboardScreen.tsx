
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useApp } from '../context/AppContext';

// Simple Sparkline Component
const Sparkline: React.FC<{ data: number[]; color?: string; width?: number; height?: number }> = ({ 
  data, 
  color = "#22c55e", 
  width = 100, 
  height = 40 
}) => {
  if (!data || data.length < 2) return null;
  
  const max = Math.max(...data);
  const min = Math.min(...data);
  const range = max - min || 1;
  
  // Calculate points
  const points = data.map((val, index) => {
    const x = (index / (data.length - 1)) * width;
    const y = height - ((val - min) / range) * height; // Invert y because SVG 0 is top
    return `${x},${y}`;
  }).join(' ');

  return (
    <div className="flex flex-col items-center">
        <svg width={width} height={height} viewBox={`0 0 ${width} ${height}`} className="overflow-visible">
        <polyline
            fill="none"
            stroke={color}
            strokeWidth="2"
            points={points}
            strokeLinecap="round"
            strokeLinejoin="round"
        />
        {/* Dot on the last point */}
        <circle 
            cx={width} 
            cy={height - ((data[data.length - 1] - min) / range) * height} 
            r="3" 
            fill={color} 
        />
        </svg>
    </div>
  );
};

const DashboardScreen: React.FC = () => {
  const navigate = useNavigate();
  const { showToast } = useApp();
  const [filter, setFilter] = useState('All');
  const [sortBy, setSortBy] = useState<'sales' | 'earnings' | 'title'>('sales');
  const [showDeleteConfirm, setShowDeleteConfirm] = useState<string | null>(null); // Stores ID of item to delete

  // Mock data with sales history for charts
  const [myTemplates, setMyTemplates] = useState([
    {
      id: '201', 
      title: 'Minimalist Portfolio Website',
      status: 'Approved',
      sales: 150,
      earnings: 750,
      rating: 4.8,
      image: 'https://images.unsplash.com/photo-1507238691740-187a5b1d37b8?ixlib=rb-1.2.1&auto=format&fit=crop&w=200&q=80',
      salesHistory: [10, 25, 40, 35, 80, 100, 150]
    },
    {
      id: '202',
      title: 'Modern CV Resume Template',
      status: 'Pending',
      sales: 0,
      earnings: 0,
      rating: 0,
      image: 'https://images.unsplash.com/photo-1586281380349-632531db7ed4?ixlib=rb-1.2.1&auto=format&fit=crop&w=200&q=80',
      salesHistory: [0, 0, 0, 0, 0, 0, 0]
    },
    {
      id: '203',
      title: 'E-commerce Dashboard UI Kit',
      status: 'Rejected',
      sales: 12,
      earnings: 90,
      rating: 3.2,
      image: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?ixlib=rb-1.2.1&auto=format&fit=crop&w=200&q=80',
      salesHistory: [5, 12, 8, 4, 6, 2, 1]
    }
  ]);

  const filteredList = (filter === 'All' ? myTemplates : myTemplates.filter(t => t.status === filter)).sort((a, b) => {
    if (sortBy === 'sales') return b.sales - a.sales;
    if (sortBy === 'earnings') return b.earnings - a.earnings;
    if (sortBy === 'title') return a.title.localeCompare(b.title);
    return 0;
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Approved': return 'text-green-600 bg-green-100 dark:text-green-400 dark:bg-green-500/20';
      case 'Pending': return 'text-yellow-600 bg-yellow-100 dark:text-yellow-400 dark:bg-yellow-500/20';
      case 'Rejected': return 'text-red-600 bg-red-100 dark:text-red-400 dark:bg-red-500/20';
      default: return 'text-slate-500 bg-slate-100 dark:text-slate-400 dark:bg-slate-800';
    }
  };

  const getChartColor = (history: number[]) => {
      const start = history[0];
      const end = history[history.length - 1];
      if (end > start) return '#22c55e'; // Green
      if (end < start) return '#ef4444'; // Red
      return '#94a3b8'; // Slate/Grey
  };

  const handleWithdraw = () => {
    showToast("Withdrawal request initiated successfully!", "success");
  };

  const handleEdit = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    showToast(`Edit functionality coming soon for item ${id}`, 'info');
    // navigate(`/edit-template/${id}`); 
  };

  const handleDeleteClick = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setShowDeleteConfirm(id);
  };

  const confirmDelete = () => {
    if (showDeleteConfirm) {
        setMyTemplates(prev => prev.filter(t => t.id !== showDeleteConfirm));
        showToast("Template deleted successfully", "success");
        setShowDeleteConfirm(null);
    }
  };

  return (
    <div className="flex flex-col min-h-screen bg-background-light dark:bg-background-dark font-display pb-24">
      {/* Top App Bar */}
      <header className="flex items-center justify-between p-4 sticky top-0 bg-background-light/80 dark:bg-background-dark/80 backdrop-blur-sm z-10 border-b border-slate-200/50 dark:border-slate-800">
        <button 
          onClick={() => navigate('/home')}
          className="flex h-10 w-10 cursor-pointer items-center justify-center rounded-full text-slate-900 dark:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
        >
          <span className="material-symbols-outlined text-2xl">arrow_back_ios_new</span>
        </button>
        <h1 className="text-lg font-bold text-slate-900 dark:text-white flex-1 text-center">My Dashboard</h1>
        <div className="flex w-12 items-center justify-end">
          <button 
            onClick={() => navigate('/upload')}
            className="flex h-10 w-10 cursor-pointer items-center justify-center rounded-full bg-primary text-white hover:bg-primary/90 transition-colors"
          >
            <span className="material-symbols-outlined">add</span>
          </button>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-grow p-4 space-y-8">
        
        {/* Withdrawal Section */}
        <div className="flex flex-col gap-4 rounded-xl p-5 bg-white dark:bg-[#1b2227] border border-slate-200 dark:border-slate-800 shadow-sm">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-sm font-medium text-slate-500 dark:text-slate-400">Available Balance</p>
              <p className="text-3xl font-bold text-slate-900 dark:text-white">$325.50</p>
            </div>
            <button 
              onClick={() => showToast("Showing history (mock)", "info")}
              className="flex items-center gap-2 text-sm font-semibold text-primary hover:text-primary/80 transition-colors"
            >
              <span>History</span>
              <span className="material-symbols-outlined !text-xl">arrow_forward</span>
            </button>
          </div>
          
          <div className="flex items-center gap-3 p-3 rounded-lg bg-slate-100 dark:bg-background-dark">
            <div className="size-8 bg-white rounded-full flex items-center justify-center border border-slate-200 shadow-sm">
                 <span className="material-symbols-outlined text-blue-600 text-lg">account_balance_wallet</span>
            </div>
            <div className="flex-grow">
              <p className="text-sm font-bold text-slate-900 dark:text-white">PayPal</p>
              <p className="text-xs text-slate-500 dark:text-slate-400">creator@email.com</p>
            </div>
            <button className="text-slate-500 dark:text-slate-400 text-sm font-medium hover:text-slate-700 dark:hover:text-slate-200">Change</button>
          </div>

          <button 
            onClick={handleWithdraw}
            className="w-full bg-primary text-white font-bold py-3.5 px-4 rounded-xl flex items-center justify-center gap-2 hover:bg-primary/90 transition-colors shadow-lg shadow-primary/20 active:scale-[0.98]"
          >
            <span className="material-symbols-outlined">payments</span>
            <span>Withdraw Funds</span>
          </button>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
          <div className="flex flex-col gap-1 rounded-xl p-4 bg-white dark:bg-[#1b2227] border border-slate-200 dark:border-slate-800 shadow-sm">
            <p className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">Templates</p>
            <p className="text-2xl font-bold text-slate-900 dark:text-white">24</p>
            <div className="flex items-center gap-1 text-xs font-medium text-green-500">
              <span className="material-symbols-outlined !text-sm">trending_up</span>
              <span>+5 this mo.</span>
            </div>
          </div>
          <div className="flex flex-col gap-1 rounded-xl p-4 bg-white dark:bg-[#1b2227] border border-slate-200 dark:border-slate-800 shadow-sm">
            <p className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">Sales</p>
            <p className="text-2xl font-bold text-slate-900 dark:text-white">$1,250</p>
            <div className="flex items-center gap-1 text-xs font-medium text-green-500">
               <span className="material-symbols-outlined !text-sm">trending_up</span>
               <span>+12%</span>
            </div>
          </div>
          <div className="flex flex-col col-span-2 sm:col-span-1 gap-1 rounded-xl p-4 bg-white dark:bg-[#1b2227] border border-slate-200 dark:border-slate-800 shadow-sm">
            <p className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">Revenue</p>
            <p className="text-2xl font-bold text-slate-900 dark:text-white">$980</p>
            <div className="flex items-center gap-1 text-xs font-medium text-red-500">
               <span className="material-symbols-outlined !text-sm">trending_down</span>
               <span>-2%</span>
            </div>
          </div>
        </div>

        {/* My Templates Section */}
        <div className="flex flex-col gap-4">
          <div className="flex items-center justify-between px-1">
             <h2 className="text-xl font-bold text-slate-900 dark:text-white">My Templates</h2>
             <div className="relative">
              <select 
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
                className="appearance-none bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 text-xs font-bold py-1.5 pl-3 pr-8 rounded-lg cursor-pointer focus:outline-none focus:ring-2 focus:ring-primary/50 border border-transparent dark:border-slate-700"
              >
                <option value="sales">Sales (High-Low)</option>
                <option value="earnings">Earnings (High-Low)</option>
                <option value="title">Title (A-Z)</option>
              </select>
              <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-slate-500">
                <span className="material-symbols-outlined text-sm">expand_more</span>
              </div>
            </div>
          </div>

          {/* Filter Tabs */}
          <div className="flex p-1 bg-slate-200 dark:bg-[#1b2227] rounded-xl overflow-x-auto no-scrollbar">
              {['All', 'Approved', 'Pending', 'Rejected'].map((status) => (
                <label key={status} className={`flex-1 cursor-pointer min-w-[80px]`}>
                  <input 
                    type="radio" 
                    name="status-filter" 
                    value={status} 
                    className="sr-only"
                    checked={filter === status}
                    onChange={() => setFilter(status)}
                  />
                  <div className={`flex items-center justify-center py-2 px-2 rounded-lg text-sm font-semibold transition-all duration-200 ${
                    filter === status 
                      ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-sm' 
                      : 'text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200'
                  }`}>
                    {status}
                  </div>
                </label>
              ))}
          </div>

          {/* Template Cards List */}
          <div className="space-y-4">
            {filteredList.map((item) => (
              <div 
                key={item.id} 
                onClick={() => navigate(`/details/${item.id}`)}
                className="flex flex-col gap-4 rounded-xl bg-white dark:bg-[#1b2227] p-4 border border-slate-200 dark:border-slate-800 shadow-sm transition-transform hover:scale-[1.01] cursor-pointer"
              >
                <div className="flex gap-4">
                  <div 
                    className="size-24 bg-center bg-no-repeat bg-cover rounded-lg flex-shrink-0 bg-slate-100 dark:bg-slate-800" 
                    style={{ backgroundImage: `url("${item.image}")` }}
                  ></div>
                  
                  <div className="flex flex-col flex-1 min-w-0 justify-between">
                    <div>
                      <div className="flex items-start justify-between mb-1">
                        <span className={`text-[10px] font-bold uppercase tracking-wider px-2 py-1 rounded-full ${getStatusColor(item.status)}`}>
                          {item.status}
                        </span>
                        
                        {/* Quick Actions */}
                        <div className="flex items-center gap-1">
                          <button 
                            onClick={(e) => handleEdit(item.id, e)}
                            className="p-1.5 text-slate-400 hover:text-primary hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors"
                            title="Edit Template"
                          >
                            <span className="material-symbols-outlined text-[20px]">edit</span>
                          </button>
                          <button 
                            onClick={(e) => handleDeleteClick(item.id, e)}
                            className="p-1.5 text-slate-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-colors"
                            title="Delete Template"
                          >
                            <span className="material-symbols-outlined text-[20px]">delete</span>
                          </button>
                        </div>
                      </div>
                      
                      <h3 className="text-base font-bold text-slate-900 dark:text-white truncate pr-2" title={item.title}>
                        {item.title}
                      </h3>
                    </div>
                    
                    <div className="flex items-end justify-between mt-2">
                        <div className="flex flex-col gap-1">
                            <div className="flex items-center gap-2">
                                <span className="text-xs font-medium text-slate-500 dark:text-slate-400">Total Sales:</span>
                                <span className="text-sm font-bold text-slate-900 dark:text-white">{item.sales}</span>
                            </div>
                            <div className="flex items-center gap-2">
                                <span className="text-xs font-medium text-slate-500 dark:text-slate-400">Earnings:</span>
                                <span className="text-sm font-bold text-green-500">${item.earnings}</span>
                            </div>
                        </div>
                        
                        {/* Sparkline Chart */}
                        {item.salesHistory && item.salesHistory.some(v => v > 0) && (
                            <div className="flex flex-col items-end">
                                <div className="h-8 w-20">
                                    <Sparkline 
                                        data={item.salesHistory} 
                                        color={getChartColor(item.salesHistory)} 
                                        width={80} 
                                        height={32} 
                                    />
                                </div>
                                <span className="text-[10px] text-slate-400 mt-1">Last 7 days</span>
                            </div>
                        )}
                    </div>
                  </div>
                </div>
              </div>
            ))}

            {filteredList.length === 0 && (
              <div className="flex flex-col items-center justify-center text-center py-12 px-4 space-y-3 rounded-xl bg-slate-50 dark:bg-[#1b2227]/50 border-2 border-dashed border-slate-200 dark:border-slate-800">
                  <div className="flex items-center justify-center h-14 w-14 rounded-full bg-slate-200 dark:bg-slate-800 text-slate-400">
                    <span className="material-symbols-outlined !text-3xl">filter_list_off</span>
                  </div>
                  <h3 className="text-base font-bold text-slate-900 dark:text-white">No Templates Found</h3>
                  <p className="text-slate-500 dark:text-slate-400 text-sm">
                    No items match the status "{filter}".
                  </p>
              </div>
            )}
          </div>
        </div>
      </main>

      {/* Delete Confirmation Modal */}
      {showDeleteConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div 
            className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            onClick={() => setShowDeleteConfirm(null)}
          ></div>
          <div className="relative w-full max-w-sm overflow-hidden rounded-xl bg-white dark:bg-[#1C1C1E] shadow-2xl animate-fade-in z-50">
            <div className="p-6 text-center">
              <div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-full bg-red-100 dark:bg-red-900/30">
                <span className="material-symbols-outlined text-red-600 dark:text-red-500 text-2xl">delete</span>
              </div>
              <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-2">Delete Template?</h3>
              <p className="text-sm text-slate-600 dark:text-slate-400">
                Are you sure you want to delete this template? This action cannot be undone.
              </p>
            </div>
            <div className="flex border-t border-slate-200 dark:border-slate-700">
              <button 
                onClick={() => setShowDeleteConfirm(null)}
                className="flex-1 px-4 py-3 text-sm font-medium text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 border-r border-slate-200 dark:border-slate-700 transition-colors"
              >
                Cancel
              </button>
              <button 
                onClick={confirmDelete}
                className="flex-1 px-4 py-3 text-sm font-bold text-red-600 dark:text-red-500 hover:bg-red-50 dark:hover:bg-red-900/10 transition-colors"
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};

export default DashboardScreen;
