
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useApp } from '../context/AppContext';

const SettingsScreen: React.FC = () => {
  const navigate = useNavigate();
  const { logout } = useApp();

  const handleLogout = () => {
    const confirm = window.confirm("Are you sure you want to log out?");
    if (confirm) {
      logout();
      navigate('/login');
    }
  };

  const handleDeleteAccount = () => {
    const confirm = window.confirm("Are you sure you want to delete your account? This action cannot be undone.");
    if (confirm) {
        logout();
        navigate('/login');
    }
  };

  return (
    <div className="relative flex h-auto min-h-screen w-full flex-col bg-background-light dark:bg-background-dark font-display overflow-x-hidden">
      {/* Top App Bar */}
      <div className="flex items-center bg-background-light dark:bg-background-dark p-4 pb-2 justify-between sticky top-0 z-10">
        <div className="flex size-12 shrink-0 items-center text-slate-800 dark:text-white">
          <button 
            onClick={() => navigate('/profile')}
            className="flex items-center justify-center size-full rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <span className="material-symbols-outlined text-3xl">arrow_back_ios_new</span>
          </button>
        </div>
        <h2 className="text-slate-900 dark:text-white text-lg font-bold leading-tight tracking-[-0.015em] flex-1 text-center">Settings</h2>
        <div className="flex size-12 shrink-0 items-center"></div>
      </div>

      {/* Spacer */}
      <div className="h-4 bg-background-light dark:bg-background-dark"></div>
      
      <div className="flex flex-col gap-8 px-4 pb-12">
        {/* ACCOUNT Section */}
        <div className="flex flex-col">
          <h3 className="text-slate-500 dark:text-slate-400 text-sm font-semibold uppercase tracking-wider px-4 pb-2">ACCOUNT</h3>
          <div className="flex flex-col bg-slate-200/50 dark:bg-slate-800/40 rounded-xl overflow-hidden">
            
            {/* Profile Information */}
            <div 
              onClick={() => navigate('/profile-info')}
              className="flex items-center gap-4 bg-transparent px-4 min-h-14 justify-between cursor-pointer hover:bg-slate-200 dark:hover:bg-slate-800/60 transition-colors"
            >
              <div className="flex items-center gap-4">
                <div className="text-slate-800 dark:text-white flex items-center justify-center rounded-lg bg-slate-300 dark:bg-slate-700 shrink-0 size-10">
                  <span className="material-symbols-outlined">person</span>
                </div>
                <p className="text-slate-900 dark:text-white text-base font-normal leading-normal flex-1 truncate">Profile Information</p>
              </div>
              <div className="shrink-0">
                <div className="text-slate-500 dark:text-slate-400 flex size-7 items-center justify-center">
                  <span className="material-symbols-outlined">chevron_right</span>
                </div>
              </div>
            </div>
            <hr className="border-slate-300 dark:border-slate-700 ml-18"/>

            {/* Notification Settings */}
            <div 
              onClick={() => navigate('/notifications')}
              className="flex items-center gap-4 bg-transparent px-4 min-h-14 justify-between cursor-pointer hover:bg-slate-200 dark:hover:bg-slate-800/60 transition-colors"
            >
              <div className="flex items-center gap-4">
                <div className="text-slate-800 dark:text-white flex items-center justify-center rounded-lg bg-slate-300 dark:bg-slate-700 shrink-0 size-10">
                  <span className="material-symbols-outlined">notifications</span>
                </div>
                <p className="text-slate-900 dark:text-white text-base font-normal leading-normal flex-1 truncate">Notification Settings</p>
              </div>
              <div className="shrink-0">
                <div className="text-slate-500 dark:text-slate-400 flex size-7 items-center justify-center">
                  <span className="material-symbols-outlined">chevron_right</span>
                </div>
              </div>
            </div>
            <hr className="border-slate-300 dark:border-slate-700 ml-18"/>

            {/* Payment Methods */}
            <div 
              onClick={() => navigate('/payment-methods')}
              className="flex items-center gap-4 bg-transparent px-4 min-h-14 justify-between cursor-pointer hover:bg-slate-200 dark:hover:bg-slate-800/60 transition-colors"
            >
              <div className="flex items-center gap-4">
                <div className="text-slate-800 dark:text-white flex items-center justify-center rounded-lg bg-slate-300 dark:bg-slate-700 shrink-0 size-10">
                  <span className="material-symbols-outlined">credit_card</span>
                </div>
                <p className="text-slate-900 dark:text-white text-base font-normal leading-normal flex-1 truncate">Payment Methods</p>
              </div>
              <div className="shrink-0">
                <div className="text-slate-500 dark:text-slate-400 flex size-7 items-center justify-center">
                  <span className="material-symbols-outlined">chevron_right</span>
                </div>
              </div>
            </div>
            <hr className="border-slate-300 dark:border-slate-700 ml-18"/>

            {/* Account Security */}
            <div 
              onClick={() => navigate('/account-security')}
              className="flex items-center gap-4 bg-transparent px-4 min-h-14 justify-between cursor-pointer hover:bg-slate-200 dark:hover:bg-slate-800/60 transition-colors"
            >
              <div className="flex items-center gap-4">
                <div className="text-slate-800 dark:text-white flex items-center justify-center rounded-lg bg-slate-300 dark:bg-slate-700 shrink-0 size-10">
                  <span className="material-symbols-outlined">security</span>
                </div>
                <p className="text-slate-900 dark:text-white text-base font-normal leading-normal flex-1 truncate">Account Security</p>
              </div>
              <div className="shrink-0">
                <div className="text-slate-500 dark:text-slate-400 flex size-7 items-center justify-center">
                  <span className="material-symbols-outlined">chevron_right</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* SUPPORT Section */}
        <div className="flex flex-col">
          <h3 className="text-slate-500 dark:text-slate-400 text-sm font-semibold uppercase tracking-wider px-4 pb-2">SUPPORT</h3>
          <div className="flex flex-col bg-slate-200/50 dark:bg-slate-800/40 rounded-xl overflow-hidden">
            {/* Help & Support */}
            <div 
              onClick={() => navigate('/help-support')}
              className="flex items-center gap-4 bg-transparent px-4 min-h-14 justify-between cursor-pointer hover:bg-slate-200 dark:hover:bg-slate-800/60 transition-colors"
            >
              <div className="flex items-center gap-4">
                <div className="text-slate-800 dark:text-white flex items-center justify-center rounded-lg bg-slate-300 dark:bg-slate-700 shrink-0 size-10">
                  <span className="material-symbols-outlined">help_outline</span>
                </div>
                <p className="text-slate-900 dark:text-white text-base font-normal leading-normal flex-1 truncate">Help & Support</p>
              </div>
              <div className="shrink-0">
                <div className="text-slate-500 dark:text-slate-400 flex size-7 items-center justify-center">
                  <span className="material-symbols-outlined">chevron_right</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* LEGAL Section */}
        <div className="flex flex-col">
          <h3 className="text-slate-500 dark:text-slate-400 text-sm font-semibold uppercase tracking-wider px-4 pb-2">LEGAL</h3>
          <div className="flex flex-col bg-slate-200/50 dark:bg-slate-800/40 rounded-xl overflow-hidden">
            {/* Terms & Privacy */}
            <div 
              onClick={() => navigate('/terms-privacy')}
              className="flex items-center gap-4 bg-transparent px-4 min-h-14 justify-between cursor-pointer hover:bg-slate-200 dark:hover:bg-slate-800/60 transition-colors"
            >
              <div className="flex items-center gap-4">
                <div className="text-slate-800 dark:text-white flex items-center justify-center rounded-lg bg-slate-300 dark:bg-slate-700 shrink-0 size-10">
                  <span className="material-symbols-outlined">gavel</span>
                </div>
                <p className="text-slate-900 dark:text-white text-base font-normal leading-normal flex-1 truncate">Terms & Privacy Policy</p>
              </div>
              <div className="shrink-0">
                <div className="text-slate-500 dark:text-slate-400 flex size-7 items-center justify-center">
                  <span className="material-symbols-outlined">chevron_right</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* ABOUT Section */}
        <div className="flex flex-col">
          <h3 className="text-slate-500 dark:text-slate-400 text-sm font-semibold uppercase tracking-wider px-4 pb-2">ABOUT</h3>
          <div className="flex flex-col bg-slate-200/50 dark:bg-slate-800/40 rounded-xl overflow-hidden">
            {/* About App */}
            <div 
              onClick={() => navigate('/about')}
              className="flex items-center gap-4 bg-transparent px-4 min-h-14 justify-between cursor-pointer hover:bg-slate-200 dark:hover:bg-slate-800/60 transition-colors"
            >
              <div className="flex items-center gap-4">
                <div className="text-slate-800 dark:text-white flex items-center justify-center rounded-lg bg-slate-300 dark:bg-slate-700 shrink-0 size-10">
                  <span className="material-symbols-outlined">info</span>
                </div>
                <p className="text-slate-900 dark:text-white text-base font-normal leading-normal flex-1 truncate">About App</p>
              </div>
              <div className="shrink-0">
                <div className="text-slate-500 dark:text-slate-400 flex size-7 items-center justify-center">
                  <span className="material-symbols-outlined">chevron_right</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* ACTIONS Section */}
        <div className="flex flex-col pb-12">
          <h3 className="text-slate-500 dark:text-slate-400 text-sm font-semibold uppercase tracking-wider px-4 pb-2">ACTIONS</h3>
          <div className="flex flex-col bg-slate-200/50 dark:bg-slate-800/40 rounded-xl overflow-hidden">
            {/* Logout */}
            <div 
              onClick={handleLogout}
              className="flex items-center gap-4 bg-transparent px-4 min-h-14 justify-center cursor-pointer hover:bg-slate-200 dark:hover:bg-slate-800/60 transition-colors"
            >
              <p className="text-primary text-base font-normal leading-normal">Logout</p>
            </div>
            <hr className="border-slate-300 dark:border-slate-700"/>
            
            {/* Delete Account */}
            <div 
              onClick={handleDeleteAccount}
              className="flex items-center gap-4 bg-transparent px-4 min-h-14 justify-center cursor-pointer hover:bg-red-50 dark:hover:bg-red-900/10 transition-colors"
            >
              <p className="text-red-500 dark:text-red-500 text-base font-normal leading-normal">Delete Account</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SettingsScreen;
