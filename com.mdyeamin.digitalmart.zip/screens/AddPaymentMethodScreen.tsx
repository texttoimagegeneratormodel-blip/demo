
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useApp } from '../context/AppContext';
import { PaymentMethod } from '../types';

const AddPaymentMethodScreen: React.FC = () => {
  const navigate = useNavigate();
  const { showToast, addPaymentMethod } = useApp();
  const [paymentType, setPaymentType] = useState('Card');
  const [isDefault, setIsDefault] = useState(false);

  // Form State - Card
  const [cardNumber, setCardNumber] = useState('');
  const [cardName, setCardName] = useState('');
  const [expiry, setExpiry] = useState('');
  const [cvv, setCvv] = useState('');

  // Form State - Bank
  const [routingNumber, setRoutingNumber] = useState('');
  const [accountNumber, setAccountNumber] = useState('');
  const [bankName, setBankName] = useState('');

  // Form State - PayPal
  const [paypalEmail, setPaypalEmail] = useState('');

  const handleSave = () => {
    let newMethod: PaymentMethod | null = null;
    const id = Math.random().toString(36).substr(2, 9);

    if (paymentType === 'Card') {
      if (!cardNumber || !expiry || !cvv) {
        showToast("Please fill in card details", "error");
        return;
      }
      newMethod = {
        id,
        type: 'Card',
        title: `Card ending in ${cardNumber.slice(-4)}`,
        subtitle: `Expires ${expiry}`,
        isDefault,
        iconType: 'icon',
        iconValue: 'credit_card'
      };
    } else if (paymentType === 'Bank Account') {
      if (!routingNumber || !accountNumber || !bankName) {
        showToast("Please fill in bank details", "error");
        return;
      }
      newMethod = {
        id,
        type: 'Bank',
        title: `${bankName} •••• ${accountNumber.slice(-4)}`,
        subtitle: 'Checking Account',
        isDefault,
        iconType: 'icon',
        iconValue: 'account_balance'
      };
    } else if (paymentType === 'PayPal') {
      if (!paypalEmail || !paypalEmail.includes('@')) {
        showToast("Please enter a valid PayPal email", "error");
        return;
      }
      newMethod = {
        id,
        type: 'PayPal',
        title: paypalEmail,
        subtitle: 'PayPal Account',
        isDefault,
        iconType: 'image',
        iconValue: 'https://lh3.googleusercontent.com/aida-public/AB6AXuD-oR3vUs4EfBB-C1zA0mWQRlcnpeGzdPMm7sS4j-crQJfYgJ2-0hSb1i8cuEYltnz-5Lzd_fcn7MFfMzX73n7ivvF_C2xu-sOBWntdO8CwBCfiSX74fzeIV2ppln-1x-_dXHKfaMsto5dQqXiNOLX7hXODRUxmevrK9VzFR5MjnUKAG8pKxqDcVhLIiwKwgGuPIOidkC2MOPAv9O7bL9sccOWsTgMg9UfM7MzlHbt3ECZ_HyydqH6uFr2ENIONNnWpX19FQzhsM0Hp'
      };
    }

    if (newMethod) {
      addPaymentMethod(newMethod);
      showToast(`${paymentType} added successfully!`, "success");
      navigate('/payment-methods');
    }
  };

  return (
    <div className="relative flex h-auto min-h-screen w-full flex-col font-display bg-background-light dark:bg-background-dark overflow-x-hidden">
      {/* Header */}
      <div className="flex items-center bg-background-light dark:bg-background-dark p-4 pb-2 justify-between sticky top-0 z-10">
        <button 
          onClick={() => navigate('/payment-methods')}
          className="text-slate-800 dark:text-white flex size-10 shrink-0 items-center justify-center rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
        >
          <span className="material-symbols-outlined text-2xl">close</span>
        </button>
        <h1 className="text-slate-900 dark:text-white text-lg font-bold leading-tight tracking-tight flex-1 text-center">Add Payment Method</h1>
        <div className="w-10"></div>
      </div>

      {/* Payment Type Selector */}
      <div className="flex px-4 py-3">
        <div className="flex h-11 w-full flex-1 items-center justify-center rounded-lg bg-slate-200 dark:bg-slate-800/60 p-1">
          {['Card', 'Bank Account', 'PayPal'].map((type) => (
            <label key={type} className={`flex cursor-pointer h-full grow items-center justify-center overflow-hidden rounded-md px-2 text-sm font-medium leading-normal transition-all duration-200 ${
              paymentType === type 
                ? 'bg-white dark:bg-slate-700/80 shadow-sm text-slate-900 dark:text-white' 
                : 'text-slate-500 dark:text-slate-400'
            }`}>
              <span className="truncate">{type}</span>
              <input 
                type="radio" 
                name="payment-method" 
                value={type} 
                className="sr-only"
                checked={paymentType === type}
                onChange={() => setPaymentType(type)}
              />
            </label>
          ))}
        </div>
      </div>

      {/* Form Content */}
      <main className="flex-1 px-4 py-3 pb-32">
        {paymentType === 'Card' && (
          <div className="flex flex-col gap-4 animate-fade-in">
            <label className="flex flex-col w-full">
              <p className="text-slate-900 dark:text-white text-base font-medium leading-normal pb-2">Card Number</p>
              <div className="flex w-full flex-1 items-stretch rounded-xl relative">
                <input 
                  className="flex w-full min-w-0 flex-1 resize-none overflow-hidden rounded-xl text-slate-900 dark:text-white focus:outline-0 focus:ring-2 focus:ring-primary/50 border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800/60 focus:border-primary h-14 placeholder:text-slate-400 dark:placeholder:text-slate-500 p-4 pr-12 text-base font-normal leading-normal" 
                  placeholder="0000 0000 0000 0000" 
                  value={cardNumber}
                  onChange={(e) => setCardNumber(e.target.value)}
                />
                <div className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 dark:text-slate-500 flex items-center justify-center pointer-events-none">
                  <span className="material-symbols-outlined text-2xl">credit_card</span>
                </div>
              </div>
            </label>

            <label className="flex flex-col w-full">
              <p className="text-slate-900 dark:text-white text-base font-medium leading-normal pb-2">Name on Card</p>
              <input 
                className="flex w-full min-w-0 flex-1 resize-none overflow-hidden rounded-xl text-slate-900 dark:text-white focus:outline-0 focus:ring-2 focus:ring-primary/50 border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800/60 focus:border-primary h-14 placeholder:text-slate-400 dark:placeholder:text-slate-500 p-4 text-base font-normal leading-normal" 
                placeholder="Enter your name" 
                value={cardName}
                onChange={(e) => setCardName(e.target.value)}
              />
            </label>

            <div className="flex w-full flex-wrap items-end gap-4">
              <label className="flex flex-col min-w-40 flex-1">
                <p className="text-slate-900 dark:text-white text-base font-medium leading-normal pb-2">Expiration Date</p>
                <input 
                  className="flex w-full min-w-0 flex-1 resize-none overflow-hidden rounded-xl text-slate-900 dark:text-white focus:outline-0 focus:ring-2 focus:ring-primary/50 border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800/60 focus:border-primary h-14 placeholder:text-slate-400 dark:placeholder:text-slate-500 p-4 text-base font-normal leading-normal" 
                  placeholder="MM/YY" 
                  value={expiry}
                  onChange={(e) => setExpiry(e.target.value)}
                />
              </label>
              <label className="flex flex-col min-w-40 flex-1">
                <div className="flex items-center pb-2">
                  <p className="text-slate-900 dark:text-white text-base font-medium leading-normal">CVV</p>
                  <span className="material-symbols-outlined text-slate-400 dark:text-slate-500 ml-1.5 text-lg">help</span>
                </div>
                <input 
                  className="flex w-full min-w-0 flex-1 resize-none overflow-hidden rounded-xl text-slate-900 dark:text-white focus:outline-0 focus:ring-2 focus:ring-primary/50 border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800/60 focus:border-primary h-14 placeholder:text-slate-400 dark:placeholder:text-slate-500 p-4 text-base font-normal leading-normal" 
                  placeholder="123" 
                  type="password"
                  maxLength={4}
                  value={cvv}
                  onChange={(e) => setCvv(e.target.value)}
                />
              </label>
            </div>
          </div>
        )}

        {paymentType === 'Bank Account' && (
           <div className="flex flex-col gap-4 animate-fade-in">
             <label className="flex flex-col w-full">
              <p className="text-slate-900 dark:text-white text-base font-medium leading-normal pb-2">Routing Number</p>
              <input 
                className="flex w-full min-w-0 flex-1 resize-none overflow-hidden rounded-xl text-slate-900 dark:text-white focus:outline-0 focus:ring-2 focus:ring-primary/50 border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800/60 focus:border-primary h-14 placeholder:text-slate-400 dark:placeholder:text-slate-500 p-4 text-base font-normal leading-normal" 
                placeholder="000000000" 
                value={routingNumber}
                onChange={(e) => setRoutingNumber(e.target.value)}
              />
            </label>
            <label className="flex flex-col w-full">
              <p className="text-slate-900 dark:text-white text-base font-medium leading-normal pb-2">Account Number</p>
              <input 
                className="flex w-full min-w-0 flex-1 resize-none overflow-hidden rounded-xl text-slate-900 dark:text-white focus:outline-0 focus:ring-2 focus:ring-primary/50 border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800/60 focus:border-primary h-14 placeholder:text-slate-400 dark:placeholder:text-slate-500 p-4 text-base font-normal leading-normal" 
                placeholder="0000000000" 
                value={accountNumber}
                onChange={(e) => setAccountNumber(e.target.value)}
              />
            </label>
             <label className="flex flex-col w-full">
              <p className="text-slate-900 dark:text-white text-base font-medium leading-normal pb-2">Bank Name</p>
              <input 
                className="flex w-full min-w-0 flex-1 resize-none overflow-hidden rounded-xl text-slate-900 dark:text-white focus:outline-0 focus:ring-2 focus:ring-primary/50 border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800/60 focus:border-primary h-14 placeholder:text-slate-400 dark:placeholder:text-slate-500 p-4 text-base font-normal leading-normal" 
                placeholder="e.g. Chase" 
                value={bankName}
                onChange={(e) => setBankName(e.target.value)}
              />
            </label>
           </div>
        )}

        {paymentType === 'PayPal' && (
           <div className="flex flex-col gap-4 animate-fade-in">
             <div className="flex flex-col items-center justify-center p-6 bg-slate-100 dark:bg-slate-800 rounded-xl mb-4">
               <span className="material-symbols-outlined text-4xl text-blue-600 mb-2">payments</span>
               <p className="text-center text-sm text-slate-500">You will be redirected to PayPal to verify your account after saving.</p>
             </div>
             <label className="flex flex-col w-full">
              <p className="text-slate-900 dark:text-white text-base font-medium leading-normal pb-2">PayPal Email</p>
              <input 
                className="flex w-full min-w-0 flex-1 resize-none overflow-hidden rounded-xl text-slate-900 dark:text-white focus:outline-0 focus:ring-2 focus:ring-primary/50 border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800/60 focus:border-primary h-14 placeholder:text-slate-400 dark:placeholder:text-slate-500 p-4 text-base font-normal leading-normal" 
                placeholder="your.email@example.com" 
                type="email"
                value={paypalEmail}
                onChange={(e) => setPaypalEmail(e.target.value)}
              />
            </label>
           </div>
        )}

        <div className="flex items-center mt-6">
          <button 
            role="switch" 
            type="button"
            aria-checked={isDefault}
            onClick={() => setIsDefault(!isDefault)}
            className={`relative inline-flex h-6 w-11 flex-shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${isDefault ? 'bg-primary' : 'bg-slate-200 dark:bg-slate-700'}`}
          >
            <span 
              aria-hidden="true" 
              className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${isDefault ? 'translate-x-5' : 'translate-x-0'}`}
            ></span>
          </button>
          <label className="ml-3 text-sm text-slate-700 dark:text-slate-300 cursor-pointer" onClick={() => setIsDefault(!isDefault)}>
             Set as default payment method
          </label>
        </div>
      </main>

      {/* Footer */}
      <footer className="fixed bottom-0 left-0 right-0 max-w-lg mx-auto bg-background-light dark:bg-background-dark p-4 pt-2 border-t border-transparent dark:border-slate-800/50 backdrop-blur-sm">
        <div className="flex flex-col items-center gap-3">
          <p className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400 text-center">
            <span className="material-symbols-outlined text-base">lock</span>
            Your information is encrypted and secure
          </p>
          <button 
            onClick={handleSave}
            className="flex h-14 w-full items-center justify-center rounded-xl bg-primary px-6 text-base font-bold text-white shadow-lg shadow-primary/20 transition-all hover:bg-primary/90 active:scale-[0.98]"
          >
            {paymentType === 'Card' ? 'Add Card' : 'Save Method'}
          </button>
        </div>
      </footer>
    </div>
  );
};

export default AddPaymentMethodScreen;
