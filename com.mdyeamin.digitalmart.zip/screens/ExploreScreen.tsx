
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useApp } from '../context/AppContext';

const ExploreScreen: React.FC = () => {
  const navigate = useNavigate();
  const { templates } = useApp();
  const [searchTerm, setSearchTerm] = useState('');
  const [activeCategory, setActiveCategory] = useState('All');

  // Filter States
  const [activeFilterDropdown, setActiveFilterDropdown] = useState<string | null>(null);
  const [selectedPrice, setSelectedPrice] = useState<string | null>(null);
  const [selectedRating, setSelectedRating] = useState<number | null>(null);
  const [selectedFileType, setSelectedFileType] = useState<string | null>(null);

  const categories = ['All', 'Websites', 'Presentations', 'Social', 'Mobile', 'UI Kits'];
  
  // Filter Options
  const priceOptions = ['Under $20', '$20 - $50', '$50+'];
  const ratingOptions = [4.5, 4.0, 3.0];
  const fileTypeOptions = ['Figma', 'Sketch', 'HTML', 'React'];

  const toggleFilterDropdown = (filterName: string) => {
    if (activeFilterDropdown === filterName) {
      setActiveFilterDropdown(null);
    } else {
      setActiveFilterDropdown(filterName);
    }
  };

  const filteredTemplates = templates.filter(t => {
    // 1. Search
    const matchesSearch = t.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          t.creator.name.toLowerCase().includes(searchTerm.toLowerCase());
    
    // 2. Category
    const matchesCategory = activeCategory === 'All' || t.category === activeCategory;

    // 3. Price Filter
    let matchesPrice = true;
    if (selectedPrice === 'Under $20') matchesPrice = t.price < 20;
    else if (selectedPrice === '$20 - $50') matchesPrice = t.price >= 20 && t.price <= 50;
    else if (selectedPrice === '$50+') matchesPrice = t.price > 50;

    // 4. Rating Filter
    let matchesRating = true;
    if (selectedRating !== null) matchesRating = t.rating >= selectedRating;

    // 5. File Type Filter (Mock logic: checking description or title for keywords)
    let matchesFileType = true;
    if (selectedFileType) {
      const content = (t.description + t.title + t.category).toLowerCase();
      // Since mock data doesn't have a specific fileType field, we simulate it
      // In a real app, you'd check t.fileTypes.includes(selectedFileType)
      // For demo purposes, we'll assume most UI kits are Figma/Sketch
      if (selectedFileType === 'Figma' || selectedFileType === 'Sketch') {
         // Allow most design categories to pass for demo if specific keyword missing
         matchesFileType = true; 
      } else {
         matchesFileType = content.includes(selectedFileType.toLowerCase());
      }
    }

    return matchesSearch && matchesCategory && matchesPrice && matchesRating && matchesFileType;
  });

  // Logic for Trending Templates (sorted by sales)
  const trendingTemplates = [...templates].sort((a, b) => b.sales - a.sales).slice(0, 5);

  return (
    <div className="flex flex-col min-h-screen bg-background-light dark:bg-background-dark font-display pb-24">
      {/* Header */}
      <div className="flex items-center justify-between p-4 sticky top-0 z-10 bg-background-light/95 dark:bg-background-dark/95 backdrop-blur-sm">
        <div className="w-6"></div> {/* Spacer for centering */}
        <h1 className="text-lg font-bold text-slate-900 dark:text-white">Explore</h1>
        <button 
          onClick={() => {
            // Reset all filters
            setSearchTerm('');
            setActiveCategory('All');
            setSelectedPrice(null);
            setSelectedRating(null);
            setSelectedFileType(null);
            setActiveFilterDropdown(null);
          }}
          className="text-slate-900 dark:text-white"
        >
          <span className="material-symbols-outlined">restart_alt</span>
        </button>
      </div>

      {/* Search Bar */}
      <div className="px-4 mb-3">
        <div className="relative">
          <div className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400">
            <span className="material-symbols-outlined">search</span>
          </div>
          <input 
            className="w-full bg-slate-200 dark:bg-[#1b2227] h-12 pl-12 pr-4 rounded-xl text-slate-900 dark:text-white placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-primary/50 transition-shadow"
            placeholder="Search templates..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
      </div>

      {/* Search Filters Row */}
      <div className="flex gap-2 px-4 mb-2 overflow-x-auto no-scrollbar">
        {/* Price Filter Button */}
        <button 
          onClick={() => toggleFilterDropdown('Price')}
          className={`flex items-center gap-1 h-9 px-4 rounded-full border text-xs font-medium whitespace-nowrap transition-colors ${
            selectedPrice || activeFilterDropdown === 'Price'
              ? 'bg-primary border-primary text-white'
              : 'bg-slate-200 dark:bg-[#1b2227] border-transparent dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-300 dark:hover:bg-slate-700'
          }`}
        >
          <span>{selectedPrice || 'Price Range'}</span>
          <span className="material-symbols-outlined text-[16px]">{activeFilterDropdown === 'Price' ? 'expand_less' : 'expand_more'}</span>
        </button>

        {/* Rating Filter Button */}
        <button 
          onClick={() => toggleFilterDropdown('Rating')}
          className={`flex items-center gap-1 h-9 px-4 rounded-full border text-xs font-medium whitespace-nowrap transition-colors ${
            selectedRating || activeFilterDropdown === 'Rating'
              ? 'bg-primary border-primary text-white'
              : 'bg-slate-200 dark:bg-[#1b2227] border-transparent dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-300 dark:hover:bg-slate-700'
          }`}
        >
          <span>{selectedRating ? `${selectedRating}+ Stars` : 'Rating'}</span>
          <span className="material-symbols-outlined text-[16px]">{activeFilterDropdown === 'Rating' ? 'expand_less' : 'expand_more'}</span>
        </button>

        {/* File Type Filter Button */}
        <button 
          onClick={() => toggleFilterDropdown('FileType')}
          className={`flex items-center gap-1 h-9 px-4 rounded-full border text-xs font-medium whitespace-nowrap transition-colors ${
            selectedFileType || activeFilterDropdown === 'FileType'
              ? 'bg-primary border-primary text-white'
              : 'bg-slate-200 dark:bg-[#1b2227] border-transparent dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-300 dark:hover:bg-slate-700'
          }`}
        >
          <span>{selectedFileType || 'File Type'}</span>
          <span className="material-symbols-outlined text-[16px]">{activeFilterDropdown === 'FileType' ? 'expand_less' : 'expand_more'}</span>
        </button>
      </div>

      {/* Expanded Filter Options (Conditionally Rendered) */}
      {activeFilterDropdown && (
        <div className="px-4 mb-4 animate-fade-in">
          <div className="bg-slate-100 dark:bg-slate-800/50 rounded-xl p-3 flex flex-wrap gap-2">
            
            {activeFilterDropdown === 'Price' && priceOptions.map(option => (
              <button
                key={option}
                onClick={() => {
                  setSelectedPrice(selectedPrice === option ? null : option);
                  setActiveFilterDropdown(null);
                }}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-colors ${
                  selectedPrice === option
                    ? 'bg-primary text-white shadow-sm'
                    : 'bg-white dark:bg-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-600'
                }`}
              >
                {option}
              </button>
            ))}

            {activeFilterDropdown === 'Rating' && ratingOptions.map(option => (
              <button
                key={option}
                onClick={() => {
                  setSelectedRating(selectedRating === option ? null : option);
                  setActiveFilterDropdown(null);
                }}
                className={`flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-bold transition-colors ${
                  selectedRating === option
                    ? 'bg-primary text-white shadow-sm'
                    : 'bg-white dark:bg-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-600'
                }`}
              >
                <span>{option}+</span>
                <span className="material-symbols-outlined text-[14px] filled">star</span>
              </button>
            ))}

             {activeFilterDropdown === 'FileType' && fileTypeOptions.map(option => (
              <button
                key={option}
                onClick={() => {
                  setSelectedFileType(selectedFileType === option ? null : option);
                  setActiveFilterDropdown(null);
                }}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-colors ${
                  selectedFileType === option
                    ? 'bg-primary text-white shadow-sm'
                    : 'bg-white dark:bg-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-600'
                }`}
              >
                {option}
              </button>
            ))}

          </div>
        </div>
      )}

      <div className="h-4"></div>

      {/* Categories */}
      <div className="mb-8">
        <h2 className="px-4 text-base font-bold text-slate-900 dark:text-white mb-3">Categories</h2>
        <div className="flex gap-3 px-4 overflow-x-auto no-scrollbar">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`px-5 py-2 rounded-full text-sm font-semibold whitespace-nowrap transition-colors ${
                activeCategory === cat
                  ? 'bg-primary text-white'
                  : 'bg-slate-200 dark:bg-[#1b2227] text-slate-700 dark:text-slate-300 hover:bg-slate-300 dark:hover:bg-slate-700'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Curated Collections */}
      <div className="mb-8">
        <h2 className="px-4 text-base font-bold text-slate-900 dark:text-white mb-3">Curated Collections</h2>
        <div className="flex gap-4 px-4 overflow-x-auto no-scrollbar">
          {/* Trending Now Card */}
          <div 
            onClick={() => navigate('/trending')}
            className="min-w-[280px] h-40 rounded-2xl relative overflow-hidden group cursor-pointer"
          >
            <div 
              className="absolute inset-0 bg-cover bg-center transition-transform group-hover:scale-105"
              style={{ backgroundImage: 'url("https://images.unsplash.com/photo-1550684848-fac1c5b4e853?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80")' }} // Abstract Blue
            >
               <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent"></div>
            </div>
            <div className="absolute bottom-4 left-4">
              <h3 className="text-white font-bold text-lg">Best Sellers</h3>
            </div>
          </div>

          {/* New Arrivals Card */}
          <div className="min-w-[280px] h-40 rounded-2xl relative overflow-hidden group cursor-pointer">
             <div 
              className="absolute inset-0 bg-cover bg-center transition-transform group-hover:scale-105"
              style={{ backgroundImage: 'url("https://images.unsplash.com/photo-1541701494587-cb58502866ab?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80")' }} // Abstract Paint
            >
               <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent"></div>
            </div>
            <div className="absolute bottom-4 left-4">
              <h3 className="text-white font-bold text-lg">New Arrivals</h3>
            </div>
          </div>
        </div>
      </div>

      {/* Trending Templates Section (New) */}
      <div className="mb-8">
        <div className="flex items-center justify-between px-4 mb-3">
          <h2 className="text-base font-bold text-slate-900 dark:text-white">Trending Templates</h2>
          <button 
            onClick={() => navigate('/trending')}
            className="text-primary text-sm font-semibold"
          >
            See All
          </button>
        </div>
        <div className="flex gap-4 px-4 overflow-x-auto no-scrollbar pb-1">
          {trendingTemplates.map((item, index) => (
            <div 
              key={item.id} 
              onClick={() => navigate(`/details/${item.id}`)}
              className="min-w-[160px] group cursor-pointer"
            >
              <div className="relative w-full aspect-[3/4] rounded-2xl overflow-hidden mb-2 bg-slate-200 dark:bg-slate-800 border border-slate-200 dark:border-slate-800">
                  <div 
                    className="absolute inset-0 bg-cover bg-center transition-transform duration-500 group-hover:scale-110"
                    style={{ backgroundImage: `url("${item.thumbnail}")` }}
                  ></div>
                  <div className="absolute top-2 left-2 size-6 rounded-full bg-black/60 backdrop-blur-md flex items-center justify-center border border-white/10">
                    <span className="text-white text-xs font-bold">{index + 1}</span>
                  </div>
              </div>
              <h3 className="text-slate-900 dark:text-white font-bold text-sm truncate">{item.title}</h3>
              <p className="text-slate-500 dark:text-slate-400 text-xs mt-0.5">by {item.creator.name}</p>
              <div className="flex items-center justify-between mt-1">
                <span className="text-primary font-bold text-sm">${item.price.toFixed(2)}</span>
                <div className="flex items-center gap-0.5">
                   <span className="material-symbols-outlined text-yellow-400 text-[14px] filled">star</span>
                   <span className="text-xs font-bold text-slate-700 dark:text-slate-300">{item.rating}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Discover More Grid */}
      <div className="px-4">
        <h2 className="text-base font-bold text-slate-900 dark:text-white mb-4">Discover More</h2>
        
        <div className="grid grid-cols-2 gap-x-4 gap-y-6">
          {filteredTemplates.map((item) => (
            <div 
              key={item.id} 
              onClick={() => navigate(`/details/${item.id}`)}
              className="group cursor-pointer"
            >
              <div className="relative w-full aspect-[4/5] rounded-2xl overflow-hidden mb-3 bg-slate-200 dark:bg-slate-800 border border-slate-200 dark:border-slate-800">
                <div 
                  className="absolute inset-0 bg-cover bg-center transition-transform duration-500 group-hover:scale-110"
                  style={{ backgroundImage: `url("${item.thumbnail}")` }}
                ></div>
              </div>
              
              <h3 className="text-slate-900 dark:text-white font-bold text-sm truncate">{item.title}</h3>
              <p className="text-slate-500 dark:text-slate-400 text-xs mt-0.5">by {item.creator.name}</p>
              <p className="text-slate-900 dark:text-white font-bold text-sm mt-1">${item.price.toFixed(2)}</p>
            </div>
          ))}
        </div>
        
        {filteredTemplates.length === 0 && (
           <div className="text-center py-10 text-slate-500 dark:text-slate-400">
             No templates found matching your filters.
           </div>
        )}
      </div>
    </div>
  );
};

export default ExploreScreen;
