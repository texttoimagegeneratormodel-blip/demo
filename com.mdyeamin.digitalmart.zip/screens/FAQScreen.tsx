
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const FAQScreen: React.FC = () => {
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState('');
  const [activeCategory, setActiveCategory] = useState('All');

  const categories = ['All', 'Account', 'Payments', 'Buying', 'Selling', 'Security'];

  const faqs = [
    {
      question: "How do I reset my password?",
      answer: "You can reset your password by going to the 'Account' section in your profile settings. Click on 'Change Password' and follow the on-screen instructions. An email will be sent to you to complete the process.",
      category: "Account"
    },
    {
      question: "What payment methods are accepted?",
      answer: "We accept a variety of payment methods including major credit cards (Visa, MasterCard, American Express), PayPal, and Apple Pay for a secure and convenient checkout experience.",
      category: "Payments",
      isOpen: true
    },
    {
      question: "How do I upload a template?",
      answer: "To upload a template, navigate to the 'Sell' tab and click on 'Upload New Asset'. You will be guided through the process of adding your file, title, description, tags, and setting a price.",
      category: "Selling"
    },
    {
      question: "Where can I see my purchase history?",
      answer: "Your complete purchase history is available in your account dashboard under the 'Purchases' section. You can view all your bought templates and re-download them from there.",
      category: "Buying"
    },
    {
      question: "Is my payment information secure?",
      answer: "Absolutely. We use industry-standard encryption and partner with trusted payment gateways to ensure your financial information is always protected and secure.",
      category: "Security"
    }
  ];

  const filteredFaqs = faqs.filter(faq => {
    const matchesSearch = faq.question.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          faq.answer.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = activeCategory === 'All' || faq.category === activeCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="relative flex h-auto min-h-screen w-full flex-col overflow-x-hidden bg-background-light dark:bg-background-dark font-display">
      {/* Top App Bar */}
      <div className="flex items-center bg-background-light dark:bg-background-dark p-4 pb-2 justify-between sticky top-0 z-10">
        <button 
          onClick={() => navigate('/help-support')}
          className="text-slate-800 dark:text-white flex size-12 shrink-0 items-center justify-start cursor-pointer hover:text-primary transition-colors"
        >
          <span className="material-symbols-outlined">arrow_back_ios_new</span>
        </button>
        <h1 className="text-slate-900 dark:text-white text-lg font-bold leading-tight tracking-[-0.015em] flex-1 text-center">Help Center</h1>
        <div className="flex size-12 shrink-0 items-center"></div> {/* Spacer */}
      </div>

      {/* Search Bar */}
      <div className="px-4 py-3">
        <label className="flex flex-col min-w-40 h-12 w-full">
          <div className="flex w-full flex-1 items-stretch rounded-lg h-full">
            <div className="text-slate-400 dark:text-[#9cadba] flex border-none bg-slate-200 dark:bg-[#283239] items-center justify-center pl-4 rounded-l-lg border-r-0">
              <span className="material-symbols-outlined">search</span>
            </div>
            <input 
              className="form-input flex w-full min-w-0 flex-1 resize-none overflow-hidden rounded-lg text-slate-900 dark:text-white focus:outline-0 focus:ring-0 border-none bg-slate-200 dark:bg-[#283239] focus:border-none h-full placeholder:text-slate-400 dark:placeholder:text-[#9cadba] px-4 rounded-l-none border-l-0 pl-2 text-base font-normal leading-normal" 
              placeholder="Search for questions..." 
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </label>
      </div>

      {/* Chips / Categories */}
      <div className="flex gap-3 px-4 py-3 overflow-x-auto no-scrollbar">
        {categories.map((cat) => (
          <button 
            key={cat}
            onClick={() => setActiveCategory(cat)}
            className={`flex h-8 shrink-0 items-center justify-center gap-x-2 rounded-full pl-4 pr-4 transition-colors ${
              activeCategory === cat 
                ? 'bg-primary' 
                : 'bg-slate-200 dark:bg-[#283239]'
            }`}
          >
            <p className={`text-sm font-medium leading-normal ${
              activeCategory === cat 
                ? 'text-white' 
                : 'text-slate-800 dark:text-white'
            }`}>
              {cat}
            </p>
          </button>
        ))}
      </div>

      {/* Accordions */}
      <div className="flex flex-col p-4 min-h-[50vh]">
        {filteredFaqs.length > 0 ? (
          filteredFaqs.map((faq, index) => (
            <details 
              key={index} 
              className="flex flex-col border-b border-b-slate-200 dark:border-b-[#3b4a54] py-2 group" 
              open={faq.isOpen}
            >
              <summary className="flex cursor-pointer list-none items-center justify-between gap-6 py-2">
                <p className="text-slate-800 dark:text-white text-base font-medium leading-normal">{faq.question}</p>
                <div className="text-slate-500 dark:text-white transition-transform duration-300 group-open:rotate-180">
                  <span className="material-symbols-outlined">expand_more</span>
                </div>
              </summary>
              <p className="text-slate-600 dark:text-[#9cadba] text-sm font-normal leading-normal pb-2 pt-1 pr-6 animate-fade-in">
                {faq.answer}
              </p>
            </details>
          ))
        ) : (
          <div className="flex flex-col items-center justify-center py-10 text-slate-500 dark:text-[#9cadba]">
            <span className="material-symbols-outlined text-4xl mb-2">search_off</span>
            <p>No answers found.</p>
          </div>
        )}
      </div>

      {/* Contact CTA */}
      <div className="flex flex-col items-center justify-center p-4 pt-8 pb-10">
        <p className="text-slate-600 dark:text-[#9cadba] text-base font-normal leading-normal pb-3 pt-1 text-center">Can't find an answer?</p>
        <button 
          onClick={() => navigate('/contact-us')}
          className="flex h-12 w-full max-w-sm items-center justify-center gap-x-2 rounded-lg bg-primary px-6 shadow-lg shadow-primary/25 hover:bg-primary/90 transition-transform active:scale-[0.98]"
        >
          <p className="text-white text-base font-medium leading-normal">Contact Us</p>
        </button>
      </div>
    </div>
  );
};

export default FAQScreen;
