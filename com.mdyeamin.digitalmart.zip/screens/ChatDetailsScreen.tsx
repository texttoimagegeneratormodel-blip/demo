
import React, { useState, useRef, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useApp } from '../context/AppContext';

interface Message {
  id: number;
  text: string;
  sender: 'me' | 'other' | 'system';
  time?: string;
  isRead?: boolean;
  audioUrl?: string;
}

const ChatDetailsScreen: React.FC = () => {
  const navigate = useNavigate();
  const { id } = useParams();
  const { creators, showToast } = useApp();
  const creator = creators.find(c => c.id === id);

  const [message, setMessage] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const [showOptions, setShowOptions] = useState(false);
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);

  // Initial mock messages
  const [messages, setMessages] = useState<Message[]>([
    { 
      id: 1, 
      text: "Hi, I'm interested in your template. Is it still updated?", 
      sender: 'me',
      time: '10:00 AM'
    },
    { 
      id: 2, 
      text: "Yes, absolutely! I update it monthly.", 
      sender: 'other',
      time: '10:15 AM'
    },
  ]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isRecording]);

  const handleAttachClick = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const newMessage: Message = {
        id: Date.now(),
        text: `Sent a file: ${file.name}`,
        sender: 'me',
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        isRead: true
      };
      setMessages(prev => [...prev, newMessage]);
      e.target.value = '';
    }
  };

  const handleSendMessage = () => {
    if (message.trim()) {
      const newMessage: Message = {
        id: Date.now(),
        text: message.trim(),
        sender: 'me',
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        isRead: true
      };
      setMessages(prev => [...prev, newMessage]);
      setMessage('');
      
      setTimeout(() => {
        const reply: Message = {
          id: Date.now() + 1,
          text: "Thanks for your message! I'll get back to you shortly.",
          sender: 'other',
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        };
        setMessages(prev => [...prev, reply]);
      }, 2000);
    }
  };

  const startRecording = async () => {
    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        throw new Error("Media Devices API not supported.");
      }

      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      audioChunksRef.current = [];

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };

      mediaRecorder.onstop = () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
        const audioUrl = URL.createObjectURL(audioBlob);
        
        const newMessage: Message = {
          id: Date.now(),
          text: 'Voice Message',
          audioUrl: audioUrl,
          sender: 'me',
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          isRead: true
        };
        setMessages(prev => [...prev, newMessage]);

        stream.getTracks().forEach(track => track.stop());
      };

      mediaRecorder.start();
      setIsRecording(true);
    } catch (error) {
      console.error("Error accessing microphone:", error);
      setIsRecording(true);
      mediaRecorderRef.current = null; 
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
    } else if (isRecording) {
      setIsRecording(false);
      const audioBlob = new Blob([], { type: 'audio/webm' });
      const audioUrl = URL.createObjectURL(audioBlob);

      const newMessage: Message = {
        id: Date.now(),
        text: 'Voice Message (Simulated)',
        audioUrl: audioUrl,
        sender: 'me',
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        isRead: true
      };
      setMessages(prev => [...prev, newMessage]);
    }
  };

  const handleVoiceToggle = () => {
    if (isRecording) {
      stopRecording();
    } else {
      startRecording();
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      handleSendMessage();
    }
  };

  // Menu Handlers
  const handleViewProfile = () => {
    setShowOptions(false);
    if (creator) {
      navigate(`/creator/${creator.id}`);
    }
  };

  const handleMute = () => {
    setShowOptions(false);
    showToast('Notifications muted for this chat.', 'info');
  };

  const handleBlock = () => {
    setShowOptions(false);
    showToast(`You have blocked ${creatorName}.`, 'info');
    navigate('/messages');
  };

  const handleDelete = () => {
    setShowOptions(false);
    const confirm = window.confirm("Are you sure you want to delete this conversation?");
    if (confirm) {
      showToast('Conversation deleted.', 'info');
      navigate('/messages');
    }
  };
  
  const creatorName = creator ? creator.name : 'Support';
  const creatorAvatar = creator ? creator.avatar : 'https://via.placeholder.com/150';

  return (
    <div className="relative flex h-screen w-full flex-col group/design-root overflow-hidden bg-background-light dark:bg-background-dark font-display">
      {/* Top App Bar */}
      <div className="sticky top-0 z-10 flex items-center justify-between border-b border-white/10 bg-background-light dark:bg-background-dark p-4 shadow-sm">
        <button 
          onClick={() => navigate('/messages')}
          className="flex size-10 shrink-0 items-center justify-center text-zinc-900 dark:text-white hover:bg-zinc-100 dark:hover:bg-zinc-800 rounded-full transition-colors cursor-pointer"
        >
          <span className="material-symbols-outlined text-2xl">arrow_back_ios_new</span>
        </button>
        <div className="flex flex-1 items-center justify-center gap-3">
          <div 
            className="bg-center bg-no-repeat aspect-square bg-cover rounded-full w-10 shrink-0" 
            style={{ backgroundImage: `url("${creatorAvatar}")` }}
          ></div>
          <div className="flex flex-col text-center">
            <h2 className="text-zinc-900 dark:text-white text-lg font-bold leading-tight tracking-[-0.015em]">{creatorName}</h2>
            <p className="text-sm text-zinc-600 dark:text-zinc-400">Online</p>
          </div>
        </div>
        <div className="flex w-10 shrink-0 items-center justify-end">
          <button 
            onClick={() => setShowOptions(true)}
            className="flex h-10 w-10 cursor-pointer items-center justify-center overflow-hidden rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors text-zinc-900 dark:text-white"
          >
            <span className="material-symbols-outlined text-2xl">more_vert</span>
          </button>
        </div>
      </div>

      {/* Chat Area */}
      <div className="flex-1 overflow-y-auto p-4">
        <div className="flex flex-col gap-4">
          <div className="flex justify-center my-2">
            <span className="rounded-full bg-zinc-200 dark:bg-zinc-800 px-3 py-1 text-xs font-medium text-zinc-600 dark:text-zinc-400">Today</span>
          </div>
          
          {messages.map((msg) => {
            if (msg.sender === 'system') {
              return (
                <div key={msg.id} className="flex justify-center my-2 animate-fade-in">
                  <div className="flex items-center gap-2 rounded-lg bg-primary/10 px-3 py-2 text-xs font-medium text-primary dark:text-primary">
                    <span className="material-symbols-outlined text-base">shopping_bag</span>
                    <span>{msg.text}</span>
                  </div>
                </div>
              );
            }

            if (msg.sender === 'other') {
              return (
                <div key={msg.id} className="flex items-end gap-3 animate-fade-in">
                  <div 
                    className="bg-center bg-no-repeat aspect-square bg-cover rounded-full w-8 h-8 shrink-0" 
                    style={{ backgroundImage: `url("${creatorAvatar}")` }}
                  ></div>
                  <div className="flex flex-1 flex-col gap-1 items-start">
                    <p className="text-base font-normal leading-normal flex max-w-[80%] rounded-xl rounded-bl-sm px-4 py-3 bg-zinc-200 dark:bg-zinc-800 text-zinc-900 dark:text-white">
                      {msg.text}
                    </p>
                    {msg.time && (
                      <p className="text-zinc-500 dark:text-zinc-400 text-xs font-normal ml-1">{msg.time}</p>
                    )}
                  </div>
                </div>
              );
            }

            // Sender is 'me'
            return (
              <div key={msg.id} className="flex items-end gap-3 justify-end animate-fade-in">
                <div className="flex flex-1 flex-col gap-1 items-end">
                  {msg.audioUrl ? (
                    <div className="flex max-w-[80%] rounded-xl rounded-br-sm px-3 py-2 bg-primary text-white items-center">
                      <audio controls src={msg.audioUrl} className="h-8 w-48 [&::-webkit-media-controls-panel]:bg-primary [&::-webkit-media-controls-current-time-display]:text-white [&::-webkit-media-controls-time-remaining-display]:text-white" />
                    </div>
                  ) : (
                    <p className="text-base font-normal leading-normal flex max-w-[80%] rounded-xl rounded-br-sm px-4 py-3 bg-primary text-white">
                      {msg.text}
                    </p>
                  )}
                  <div className="flex items-center gap-1">
                    {msg.time && (
                      <p className="text-zinc-500 dark:text-zinc-400 text-xs font-normal">{msg.time}</p>
                    )}
                    {msg.isRead && (
                      <span className="material-symbols-outlined text-base text-primary filled">done_all</span>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
          <div ref={messagesEndRef} />
        </div>
      </div>

      {/* Input Area */}
      <div className="sticky bottom-0 flex items-center px-4 py-3 gap-3 border-t border-white/10 bg-background-light dark:bg-background-dark">
        <button 
          onClick={handleAttachClick}
          disabled={isRecording}
          className={`flex h-10 w-10 min-w-10 items-center justify-center rounded-full bg-zinc-200 dark:bg-zinc-800 text-zinc-600 dark:text-zinc-300 hover:bg-zinc-300 dark:hover:bg-zinc-700 transition-colors ${isRecording ? 'opacity-50 cursor-not-allowed' : ''}`}
        >
          <span className="material-symbols-outlined">add</span>
        </button>
        <input 
          type="file" 
          ref={fileInputRef} 
          onChange={handleFileChange} 
          className="hidden" 
        />

        <label className="flex flex-col min-w-40 h-11 flex-1">
          <div className={`flex w-full flex-1 items-stretch rounded-full h-full bg-zinc-200 dark:bg-zinc-800 focus-within:ring-2 focus-within:ring-primary/50 transition-all ${isRecording ? 'ring-2 ring-red-500/50 bg-red-50 dark:bg-red-900/10' : ''}`}>
            {isRecording ? (
               <div className="flex w-full min-w-0 flex-1 items-center px-4">
                 <div className="h-2 w-2 rounded-full bg-red-500 animate-pulse mr-2"></div>
                 <span className="text-red-500 font-medium text-sm">Recording...</span>
               </div>
            ) : (
              <input 
                className="flex w-full min-w-0 flex-1 resize-none overflow-hidden rounded-l-full text-zinc-900 dark:text-white border-none bg-transparent h-full placeholder:text-zinc-500 dark:placeholder:text-zinc-400 px-4 text-base font-normal leading-normal focus:outline-0 focus:ring-0" 
                placeholder="Type a message..." 
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                onKeyDown={handleKeyDown}
                disabled={isRecording}
              />
            )}
            <button 
              onClick={handleVoiceToggle}
              className={`flex w-12 items-center justify-center rounded-r-full transition-colors ${isRecording ? 'text-red-500 hover:text-red-600' : 'text-zinc-600 dark:text-zinc-300 hover:text-zinc-900 dark:hover:text-white'}`}
            >
              <span className={`material-symbols-outlined ${isRecording ? 'filled' : ''}`}>
                {isRecording ? 'stop_circle' : 'mic'}
              </span>
            </button>
          </div>
        </label>

        <button 
          onClick={handleSendMessage}
          disabled={!message.trim() || isRecording}
          className={`flex h-10 w-10 min-w-10 cursor-pointer items-center justify-center overflow-hidden rounded-full bg-primary text-white transition-all active:scale-95 ${!message.trim() || isRecording ? 'opacity-50 cursor-not-allowed' : 'hover:bg-primary/90'}`}
        >
          <span className="material-symbols-outlined">send</span>
        </button>
      </div>

      {/* Options Menu Bottom Sheet */}
      {showOptions && (
        <div className="fixed inset-0 z-50 flex flex-col justify-end">
          <div 
            className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            onClick={() => setShowOptions(false)}
          ></div>
          <div className="relative bg-white dark:bg-[#1C1C1E] rounded-t-3xl p-4 animate-slide-up flex flex-col gap-2 pb-8 shadow-2xl">
            <div className="w-12 h-1.5 bg-slate-300 dark:bg-slate-700 rounded-full mx-auto mb-4"></div>
            
            <button 
              onClick={handleViewProfile} 
              className="flex items-center gap-4 p-4 rounded-2xl hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors text-slate-900 dark:text-white font-bold text-left"
            >
              <div className="size-10 rounded-full bg-slate-100 dark:bg-slate-700 flex items-center justify-center">
                 <span className="material-symbols-outlined">person</span>
              </div>
              <span className="text-base">View Profile</span>
            </button>

            <button 
              onClick={handleMute} 
              className="flex items-center gap-4 p-4 rounded-2xl hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors text-slate-900 dark:text-white font-bold text-left"
            >
              <div className="size-10 rounded-full bg-slate-100 dark:bg-slate-700 flex items-center justify-center">
                 <span className="material-symbols-outlined">notifications_off</span>
              </div>
              <span className="text-base">Mute Notifications</span>
            </button>

            <button 
              onClick={handleBlock} 
              className="flex items-center gap-4 p-4 rounded-2xl hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors text-slate-900 dark:text-white font-bold text-left"
            >
              <div className="size-10 rounded-full bg-slate-100 dark:bg-slate-700 flex items-center justify-center">
                 <span className="material-symbols-outlined">block</span>
              </div>
              <span className="text-base">Block User</span>
            </button>

            <button 
              onClick={handleDelete} 
              className="flex items-center gap-4 p-4 rounded-2xl hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors text-red-500 font-bold text-left"
            >
              <div className="size-10 rounded-full bg-red-50 dark:bg-red-900/20 flex items-center justify-center">
                 <span className="material-symbols-outlined">delete</span>
              </div>
              <span className="text-base">Delete Conversation</span>
            </button>
            
            <div className="h-px bg-slate-200 dark:bg-slate-800 my-2 mx-4"></div>
            
            <button 
              onClick={() => setShowOptions(false)}
              className="p-4 rounded-2xl bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-white font-bold text-center mt-2"
            >
              Cancel
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default ChatDetailsScreen;
