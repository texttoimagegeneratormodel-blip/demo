
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useApp } from '../context/AppContext';

const MessagesScreen: React.FC = () => {
  const navigate = useNavigate();
  const { creators } = useApp();
  const [searchTerm, setSearchTerm] = useState('');

  // Generate conversations from creators data for demonstration
  const conversations = creators.map((creator, index) => ({
    id: creator.id,
    name: creator.name,
    avatar: creator.avatar,
    lastMessage: index === 0 ? 'Hey, just wanted to check in about the pack.' : 'Thanks for the update!',
    time: index === 0 ? '10:45 AM' : 'Yesterday',
    unread: index === 0
  }));

  const filteredConversations = conversations.filter(c => 
    c.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
    c.lastMessage.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="flex flex-col min-h-screen bg-background-light dark:bg-background-dark font-display overflow-x-hidden">
      {/* Top App Bar */}
      <div className="flex flex-col gap-2 bg-background-light dark:bg-background-dark p-4 pb-2 sticky top-0 z-10">
        <div className="flex items-center h-12 justify-between">
          <div className="flex size-12 shrink-0 items-center">
             <button 
              onClick={() => navigate('/home')}
              className="flex items-center justify-center rounded-full bg-transparent hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors size-10 cursor-pointer"
             >
               <span className="material-symbols-outlined text-slate-900 dark:text-white">arrow_back_ios_new</span>
             </button>
          </div>
          <div className="flex w-12 items-center justify-end">
            <button className="flex max-w-[480px] cursor-pointer items-center justify-center overflow-hidden rounded-lg h-12 bg-transparent text-primary gap-2 text-base font-bold leading-normal tracking-[0.015em] min-w-0 p-0">
              <span className="material-symbols-outlined text-3xl">edit_square</span>
            </button>
          </div>
        </div>
        <p className="text-slate-900 dark:text-white tracking-light text-[28px] font-bold leading-tight">Messages</p>
      </div>

      {/* Search Bar */}
      <div className="px-4 py-3 bg-background-light dark:bg-background-dark sticky top-[104px] z-10">
        <label className="flex flex-col min-w-40 h-12 w-full">
          <div className="flex w-full flex-1 items-stretch rounded-lg h-full">
            <div className="text-slate-500 dark:text-[#9cadba] flex border-none bg-slate-200 dark:bg-[#283239] items-center justify-center pl-4 rounded-l-lg border-r-0">
              <span className="material-symbols-outlined">search</span>
            </div>
            <input 
              className="form-input flex w-full min-w-0 flex-1 resize-none overflow-hidden rounded-lg text-slate-900 dark:text-white focus:outline-0 focus:ring-0 border-none bg-slate-200 dark:bg-[#283239] focus:border-none h-full placeholder:text-slate-500 dark:placeholder:text-[#9cadba] px-4 rounded-l-none border-l-0 pl-2 text-base font-normal leading-normal" 
              placeholder="Search Conversations" 
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </label>
      </div>

      {/* Conversation List */}
      <div className="flex flex-col pb-24">
        {filteredConversations.map((convo) => (
          <div 
            key={convo.id} 
            className="flex items-center gap-4 bg-background-light dark:bg-background-dark px-4 min-h-[72px] py-2 justify-between cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors"
            onClick={() => navigate(`/messages/${convo.id}`)}
          >
            <div className="flex items-center gap-4 flex-grow">
              <div className="relative shrink-0">
                <div 
                  className="bg-center bg-no-repeat aspect-square bg-cover rounded-full h-14 w-14" 
                  style={{ backgroundImage: `url("${convo.avatar}")` }}
                ></div>
                {convo.unread && (
                    <div className="absolute bottom-0 right-0 h-3.5 w-3.5 bg-background-light dark:bg-background-dark rounded-full flex items-center justify-center">
                        <div className="h-2.5 w-2.5 bg-primary rounded-full"></div>
                    </div>
                )}
              </div>
              <div className="flex flex-col justify-center flex-grow min-w-0">
                <div className="flex items-center gap-2">
                  <p className={`text-slate-900 dark:text-white text-base leading-normal line-clamp-1 ${convo.unread ? 'font-bold' : 'font-medium'}`}>
                    {convo.name}
                  </p>
                </div>
                <p className={`text-sm leading-normal line-clamp-2 ${convo.unread ? 'text-slate-800 dark:text-slate-200 font-medium' : 'text-slate-500 dark:text-[#9cadba] font-normal'}`}>
                  {convo.lastMessage}
                </p>
              </div>
            </div>
            <div className="shrink-0 flex items-center gap-2">
              <p className="text-slate-500 dark:text-[#9cadba] text-sm font-normal leading-normal">{convo.time}</p>
              <span className="material-symbols-outlined text-slate-400 dark:text-slate-600 text-lg">chevron_right</span>
            </div>
          </div>
        ))}
        {filteredConversations.length === 0 && (
           <div className="flex flex-col items-center justify-center p-10 text-slate-500">
              <p>No conversations found.</p>
           </div>
        )}
      </div>
    </div>
  );
};

export default MessagesScreen;
