
import React from 'react';
import { useNavigate } from 'react-router-dom';

const BuySourceCodeScreen: React.FC = () => {
  const navigate = useNavigate();

  const features = [
    { title: "Complete Marketplace Logic", desc: "Browsing, searching, cart, wishlist, and checkout flows pre-built.", icon: "storefront" },
    { title: "Seller Dashboard", desc: "Dedicated interfaces for creators to upload assets, track sales, and view analytics.", icon: "dashboard" },
    { title: "Chat System", desc: "Real-time messaging UI with attachment support and audio recording simulation.", icon: "chat" },
    { title: "Premium UI/UX", desc: "World-class design with Dark Mode, smooth animations (Framer Motion style), and responsive layouts.", icon: "palette" },
    { title: "React & Tailwind CSS", desc: "Built with the latest modern web technologies for maximum performance and scalability.", icon: "code" },
    { title: "Mobile Optimized", desc: "Looks and feels like a native app on iOS and Android devices.", icon: "smartphone" }
  ];

  const handleWhatsApp = () => {
    window.open('https://wa.me/8801810211815', '_blank');
  };

  const handleEmail = () => {
    window.location.href = 'mailto:mdyeaminhossain718@gmail.com?subject=Purchase DigitalMart Source Code';
  };

  return (
    <div className="flex flex-col min-h-screen bg-background-light dark:bg-background-dark font-display pb-28">
      {/* Header */}
      <div className="sticky top-0 z-20 flex items-center justify-between p-4 bg-background-light/95 dark:bg-background-dark/95 backdrop-blur-md border-b border-slate-200 dark:border-slate-800">
        <button onClick={() => navigate(-1)} className="p-2 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors">
          <span className="material-symbols-outlined text-slate-900 dark:text-white">arrow_back</span>
        </button>
        <span className="font-bold text-lg text-slate-900 dark:text-white">Premium License</span>
        <div className="w-10"></div>
      </div>

      <div className="p-4 flex flex-col items-center text-center">
        <div className="size-20 bg-primary/10 rounded-3xl flex items-center justify-center mb-6 text-primary animate-fade-in">
          <span className="material-symbols-outlined text-5xl">rocket_launch</span>
        </div>

        <h1 className="text-3xl font-extrabold text-slate-900 dark:text-white leading-tight mb-3">
          Launch Your Own <br/> <span className="text-primary">Digital Marketplace</span>
        </h1>
        
        <p className="text-slate-600 dark:text-slate-300 text-base leading-relaxed max-w-sm mb-8">
          Stop building from scratch. Get the full source code of this production-ready application and launch your startup in days, not months.
        </p>

        {/* Pricing Card */}
        <div className="w-full bg-gradient-to-br from-slate-900 to-slate-800 dark:from-slate-800 dark:to-slate-900 text-white rounded-3xl p-8 shadow-2xl mb-10 relative overflow-hidden group">
          <div className="absolute top-0 right-0 bg-primary text-white text-xs font-bold px-3 py-1 rounded-bl-xl">LIMITED OFFER</div>
          <p className="text-slate-300 text-sm font-medium uppercase tracking-widest mb-2">Source Code License</p>
          <div className="flex items-baseline justify-center gap-1 mb-6">
            <span className="text-5xl font-bold">$399</span>
            <span className="text-slate-400 font-medium">USD</span>
          </div>
          <div className="flex flex-col gap-3">
            <button 
              onClick={handleWhatsApp}
              className="w-full bg-[#25D366] hover:bg-[#20bd5a] text-white font-bold py-3.5 rounded-xl flex items-center justify-center gap-2 transition-transform active:scale-95"
            >
              <span className="text-xl">📱</span> Buy via WhatsApp
            </button>
            <button 
              onClick={handleEmail}
              className="w-full bg-white/10 hover:bg-white/20 text-white font-bold py-3.5 rounded-xl flex items-center justify-center gap-2 transition-colors"
            >
              <span className="material-symbols-outlined">mail</span> Contact via Email
            </button>
          </div>
          <p className="text-xs text-slate-400 mt-4 opacity-80">Instant delivery upon payment confirmation.</p>
        </div>

        {/* Features Grid */}
        <div className="w-full text-left">
          <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-6 px-2">What You Get (A-Z)</h3>
          <div className="grid grid-cols-1 gap-4">
            {features.map((feat, idx) => (
              <div key={idx} className="bg-white dark:bg-slate-800/50 p-5 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm flex gap-4">
                <div className="size-12 rounded-xl bg-slate-100 dark:bg-slate-700 flex items-center justify-center text-primary shrink-0">
                  <span className="material-symbols-outlined">{feat.icon}</span>
                </div>
                <div>
                  <h4 className="font-bold text-slate-900 dark:text-white text-base mb-1">{feat.title}</h4>
                  <p className="text-sm text-slate-500 dark:text-slate-400 leading-relaxed">{feat.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Note */}
        <div className="mt-10 bg-orange-50 dark:bg-orange-900/10 p-6 rounded-2xl border border-orange-100 dark:border-orange-900/30">
          <div className="flex items-center gap-2 text-orange-600 dark:text-orange-400 font-bold mb-2">
            <span className="material-symbols-outlined">info</span>
            <span>Important Note</span>
          </div>
          <p className="text-sm text-slate-700 dark:text-slate-300 leading-relaxed text-left">
            This application is a <strong>Demo Version</strong> designed to showcase the quality of the code you will purchase. Payment gateways and backend endpoints are simulated to demonstrate the UI flows. You will receive the complete React/Typescript source code to connect to your own backend.
          </p>
        </div>

        {/* Contact Details Text */}
        <div className="mt-10 text-center">
          <p className="text-slate-500 dark:text-slate-400 text-sm mb-2">Direct Contact Support</p>
          <p className="text-slate-900 dark:text-white font-bold select-all">mdyeaminhossain718@gmail.com</p>
          <p className="text-slate-900 dark:text-white font-bold select-all mt-1">+880 1810 211 815</p>
        </div>
      </div>
    </div>
  );
};

export default BuySourceCodeScreen;
