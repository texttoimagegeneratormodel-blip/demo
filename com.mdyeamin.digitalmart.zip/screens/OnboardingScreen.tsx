
import React from 'react';
import { useNavigate } from 'react-router-dom';

const OnboardingScreen: React.FC = () => {
  const navigate = useNavigate();

  return (
    <div className="flex flex-col min-h-screen bg-background-light dark:bg-background-dark">
      <div className="flex-grow flex flex-col">
        <div className="p-4 pt-4">
          <div 
            className="w-full bg-center bg-no-repeat bg-cover flex flex-col justify-end overflow-hidden rounded-2xl min-h-[50vh] shadow-lg"
            style={{ backgroundImage: 'url("https://images.unsplash.com/photo-1600607686527-6fb886090705?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80")' }}
          >
            <div className="bg-gradient-to-t from-black/80 via-black/40 to-transparent p-6 h-full flex flex-col justify-end">
               <div className="bg-primary/20 backdrop-blur-md self-start px-3 py-1 rounded-lg border border-primary/30 mb-2">
                 <span className="text-white text-xs font-bold uppercase tracking-wider">Source Code For Sale</span>
               </div>
            </div>
          </div>
        </div>
        <div className="px-6 flex flex-col items-center text-center mt-4">
          <h1 className="text-slate-900 dark:text-white tracking-tight text-3xl font-extrabold leading-tight font-display mb-3">
            Start Your Digital <br/> <span className="text-primary">Marketplace Today</span>
          </h1>
          <p className="text-slate-600 dark:text-zinc-400 text-base font-normal leading-relaxed max-w-xs">
            Purchase this premium, production-ready React app template for just $399 and save months of development time.
          </p>
        </div>
      </div>
      <div className="p-6 pb-10 w-full flex flex-col gap-3">
        <button 
          onClick={() => navigate('/buy-code')}
          className="flex w-full items-center justify-center overflow-hidden rounded-xl h-14 px-6 bg-slate-900 dark:bg-white text-white dark:text-slate-900 text-base font-bold tracking-wide shadow-lg transition-transform active:scale-95"
        >
          Buy Source Code - $399
        </button>
        <button 
          onClick={() => navigate('/home')}
          className="flex w-full items-center justify-center overflow-hidden rounded-xl h-14 px-6 bg-transparent text-slate-500 dark:text-slate-400 text-base font-semibold tracking-wide transition-colors hover:text-slate-900 dark:hover:text-white"
        >
          Explore Demo App
        </button>
      </div>
    </div>
  );
};

export default OnboardingScreen;
