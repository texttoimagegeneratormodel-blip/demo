
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const TermsPrivacyScreen: React.FC = () => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<'Terms' | 'Privacy'>('Terms');

  const termsData = [
    {
      title: "1. Acceptance of Terms",
      content: "By downloading or using the DigitalMart app, these terms will automatically apply to you. You should make sure therefore that you read them carefully before using the app. This app is primarily a Source Code Template and Demo.",
      isOpen: true
    },
    {
      title: "2. Use of the App",
      content: "You are not allowed to copy or modify the app, any part of the app, or our trademarks in any way. You are not allowed to attempt to extract the source code of the app unless you have officially purchased the license from the developer."
    },
    {
      title: "3. Purchases & Source Code License",
      content: "The templates listed within this demo are for display purposes only. The 'Buy Source Code' option allows you to purchase the codebase of this application. No actual physical goods or other digital assets are delivered through the simulated checkout flow."
    },
    {
      title: "4. Intellectual Property Rights",
      content: "The Service and its original content (excluding user-provided content), features, and functionality are and will remain the exclusive property of Md Yeamin Hossain and DigitalMart. The source code is protected by copyright laws."
    },
    {
      title: "5. Disclaimer",
      content: "The app is provided on an 'AS IS' and 'AS AVAILABLE' basis. The developer accepts no liability for any loss, direct or indirect, you experience as a result of relying wholly on this functionality of the app."
    },
    {
      title: "6. Changes to Terms",
      content: "We may update our Terms and Conditions from time to time. Thus, you are advised to review this page periodically for any changes. These changes are effective immediately after they are posted on this page."
    },
    {
      title: "7. Contact Information",
      content: "If you have any questions or suggestions about our Terms and Conditions, do not hesitate to contact us at mdyeaminhossain718@gmail.com."
    }
  ];

  const privacyData = [
    {
      title: "1. Information Collection",
      content: "For a better experience, while using our Service, we may require you to provide us with certain personally identifiable information. Since this is a Demo App, any data entered (Email, Name, Password) is processed locally or for simulation purposes only and is not sold to third parties.",
      isOpen: true
    },
    {
      title: "2. Log Data",
      content: "We want to inform you that whenever you use our Service, in a case of an error in the app we collect data and information (through third-party products) on your phone called Log Data. This Log Data may include information such as your device IP address, device name, operating system version, and the time and date of your use of the Service."
    },
    {
      title: "3. Service Providers",
      content: "We may employ third-party companies and individuals due to the following reasons: To facilitate our Service; To provide the Service on our behalf; or To assist us in analyzing how our Service is used."
    },
    {
      title: "4. Security",
      content: "We value your trust in providing us your Personal Information, thus we are striving to use commercially acceptable means of protecting it. But remember that no method of transmission over the internet, or method of electronic storage is 100% secure and reliable."
    },
    {
      title: "5. Contact Us",
      content: "If you have any questions or suggestions about our Privacy Policy, do not hesitate to contact us at: mdyeaminhossain718@gmail.com or WhatsApp: +880 1810 211 815."
    }
  ];

  const currentData = activeTab === 'Terms' ? termsData : privacyData;

  return (
    <div className="relative flex h-auto min-h-screen w-full flex-col overflow-x-hidden bg-background-light dark:bg-background-dark font-display">
      {/* Top App Bar */}
      <div className="flex items-center bg-background-light dark:bg-background-dark p-4 pb-2 justify-between sticky top-0 z-10 border-b border-gray-200 dark:border-gray-700">
        <button 
          type="button"
          onClick={() => navigate('/settings')}
          className="text-primary dark:text-primary flex size-12 shrink-0 items-center justify-start cursor-pointer"
        >
          <span className="material-symbols-outlined">arrow_back_ios_new</span>
        </button>
        <h2 className="text-gray-900 dark:text-white text-lg font-bold leading-tight tracking-[-0.015em] flex-1 text-center">Legal</h2>
        <div className="flex w-12 items-center justify-end">
          <button 
            onClick={() => navigate('/settings')}
            className="text-primary dark:text-primary text-base font-bold leading-normal tracking-[0.015em] shrink-0"
          >
            Done
          </button>
        </div>
      </div>

      {/* Headline Text */}
      <h1 className="text-gray-900 dark:text-white tracking-tight text-[32px] font-bold leading-tight px-4 text-left pb-1 pt-6">
        Terms of Service & Privacy Policy
      </h1>

      {/* Meta Text */}
      <p className="text-gray-500 dark:text-gray-400 text-sm font-normal leading-normal pb-3 pt-1 px-4">
        Last Updated: October 26, 2023
      </p>

      {/* Segmented Buttons */}
      <div className="flex px-4 py-3 sticky top-[70px] z-10 bg-background-light dark:bg-background-dark">
        <div className="flex h-10 flex-1 items-center justify-center rounded-lg bg-gray-200 dark:bg-gray-800 p-1">
          <label className={`flex cursor-pointer h-full grow items-center justify-center overflow-hidden rounded-lg px-2 text-sm font-medium leading-normal transition-colors ${
            activeTab === 'Terms' 
              ? 'bg-white dark:bg-gray-700 shadow-sm text-gray-900 dark:text-white' 
              : 'text-gray-500 dark:text-gray-400'
          }`}>
            <span className="truncate">Terms of Service</span>
            <input 
              checked={activeTab === 'Terms'} 
              className="invisible w-0" 
              name="legal-section-toggle" 
              type="radio" 
              value="Terms of Service"
              onChange={() => setActiveTab('Terms')}
            />
          </label>
          <label className={`flex cursor-pointer h-full grow items-center justify-center overflow-hidden rounded-lg px-2 text-sm font-medium leading-normal transition-colors ${
            activeTab === 'Privacy' 
              ? 'bg-white dark:bg-gray-700 shadow-sm text-gray-900 dark:text-white' 
              : 'text-gray-500 dark:text-gray-400'
          }`}>
            <span className="truncate">Privacy Policy</span>
            <input 
              checked={activeTab === 'Privacy'}
              className="invisible w-0" 
              name="legal-section-toggle" 
              type="radio" 
              value="Privacy Policy"
              onChange={() => setActiveTab('Privacy')}
            />
          </label>
        </div>
      </div>

      {/* Accordions */}
      <div className="flex flex-col p-4 pb-10">
        {currentData.map((item, index) => (
          <details 
            key={index} 
            className={`flex flex-col py-2 group ${index === 0 ? 'border-t border-t-gray-200 dark:border-t-gray-700' : 'border-t border-t-gray-200 dark:border-t-gray-700'} ${index === currentData.length - 1 ? 'border-b border-b-gray-200 dark:border-b-gray-700' : ''}`}
            open={item.isOpen}
          >
            <summary className="flex cursor-pointer items-center justify-between gap-6 py-2 list-none">
              <p className="text-gray-900 dark:text-white text-base font-medium leading-normal">{item.title}</p>
              <div className="text-gray-400 dark:text-gray-500 group-open:rotate-180 transition-transform">
                <span className="material-symbols-outlined !text-2xl">expand_more</span>
              </div>
            </summary>
            <p className="text-gray-600 dark:text-gray-400 text-sm font-normal leading-relaxed pb-2 animate-fade-in">
              {item.content}
            </p>
          </details>
        ))}
      </div>
    </div>
  );
};

export default TermsPrivacyScreen;
