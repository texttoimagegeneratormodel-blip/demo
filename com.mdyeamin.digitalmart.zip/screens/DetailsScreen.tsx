
import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useApp } from '../context/AppContext';
import { Template, Review } from '../types';

const DetailsScreen: React.FC = () => {
  const navigate = useNavigate();
  const { id } = useParams();
  const { templates, addToCart, toggleWishlist, isInWishlist, showToast, toggleFollow, isFollowing, addReview, user } = useApp();
  const [activeImage, setActiveImage] = useState(0);
  const [template, setTemplate] = useState<Template | null>(null);
  
  // UI State
  const [showWriteReview, setShowWriteReview] = useState(false);
  const [showAllReviews, setShowAllReviews] = useState(false);
  const [ratingInput, setRatingInput] = useState(5);
  const [reviewTextInput, setReviewTextInput] = useState('');

  useEffect(() => {
    const found = templates.find(t => t.id === id);
    if (found) {
      setTemplate(found);
    }
  }, [id, templates]);

  if (!template) {
    return <div className="flex items-center justify-center min-h-screen text-slate-500">Loading...</div>;
  }

  const isWishlisted = isInWishlist(template.id);
  const isCreatorFollowed = isFollowing(template.creator.id);
  const relatedTemplates = templates.filter(t => t.category === template.category && t.id !== template.id).slice(0, 5);

  // Review Logic
  const reviews = template.reviews || [];
  const reviewCount = reviews.length;
  // Show only first 3 in the main view
  const visibleReviews = reviews.slice(0, 3);
  
  const calculatePercentage = (rating: number) => {
    if (reviewCount === 0) return 0;
    const count = reviews.filter(r => r.rating === rating).length;
    return (count / reviewCount) * 100;
  };

  const handleAddToCart = () => {
    addToCart(template);
  };

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: template.title,
          text: `Check out ${template.title} by ${template.creator.name} on DigitalMart!`,
          url: window.location.href,
        });
      } catch (error) {
        console.log('Error sharing:', error);
      }
    } else {
      navigator.clipboard.writeText(window.location.href);
      showToast('Link copied to clipboard');
    }
  };

  const handleChat = () => {
    navigate(`/messages/${template.creator.id}`);
  };

  const handleSubmitReview = () => {
    if (!user) {
      showToast('Please log in to write a review', 'error');
      navigate('/login');
      return;
    }
    if (!reviewTextInput.trim()) {
      showToast('Please enter a comment', 'info');
      return;
    }

    const newReview: Review = {
      id: Math.random().toString(36).substr(2, 9),
      user: user.name,
      avatar: user.avatar,
      rating: ratingInput,
      date: 'Just now',
      content: reviewTextInput
    };

    addReview(template.id, newReview);
    setShowWriteReview(false);
    setReviewTextInput('');
    setRatingInput(5);
  };

  return (
    <div className="flex flex-col min-h-screen bg-background-light dark:bg-background-dark pb-24 font-display">
      {/* Header */}
      <header className="fixed top-0 left-0 right-0 z-40 flex items-center justify-between p-4 bg-gradient-to-b from-black/50 to-transparent pointer-events-none">
        <button 
          type="button"
          onClick={() => navigate('/home')}
          className="pointer-events-auto size-10 flex items-center justify-center rounded-full bg-white/20 backdrop-blur-md text-white hover:bg-white/30 transition-colors cursor-pointer"
        >
          <span className="material-symbols-outlined pl-1">arrow_back_ios_new</span>
        </button>
        <div className="flex gap-3 pointer-events-auto">
          <button 
            onClick={handleShare}
            className="size-10 flex items-center justify-center rounded-full bg-white/20 backdrop-blur-md text-white hover:bg-white/30 transition-colors"
          >
            <span className="material-symbols-outlined">ios_share</span>
          </button>
          <button 
            onClick={() => toggleWishlist(template.id)}
            className={`size-10 flex items-center justify-center rounded-full backdrop-blur-md transition-colors ${isWishlisted ? 'bg-red-500 text-white' : 'bg-white/20 text-white hover:bg-white/30'}`}
          >
            <span className={`material-symbols-outlined ${isWishlisted ? 'filled' : ''}`}>favorite</span>
          </button>
        </div>
      </header>

      {/* Image Carousel */}
      <div className="w-full h-[45vh] relative bg-slate-200 dark:bg-slate-800">
        <div 
          className="w-full h-full bg-cover bg-center transition-all duration-500"
          style={{ backgroundImage: `url("${template.images[activeImage]}")` }}
        ></div>
        <div className="absolute bottom-4 left-0 right-0 flex justify-center gap-2">
          {template.images.map((_, idx) => (
            <button 
              key={idx}
              onClick={() => setActiveImage(idx)}
              className={`h-1.5 rounded-full transition-all shadow-sm ${idx === activeImage ? 'w-6 bg-white' : 'w-1.5 bg-white/50 hover:bg-white/80'}`}
            />
          ))}
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 -mt-6 bg-background-light dark:bg-background-dark rounded-t-3xl px-6 pt-8 z-10 relative shadow-[0_-4px_20px_rgba(0,0,0,0.1)]">
        <div className="flex justify-between items-start mb-2">
           <h1 className="text-2xl font-bold text-slate-900 dark:text-white leading-tight max-w-[75%]">{template.title}</h1>
           <div className="flex flex-col items-end">
             <span className="text-2xl font-bold text-primary">${template.price.toFixed(2)}</span>
           </div>
        </div>

        {/* Creator */}
        <div className="flex items-center gap-3 py-4 border-b border-slate-200 dark:border-slate-800">
          <div 
            onClick={() => navigate(`/creator/${template.creator.id}`)}
            className="size-10 rounded-full bg-cover bg-center cursor-pointer ring-2 ring-transparent hover:ring-primary transition-all"
            style={{ backgroundImage: `url("${template.creator.avatar}")` }}
          ></div>
          <div className="flex-1 cursor-pointer" onClick={() => navigate(`/creator/${template.creator.id}`)}>
            <p className="text-slate-900 dark:text-white font-bold text-sm">{template.creator.name}</p>
            <p className="text-slate-500 dark:text-slate-400 text-xs">{template.creator.role}</p>
          </div>
          <button 
            onClick={() => toggleFollow(template.creator.id)}
            className={`px-4 py-1.5 rounded-full text-xs font-bold transition-colors ${isCreatorFollowed ? 'bg-slate-200 dark:bg-slate-700 text-slate-800 dark:text-white' : 'bg-primary/10 text-primary hover:bg-primary/20'}`}
          >
            {isCreatorFollowed ? 'Following' : 'Follow'}
          </button>
        </div>

        {/* Stats */}
        <div className="flex items-center gap-6 py-4">
          <div className="flex items-center gap-1.5">
            <span className="material-symbols-outlined text-yellow-400 filled text-[20px]">star</span>
            <span className="font-bold text-slate-900 dark:text-white">{template.rating}</span>
            <span className="text-slate-500 dark:text-slate-400 text-sm">({reviewCount} reviews)</span>
          </div>
          <div className="w-px h-4 bg-slate-300 dark:bg-slate-700"></div>
          <p className="text-slate-900 dark:text-white font-medium text-sm">{template.sales}+ Sales</p>
        </div>

        {/* Description */}
        <div className="py-2">
          <h3 className="text-slate-900 dark:text-white font-bold text-lg mb-2">Description</h3>
          <p className="text-slate-600 dark:text-slate-300 text-sm leading-relaxed">
            {template.description}
          </p>
          <button className="text-primary text-sm font-semibold mt-1 hover:underline">Read More</button>
        </div>

        {/* Ratings & Reviews Section */}
        <div className="py-6 border-t border-slate-200 dark:border-slate-800 mt-2">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-slate-900 dark:text-white font-bold text-lg">Ratings & Reviews</h3>
            {reviewCount > 3 && (
               <button onClick={() => setShowAllReviews(true)} className="text-primary text-sm font-bold">See All</button>
            )}
          </div>
          
          {/* Summary */}
          <div className="flex items-center gap-4 mb-6 bg-slate-50 dark:bg-slate-800/50 p-4 rounded-2xl">
            <div className="flex flex-col items-center justify-center px-2 min-w-[100px]">
              <span className="text-4xl font-extrabold text-slate-900 dark:text-white">{template.rating}</span>
              <div className="flex text-yellow-400 my-1">
                 {[...Array(5)].map((_, i) => (
                    <span key={i} className={`material-symbols-outlined text-[14px] ${i < Math.round(template.rating) ? 'filled' : ''}`}>star</span>
                 ))}
              </div>
              <p className="text-[10px] font-medium text-slate-500 dark:text-slate-400">out of 5 stars</p>
            </div>
            
            <div className="flex-1 space-y-1">
              {[5, 4, 3, 2, 1].map((star) => (
                <div key={star} className="flex items-center gap-2">
                  <span className="text-xs font-bold text-slate-500 dark:text-slate-400 w-3">{star}</span>
                  <div className="flex-1 h-1.5 bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-yellow-400 rounded-full" 
                      style={{ width: `${calculatePercentage(star)}%` }}
                    ></div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Review List (Limited) */}
          <div className="space-y-4">
            {visibleReviews.length > 0 ? (
              visibleReviews.map((review) => (
                <div key={review.id} className="bg-white dark:bg-[#1b2227] p-4 rounded-xl shadow-sm border border-slate-100 dark:border-slate-800">
                  <div className="flex justify-between items-start mb-2">
                    <div className="flex items-center gap-2">
                      <div 
                        className="size-8 rounded-full bg-cover bg-center bg-slate-200"
                        style={{ backgroundImage: `url("${review.avatar}")` }}
                      ></div>
                      <div>
                        <p className="text-sm font-bold text-slate-900 dark:text-white">{review.user}</p>
                        <div className="flex text-yellow-400">
                          {[...Array(5)].map((_, i) => (
                             <span key={i} className={`material-symbols-outlined text-[12px] ${i < review.rating ? 'filled' : ''}`}>star</span>
                          ))}
                        </div>
                      </div>
                    </div>
                    <span className="text-xs text-slate-400">{review.date}</span>
                  </div>
                  <p className="text-slate-600 dark:text-slate-300 text-sm leading-relaxed mt-2">
                    "{review.content}"
                  </p>
                </div>
              ))
            ) : (
              <p className="text-center text-slate-500 dark:text-slate-400 py-4 italic">No reviews yet. Be the first!</p>
            )}
            
            {reviewCount > 3 && (
               <button 
                  onClick={() => setShowAllReviews(true)}
                  className="w-full py-2 text-sm font-semibold text-slate-500 dark:text-slate-400 hover:text-primary transition-colors"
                >
                  Show all {reviewCount} reviews
                </button>
            )}
          </div>
          
          <button 
            onClick={() => setShowWriteReview(true)}
            className="w-full mt-4 py-3 rounded-xl border border-primary text-primary font-bold text-sm hover:bg-primary/5 transition-colors"
          >
            Write a Review
          </button>
        </div>

        {/* Related */}
        {relatedTemplates.length > 0 && (
          <div className="py-6 border-t border-slate-200 dark:border-slate-800">
            <h3 className="text-slate-900 dark:text-white font-bold text-lg mb-4">Related Templates</h3>
            <div className="flex gap-4 overflow-x-auto no-scrollbar -mx-6 px-6 pb-2">
              {relatedTemplates.map((item) => (
                <div key={item.id} onClick={() => navigate(`/details/${item.id}`)} className="min-w-[140px] flex flex-col gap-2 cursor-pointer group">
                  <div 
                    className="w-full aspect-square rounded-xl bg-cover bg-center transition-transform group-hover:scale-105"
                    style={{ backgroundImage: `url("${item.thumbnail}")` }}
                  ></div>
                  <p className="text-slate-900 dark:text-white font-bold text-sm truncate">{item.title}</p>
                  <p className="text-slate-500 dark:text-slate-400 text-xs">${item.price.toFixed(2)}</p>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Sticky Bottom Bar */}
      <div className="fixed bottom-0 left-0 right-0 p-4 bg-white/90 dark:bg-[#101a22]/90 backdrop-blur-lg border-t border-slate-200 dark:border-slate-800 z-30 flex gap-4 max-w-lg mx-auto">
        <button 
          onClick={handleChat}
          className="size-14 rounded-xl flex items-center justify-center border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
        >
          <span className="material-symbols-outlined">chat</span>
        </button>
        <button 
          onClick={handleAddToCart}
          className="flex-1 rounded-xl bg-primary text-white font-bold text-lg shadow-lg shadow-primary/25 hover:bg-primary/90 transition-all active:scale-95"
        >
          Add to Cart
        </button>
      </div>

      {/* Write Review Modal */}
      {showWriteReview && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={() => setShowWriteReview(false)}></div>
          <div className="relative w-full max-w-md bg-white dark:bg-[#1C1C1E] rounded-2xl shadow-2xl p-6 animate-fade-in z-50">
             <div className="flex justify-between items-center mb-4">
                <h3 className="text-xl font-bold text-slate-900 dark:text-white">Write a Review</h3>
                <button onClick={() => setShowWriteReview(false)} className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200">
                  <span className="material-symbols-outlined">close</span>
                </button>
             </div>
             
             {/* Star Rating Input */}
             <div className="flex justify-center gap-2 mb-6">
                {[1, 2, 3, 4, 5].map((star) => (
                   <button 
                    key={star} 
                    onClick={() => setRatingInput(star)}
                    className="transition-transform hover:scale-110 active:scale-95 focus:outline-none"
                   >
                      <span className={`material-symbols-outlined text-4xl ${ratingInput >= star ? 'text-yellow-400 filled' : 'text-slate-300 dark:text-slate-600'}`}>star</span>
                   </button>
                ))}
             </div>

             <label className="block mb-4">
                <span className="text-sm font-semibold text-slate-700 dark:text-slate-300 mb-2 block">Your Comment</span>
                <textarea 
                  className="w-full bg-slate-100 dark:bg-slate-800 rounded-xl p-4 text-slate-900 dark:text-white resize-none h-32 focus:ring-2 focus:ring-primary/50 outline-none"
                  placeholder="Share your experience with this template..."
                  value={reviewTextInput}
                  onChange={(e) => setReviewTextInput(e.target.value)}
                ></textarea>
             </label>

             <button 
                onClick={handleSubmitReview}
                className="w-full py-4 bg-primary text-white rounded-xl font-bold text-base shadow-lg shadow-primary/25 hover:bg-primary/90 transition-transform active:scale-[0.98]"
             >
                Submit Review
             </button>
          </div>
        </div>
      )}

      {/* All Reviews Full Screen Modal (Acting as Page) */}
      {showAllReviews && (
        <div className="fixed inset-0 z-50 bg-background-light dark:bg-background-dark overflow-y-auto animate-slide-up flex flex-col">
           <div className="sticky top-0 bg-background-light/95 dark:bg-background-dark/95 backdrop-blur-sm p-4 flex items-center gap-4 border-b border-slate-200 dark:border-slate-800 z-10">
              <button 
                onClick={() => setShowAllReviews(false)}
                className="size-10 flex items-center justify-center rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
              >
                 <span className="material-symbols-outlined text-slate-900 dark:text-white">arrow_back</span>
              </button>
              <h2 className="text-xl font-bold text-slate-900 dark:text-white">All Reviews</h2>
           </div>

           <div className="p-4 flex-1">
              {/* Summary Stats (Repeated for clarity) */}
              <div className="flex items-center gap-4 mb-8 bg-slate-50 dark:bg-slate-800/50 p-6 rounded-2xl">
                <div className="flex flex-col items-center justify-center px-2 min-w-[100px]">
                  <span className="text-5xl font-extrabold text-slate-900 dark:text-white">{template.rating}</span>
                  <div className="flex text-yellow-400 my-2">
                    {[...Array(5)].map((_, i) => (
                        <span key={i} className={`material-symbols-outlined text-lg ${i < Math.round(template.rating) ? 'filled' : ''}`}>star</span>
                    ))}
                  </div>
                  <p className="text-xs font-medium text-slate-500 dark:text-slate-400">{reviewCount} reviews</p>
                </div>
                
                <div className="flex-1 space-y-2">
                  {[5, 4, 3, 2, 1].map((star) => (
                    <div key={star} className="flex items-center gap-3">
                      <span className="text-sm font-bold text-slate-500 dark:text-slate-400 w-3">{star}</span>
                      <div className="flex-1 h-2 bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden">
                        <div 
                          className="h-full bg-yellow-400 rounded-full" 
                          style={{ width: `${calculatePercentage(star)}%` }}
                        ></div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* All Reviews List */}
              <div className="space-y-4 pb-24">
                {reviews.map((review) => (
                  <div key={review.id} className="bg-white dark:bg-[#1b2227] p-5 rounded-xl shadow-sm border border-slate-100 dark:border-slate-800">
                    <div className="flex justify-between items-start mb-3">
                      <div className="flex items-center gap-3">
                        <div 
                          className="size-10 rounded-full bg-cover bg-center bg-slate-200"
                          style={{ backgroundImage: `url("${review.avatar}")` }}
                        ></div>
                        <div>
                          <p className="text-base font-bold text-slate-900 dark:text-white">{review.user}</p>
                          <div className="flex text-yellow-400">
                            {[...Array(5)].map((_, i) => (
                              <span key={i} className={`material-symbols-outlined text-[14px] ${i < review.rating ? 'filled' : ''}`}>star</span>
                            ))}
                          </div>
                        </div>
                      </div>
                      <span className="text-xs text-slate-400 font-medium">{review.date}</span>
                    </div>
                    <p className="text-slate-600 dark:text-slate-300 text-base leading-relaxed">
                      "{review.content}"
                    </p>
                  </div>
                ))}
              </div>
           </div>

           <div className="sticky bottom-0 p-4 bg-background-light/95 dark:bg-background-dark/95 border-t border-slate-200 dark:border-slate-800 backdrop-blur-md">
              <button 
                  onClick={() => {
                    setShowAllReviews(false);
                    setShowWriteReview(true);
                  }}
                  className="w-full py-4 bg-primary text-white rounded-xl font-bold text-base shadow-lg shadow-primary/25 hover:bg-primary/90 transition-transform active:scale-[0.98]"
              >
                  Write a Review
              </button>
           </div>
        </div>
      )}
    </div>
  );
};

export default DetailsScreen;
