
import React, { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useApp } from '../context/AppContext';
import { Creator, Template } from '../types';

const CreatorProfileScreen: React.FC = () => {
  const navigate = useNavigate();
  const { id } = useParams();
  const { creators, templates, toggleFollow, isFollowing, toggleWishlist, isInWishlist, showToast } = useApp();
  const [creator, setCreator] = useState<Creator | null>(null);
  const [creatorTemplates, setCreatorTemplates] = useState<Template[]>([]);
  const [activeTab, setActiveTab] = useState('Popular');
  const [showOptions, setShowOptions] = useState(false);

  useEffect(() => {
    // If no ID is passed, default to first creator for demo
    const foundCreator = creators.find(c => c.id === id) || creators[0];
    setCreator(foundCreator);
    
    if (foundCreator) {
      setCreatorTemplates(templates.filter(t => t.creator.id === foundCreator.id));
    }
  }, [id, creators, templates]);

  if (!creator) return <div className="p-10 text-center text-white">Loading...</div>;

  const filteredTemplates = activeTab === 'Popular' 
    ? creatorTemplates 
    : creatorTemplates.filter(t => t.category === activeTab || activeTab === 'Newest'); 
    // Simplified logic for demo tabs since "Newest" isn't strictly tracked in mock data

  const isFollowed = isFollowing(creator.id);

  const handleShare = async () => {
    setShowOptions(false);
    if (navigator.share) {
      try {
        await navigator.share({
          title: creator.name,
          text: `Check out ${creator.name}'s profile on DigitalMart!`,
          url: window.location.href,
        });
      } catch (error) {
        console.log('Error sharing:', error);
      }
    } else {
      navigator.clipboard.writeText(window.location.href);
      showToast('Profile link copied to clipboard');
    }
  };

  const handleReport = () => {
    setShowOptions(false);
    showToast('User reported. We will review this profile.', 'info');
  };

  const handleBlock = () => {
    setShowOptions(false);
    showToast(`${creator.name} has been blocked.`, 'info');
  };

  // Helper component for social icons
  const SocialIcon = ({ icon, label }: { icon: string, label: string }) => (
    <div className="flex flex-col items-center gap-2 cursor-pointer group">
      <div className="size-12 rounded-full bg-slate-200 dark:bg-[#1e293b] flex items-center justify-center text-slate-900 dark:text-white group-hover:bg-primary group-hover:text-white transition-colors">
        <span className="material-symbols-outlined">{icon}</span>
      </div>
      <span className="text-xs text-slate-500 dark:text-slate-400 font-medium">{label}</span>
    </div>
  );

  return (
    <div className="flex flex-col min-h-screen bg-background-light dark:bg-[#101a22] font-display text-slate-900 dark:text-white pb-10 relative">
      {/* Top App Bar */}
      <div className="flex items-center justify-between p-4 sticky top-0 z-10 bg-background-light dark:bg-[#101a22]">
        <button 
          type="button" 
          onClick={() => navigate(-1)} 
          className="flex size-10 items-center justify-center rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
        >
          <span className="material-symbols-outlined text-xl">arrow_back_ios_new</span>
        </button>
        <h2 className="text-lg font-bold">Creator Profile</h2>
        <button 
          onClick={() => setShowOptions(true)}
          className="flex size-10 items-center justify-center rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
        >
           <span className="material-symbols-outlined text-xl">more_horiz</span>
        </button>
      </div>

      {/* Profile Info */}
      <div className="flex flex-col items-center px-4 mt-2">
        <div 
          className="size-28 rounded-full bg-cover bg-center mb-4 ring-4 ring-white dark:ring-[#1e293b] shadow-lg" 
          style={{ backgroundImage: `url("${creator.avatar}")` }}
        ></div>
        
        <h1 className="text-xl font-bold mb-1">{creator.name}</h1>
        <p className="text-slate-500 dark:text-slate-400 text-sm mb-6">{creator.role}</p>
        
        <div className="flex gap-4 w-full mb-8">
            <button 
                onClick={() => toggleFollow(creator.id)}
                className={`flex-1 py-3.5 rounded-xl font-bold text-sm transition-all active:scale-95 shadow-lg ${
                  isFollowed 
                    ? 'bg-slate-200 text-slate-900 dark:bg-[#1e293b] dark:text-white' 
                    : 'bg-primary text-white shadow-primary/25'
                }`}
            >
                {isFollowed ? 'Following' : 'Follow'}
            </button>
            <button 
                onClick={() => navigate(`/messages/${creator.id}`)}
                className="flex-1 py-3.5 rounded-xl font-bold text-sm bg-slate-200 dark:bg-[#1e293b] text-slate-900 dark:text-white hover:bg-slate-300 dark:hover:bg-slate-700 transition-colors"
            >
                Message
            </button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-3 px-4 mb-8">
        <div className="flex flex-col items-center justify-center p-4 bg-slate-100 dark:bg-[#1e293b] rounded-2xl border border-transparent dark:border-slate-800">
          <span className="text-lg font-bold">{creator.followers}</span>
          <span className="text-xs text-slate-500 dark:text-slate-400 mt-1">Followers</span>
        </div>
        <div className="flex flex-col items-center justify-center p-4 bg-slate-100 dark:bg-[#1e293b] rounded-2xl border border-transparent dark:border-slate-800">
          <span className="text-lg font-bold">{creator.templatesCount}</span>
          <span className="text-xs text-slate-500 dark:text-slate-400 mt-1">Templates</span>
        </div>
        <div className="flex flex-col items-center justify-center p-4 bg-slate-100 dark:bg-[#1e293b] rounded-2xl border border-transparent dark:border-slate-800">
          <span className="text-lg font-bold">{creator.likes}</span>
          <span className="text-xs text-slate-500 dark:text-slate-400 mt-1">Likes</span>
        </div>
      </div>

      {/* Bio */}
      <div className="px-6 text-center mb-8">
        <p className="text-slate-600 dark:text-slate-400 text-sm leading-relaxed mb-8">
          {creator.bio}
        </p>
        
        {/* Social Icons */}
        <div className="flex justify-center gap-10">
          <SocialIcon icon="alternate_email" label="Instagram" />
          <SocialIcon icon="sports_basketball" label="Dribbble" />
          <SocialIcon icon="language" label="Website" />
        </div>
      </div>

      {/* Notification Row */}
      <div className="px-4 mb-8">
        <button 
            onClick={() => navigate('/notifications')}
            className="w-full flex items-center justify-between p-4 bg-slate-100 dark:bg-[#1e293b] rounded-xl hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
        >
             <div className="flex items-center gap-3">
                 <span className="material-symbols-outlined text-slate-900 dark:text-white">notifications</span>
                 <span className="font-bold text-sm">Notification Settings</span>
             </div>
             <span className="material-symbols-outlined text-slate-400 text-sm">chevron_right</span>
        </button>
      </div>

      <div className="px-4 py-2">
        <hr className="border-slate-200 dark:border-slate-800"/>
      </div>

      {/* Portfolio Section */}
      <div className="px-4 pt-6">
        <h3 className="text-xl font-bold mb-4">Portfolio</h3>
        
        {/* Tabs */}
        <div className="flex gap-3 mb-6 overflow-x-auto no-scrollbar">
           {['Popular', 'Newest', 'Mobile', 'Web'].map((tab) => (
             <button
               key={tab}
               onClick={() => setActiveTab(tab)}
               className={`px-5 py-2 rounded-full text-sm font-bold whitespace-nowrap transition-colors ${
                 activeTab === tab 
                 ? 'bg-primary text-white' 
                 : 'bg-slate-200 dark:bg-[#1e293b] text-slate-600 dark:text-slate-400 hover:bg-slate-300 dark:hover:bg-slate-700'
               }`}
             >
               {tab}
             </button>
           ))}
        </div>

        {/* Grid */}
        <div className="grid grid-cols-2 gap-4 pb-10">
          {filteredTemplates.map((item) => (
            <div 
                key={item.id} 
                onClick={() => navigate(`/details/${item.id}`)}
                className="group cursor-pointer"
            >
              <div className="relative w-full aspect-[3/4] rounded-2xl overflow-hidden mb-3 bg-slate-200 dark:bg-slate-800">
                <div 
                  className="absolute inset-0 bg-cover bg-center transition-transform duration-500 group-hover:scale-110"
                  style={{ backgroundImage: `url("${item.thumbnail}")` }}
                ></div>
                
                {/* Heart Icon Overlay */}
                <button 
                    onClick={(e) => {
                        e.stopPropagation();
                        toggleWishlist(item.id);
                    }}
                    className="absolute top-3 right-3 size-8 bg-black/30 backdrop-blur-sm rounded-full flex items-center justify-center hover:bg-black/50 transition-colors"
                >
                    <span className={`material-symbols-outlined text-[18px] ${isInWishlist(item.id) ? 'text-red-500 filled' : 'text-white'}`}>favorite</span>
                </button>
              </div>
              
              <h4 className="font-bold text-slate-900 dark:text-white text-sm truncate">{item.title}</h4>
              <p className="text-slate-500 dark:text-slate-400 text-xs mt-1">${item.price.toFixed(2)}</p>
            </div>
          ))}
          {filteredTemplates.length === 0 && (
              <p className="col-span-2 text-center text-slate-500 py-10">No items found.</p>
          )}
        </div>
      </div>

      {/* Options Menu Bottom Sheet */}
      {showOptions && (
        <div className="fixed inset-0 z-50 flex flex-col justify-end">
          <div 
            className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            onClick={() => setShowOptions(false)}
          ></div>
          <div className="relative bg-white dark:bg-[#1C1C1E] rounded-t-3xl p-4 animate-slide-up flex flex-col gap-2 pb-8 shadow-2xl">
            {/* Handle */}
            <div className="w-12 h-1.5 bg-slate-300 dark:bg-slate-700 rounded-full mx-auto mb-4"></div>
            
            <button 
              onClick={handleShare}
              className="flex items-center gap-4 p-4 rounded-2xl hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors text-slate-900 dark:text-white font-bold text-left"
            >
              <div className="size-10 rounded-full bg-slate-100 dark:bg-slate-700 flex items-center justify-center">
                 <span className="material-symbols-outlined">ios_share</span>
              </div>
              <span className="text-base">Share Profile</span>
            </button>
            
            <button 
              onClick={handleReport}
              className="flex items-center gap-4 p-4 rounded-2xl hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors text-slate-900 dark:text-white font-bold text-left"
            >
              <div className="size-10 rounded-full bg-slate-100 dark:bg-slate-700 flex items-center justify-center">
                 <span className="material-symbols-outlined">flag</span>
              </div>
              <span className="text-base">Report User</span>
            </button>
            
            <button 
              onClick={handleBlock}
              className="flex items-center gap-4 p-4 rounded-2xl hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors text-red-500 font-bold text-left"
            >
              <div className="size-10 rounded-full bg-red-50 dark:bg-red-900/20 flex items-center justify-center">
                 <span className="material-symbols-outlined">block</span>
              </div>
              <span className="text-base">Block User</span>
            </button>
            
            <div className="h-px bg-slate-200 dark:bg-slate-800 my-2 mx-4"></div>
            
            <button 
              onClick={() => setShowOptions(false)}
              className="p-4 rounded-2xl bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-white font-bold text-center mt-2"
            >
              Cancel
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default CreatorProfileScreen;
