
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useApp } from '../context/AppContext';

interface Session {
  id: string;
  name: string;
  location: string;
  lastActive: string;
  icon: string;
  type: 'mobile' | 'desktop' | 'tablet';
  os: string;
  browser?: string;
  ip: string;
  loginTime: string;
}

const ManageSessionsScreen: React.FC = () => {
  const navigate = useNavigate();
  const { showToast } = useApp();
  const [showLogoutConfirm, setShowLogoutConfirm] = useState(false);

  const [otherSessions, setOtherSessions] = useState<Session[]>([
    {
      id: '1',
      name: 'Macbook Pro',
      location: 'New York, USA',
      lastActive: 'Last active: Yesterday',
      icon: 'laptop_mac',
      type: 'desktop',
      os: 'macOS Sonoma',
      browser: 'Chrome',
      ip: '203.0.113.25',
      loginTime: 'Jan 14, 2024, 4:15 PM'
    },
    {
      id: '2',
      name: 'Windows Desktop',
      location: 'San Francisco, USA',
      lastActive: 'Last active: 2 days ago',
      icon: 'desktop_windows',
      type: 'desktop',
      os: 'Windows 11',
      browser: 'Edge',
      ip: '192.0.2.146',
      loginTime: 'Jan 13, 2024, 9:00 AM'
    }
  ]);

  const handleLogoutSession = (id: string) => {
    // In a real app, API call here
    setOtherSessions(prev => prev.filter(s => s.id !== id));
    showToast('Session logged out successfully');
  };

  const handleLogoutAllClick = () => {
    setShowLogoutConfirm(true);
  };

  const handleConfirmLogoutAll = () => {
    setOtherSessions([]);
    setShowLogoutConfirm(false);
    // In a real app, API call here
    showToast('Logged out from all other devices');
  };

  return (
    <div className="relative flex h-auto min-h-screen w-full flex-col bg-background-light dark:bg-background-dark font-display overflow-x-hidden">
      {/* Top App Bar */}
      <div className="flex items-center bg-background-light/80 dark:bg-background-dark/80 backdrop-blur-sm p-4 sticky top-0 z-10 border-b border-slate-200/10 dark:border-white/10">
        <button 
          onClick={() => navigate('/account-security')}
          className="text-slate-800 dark:text-white flex size-10 shrink-0 items-center justify-center hover:bg-slate-100 dark:hover:bg-slate-800 rounded-full transition-colors cursor-pointer"
        >
          <span className="material-symbols-outlined">arrow_back_ios_new</span>
        </button>
        <h1 className="text-slate-900 dark:text-white text-lg font-bold leading-tight tracking-tight flex-1 text-center pr-10">Active Sessions</h1>
      </div>

      {/* Body Text */}
      <div className="px-4 pt-4">
        <p className="text-slate-600 dark:text-slate-400 text-sm font-normal leading-relaxed">
          This is a list of devices that have logged into your account. You can log out of any sessions you don't recognize.
        </p>
      </div>

      <div className="flex flex-col gap-1 px-4 py-6">
        {/* Current Device Session */}
        <div className="flex flex-col gap-4 bg-background-light dark:bg-background-dark p-4 rounded-xl border border-slate-200 dark:border-slate-800">
          <div className="flex items-start gap-4">
            <div className="text-primary flex items-center justify-center rounded-lg bg-primary/20 shrink-0 size-12">
              <span className="material-symbols-outlined text-3xl">phone_iphone</span>
            </div>
            <div className="flex flex-1 flex-col justify-center gap-0.5">
              <p className="text-slate-900 dark:text-white text-base font-medium leading-normal">iPhone 15 Pro</p>
              <p className="text-green-500 dark:text-green-400 text-sm font-medium leading-normal">Current Device</p>
              <p className="text-slate-500 dark:text-slate-400 text-sm font-normal leading-normal">Last active: Just now</p>
            </div>
          </div>
          <div className="flex flex-col gap-1 text-sm text-slate-500 dark:text-slate-400">
            <p><span className="font-medium text-slate-700 dark:text-slate-300">OS:</span> iOS 17.2</p>
            <p><span className="font-medium text-slate-700 dark:text-slate-300">Location:</span> London, UK</p>
            <p><span className="font-medium text-slate-700 dark:text-slate-300">IP Address:</span> 198.51.100.1</p>
            <p><span className="font-medium text-slate-700 dark:text-slate-300">Login time:</span> Jan 15, 2024, 10:30 AM</p>
          </div>
        </div>

        {/* Other Devices Section Title */}
        {otherSessions.length > 0 && (
          <h2 className="text-slate-500 dark:text-slate-400 text-sm font-semibold leading-normal uppercase tracking-wider px-4 pt-6 pb-2">Other Sessions</h2>
        )}

        {/* Other Sessions List */}
        {otherSessions.map((session) => (
          <div key={session.id} className="flex flex-col gap-4 bg-background-light dark:bg-background-dark p-4 rounded-xl border border-slate-200 dark:border-slate-800 animate-fade-in">
            <div className="flex items-center gap-4">
              <div className="text-slate-800 dark:text-white flex items-center justify-center rounded-lg bg-slate-200 dark:bg-slate-700 shrink-0 size-12">
                <span className="material-symbols-outlined text-3xl">{session.icon}</span>
              </div>
              <div className="flex flex-1 flex-col justify-center">
                <p className="text-slate-900 dark:text-white text-base font-medium leading-normal line-clamp-1">{session.name}</p>
                <p className="text-slate-500 dark:text-slate-400 text-sm font-normal leading-normal line-clamp-2">{session.lastActive}</p>
              </div>
              <div className="shrink-0">
                <button 
                  onClick={() => handleLogoutSession(session.id)}
                  className="flex min-w-[84px] max-w-[480px] cursor-pointer items-center justify-center overflow-hidden rounded-lg h-9 px-4 bg-red-500/10 text-red-500 text-sm font-medium leading-normal w-fit transition-colors hover:bg-red-500/20"
                >
                  <span className="truncate">Log Out</span>
                </button>
              </div>
            </div>
            <div className="flex flex-col gap-1 text-sm text-slate-500 dark:text-slate-400">
              <p><span className="font-medium text-slate-700 dark:text-slate-300">OS:</span> {session.os}</p>
              {session.browser && <p><span className="font-medium text-slate-700 dark:text-slate-300">Browser:</span> {session.browser}</p>}
              <p><span className="font-medium text-slate-700 dark:text-slate-300">Location:</span> {session.location}</p>
              <p><span className="font-medium text-slate-700 dark:text-slate-300">IP Address:</span> {session.ip}</p>
              <p><span className="font-medium text-slate-700 dark:text-slate-300">Login time:</span> {session.loginTime}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Spacer */}
      <div className="flex-grow"></div>

      {/* Global Action Button */}
      {otherSessions.length > 0 && (
        <div className="sticky bottom-0 w-full p-4 bg-background-light dark:bg-background-dark border-t border-slate-200 dark:border-slate-800">
          <button 
            onClick={handleLogoutAllClick}
            className="flex w-full cursor-pointer items-center justify-center overflow-hidden rounded-xl h-12 px-6 bg-red-600 text-white text-base font-bold leading-normal transition-colors hover:bg-red-700 active:scale-[0.98]"
          >
            <span className="truncate">Log Out from All Devices</span>
          </button>
        </div>
      )}

      {/* Log Out All Devices Confirmation Dialog */}
      {showLogoutConfirm && (
        <div className="fixed inset-0 z-50 flex flex-col justify-end items-center">
          {/* Backdrop */}
          <div 
            className="absolute inset-0 h-full w-full bg-black/60 backdrop-blur-sm"
            onClick={() => setShowLogoutConfirm(false)}
          ></div>
          
          {/* BottomSheet/Modal Dialog Box */}
          <div className="relative flex w-full max-w-md flex-col items-stretch rounded-t-xl bg-white dark:bg-[#1c1c1e] pb-6 animate-slide-up shadow-2xl">
            {/* BottomSheetHandle */}
            <div className="flex h-5 w-full items-center justify-center pt-2 pb-1">
              <div className="h-1 w-9 rounded-full bg-slate-300 dark:bg-[#464649]"></div>
            </div>
            
            {/* Icon */}
            <div className="flex justify-center py-4">
              <div className="flex h-16 w-16 items-center justify-center rounded-full bg-red-500/10 dark:bg-red-500/20">
                <span className="material-symbols-outlined text-4xl text-red-500">logout</span>
              </div>
            </div>
            
            {/* HeadlineText */}
            <h3 className="text-slate-900 dark:text-white tracking-light text-2xl font-bold leading-tight px-4 text-center pb-2 pt-1 font-display">Log Out All Devices?</h3>
            
            {/* BodyText */}
            <p className="text-slate-600 dark:text-slate-400 text-base font-normal leading-normal pb-6 pt-1 px-6 text-center font-display">
              Are you sure you want to log out from all devices? You will need to log in again on each device.
            </p>
            
            {/* ButtonGroup */}
            <div className="flex justify-center">
              <div className="flex flex-1 gap-3 max-w-[480px] flex-col items-stretch px-4">
                <button 
                  onClick={handleConfirmLogoutAll}
                  className="flex min-w-[84px] max-w-[480px] cursor-pointer items-center justify-center overflow-hidden rounded-lg h-12 px-5 bg-red-500 text-white text-base font-bold leading-normal tracking-[0.015em] w-full font-display hover:bg-red-600 transition-colors"
                >
                  <span className="truncate">Log Out All</span>
                </button>
                <button 
                  onClick={() => setShowLogoutConfirm(false)}
                  className="flex min-w-[84px] max-w-[480px] cursor-pointer items-center justify-center overflow-hidden rounded-lg h-12 px-5 bg-slate-100 dark:bg-[#283239] text-slate-900 dark:text-white text-base font-bold leading-normal tracking-[0.015em] w-full font-display hover:bg-slate-200 dark:hover:bg-[#3A3A3C] transition-colors"
                >
                  <span className="truncate">Cancel</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ManageSessionsScreen;
