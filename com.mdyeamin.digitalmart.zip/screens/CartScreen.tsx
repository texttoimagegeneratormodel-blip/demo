
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useApp } from '../context/AppContext';

const CartScreen: React.FC = () => {
  const navigate = useNavigate();
  const { cart, removeFromCart, cartTotal, clearCart, showToast } = useApp();
  const [promoCode, setPromoCode] = useState('');
  const [discount, setDiscount] = useState(0);
  const [isProcessing, setIsProcessing] = useState(false);
  const [showDemoModal, setShowDemoModal] = useState(false);

  const tax = cartTotal * 0.05;
  const finalTotal = Math.max(0, cartTotal + tax - discount);

  const handleApplyPromo = () => {
    if (!promoCode.trim()) {
      showToast('Please enter a promo code', 'info');
      return;
    }
    if (promoCode.trim().toUpperCase() === 'SAVE10') {
      const disc = cartTotal * 0.10;
      setDiscount(disc);
      showToast(`Promo code applied! You saved $${disc.toFixed(2)}`);
    } else {
      showToast('Invalid promo code', 'error');
      setDiscount(0);
    }
  };

  const handleCheckout = () => {
    if (cart.length === 0) return;
    setIsProcessing(true);
    
    // Simulate delay then show Demo Modal instead of success
    setTimeout(() => {
      setIsProcessing(false);
      setShowDemoModal(true);
    }, 1000);
  };

  return (
    <div className="flex flex-col min-h-screen bg-background-light dark:bg-background-dark">
      {/* Header */}
      <header className="sticky top-0 z-10 flex items-center justify-between p-4 bg-background-light/95 dark:bg-background-dark/95 backdrop-blur-sm border-b border-slate-200 dark:border-slate-800">
        <button type="button" onClick={() => navigate('/home')} className="text-slate-900 dark:text-white cursor-pointer">
          <span className="material-symbols-outlined">arrow_back_ios_new</span>
        </button>
        <span className="font-bold text-lg text-slate-900 dark:text-white">My Cart</span>
        <div className="w-6"></div>
      </header>

      <div className="flex-1 p-4 pb-32">
        {/* Cart Items */}
        {cart.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-64 text-slate-500">
            <span className="material-symbols-outlined text-6xl mb-4 opacity-50">shopping_cart_off</span>
            <p className="text-lg font-medium">Your cart is empty</p>
            <button 
              onClick={() => navigate('/home')}
              className="mt-4 text-primary font-bold hover:underline"
            >
              Start Shopping
            </button>
          </div>
        ) : (
          <div className="flex flex-col gap-4">
            {cart.map((item) => (
              <div key={item.id} className="flex gap-4 p-3 bg-white dark:bg-slate-800/50 rounded-2xl shadow-sm border border-slate-100 dark:border-slate-800/50 transition-all hover:shadow-md">
                <div 
                  className="size-20 rounded-xl bg-cover bg-center shrink-0 cursor-pointer"
                  style={{ backgroundImage: `url("${item.template.thumbnail}")` }}
                  onClick={() => navigate(`/details/${item.template.id}`)}
                ></div>
                <div className="flex flex-col flex-1 justify-center">
                  <div className="flex justify-between items-start">
                     <h3 
                      className="font-bold text-slate-900 dark:text-white line-clamp-1 pr-2 cursor-pointer"
                      onClick={() => navigate(`/details/${item.template.id}`)}
                     >
                       {item.template.title}
                     </h3>
                     <button 
                       onClick={() => removeFromCart(item.id)}
                       className="text-slate-400 hover:text-red-500 transition-colors p-1"
                     >
                       <span className="material-symbols-outlined text-[20px]">delete</span>
                     </button>
                  </div>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mb-2">by {item.template.creator.name}</p>
                  <p className="font-bold text-primary text-lg">${item.template.price.toFixed(2)}</p>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Coupon */}
        {cart.length > 0 && (
          <div className="mt-8">
            <p className="text-sm font-bold text-slate-900 dark:text-white mb-2 ml-1">Have a discount code?</p>
            <div className="flex gap-2">
              <input 
                className="flex-1 bg-white dark:bg-slate-800 rounded-xl px-4 h-12 border-none focus:ring-2 focus:ring-primary/50 text-slate-900 dark:text-white placeholder:text-slate-400"
                placeholder="Try 'SAVE10'"
                value={promoCode}
                onChange={(e) => setPromoCode(e.target.value)}
              />
              <button 
                onClick={handleApplyPromo}
                className="px-6 h-12 bg-slate-200 dark:bg-slate-700 rounded-xl font-bold text-slate-700 dark:text-slate-200 hover:bg-slate-300 dark:hover:bg-slate-600 transition-colors"
              >
                Apply
              </button>
            </div>
          </div>
        )}

        {/* Summary */}
        {cart.length > 0 && (
          <div className="mt-8 bg-white dark:bg-slate-800/50 rounded-2xl p-5 border border-slate-100 dark:border-slate-800/50 shadow-sm">
            <h2 className="font-bold text-lg text-slate-900 dark:text-white mb-4">Order Summary</h2>
            <div className="space-y-3">
              <div className="flex justify-between text-slate-500 dark:text-slate-400 text-sm">
                <span>Subtotal</span>
                <span>${cartTotal.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-slate-500 dark:text-slate-400 text-sm">
                <span>Tax (5%)</span>
                <span>${tax.toFixed(2)}</span>
              </div>
              {discount > 0 && (
                <div className="flex justify-between text-green-500 text-sm font-medium">
                  <span>Discount</span>
                  <span>-${discount.toFixed(2)}</span>
                </div>
              )}
              <div className="h-px bg-slate-200 dark:bg-slate-700 my-2"></div>
              <div className="flex justify-between text-slate-900 dark:text-white text-lg font-bold">
                <span>Total</span>
                <span>${finalTotal.toFixed(2)}</span>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Checkout Button */}
      {cart.length > 0 && (
        <div className="fixed bottom-0 left-0 right-0 p-4 bg-background-light/90 dark:bg-background-dark/90 backdrop-blur-lg border-t border-slate-200 dark:border-slate-800 max-w-lg mx-auto">
          <button 
            onClick={handleCheckout}
            disabled={isProcessing}
            className={`w-full h-14 bg-primary text-white rounded-xl font-bold text-lg shadow-lg shadow-primary/25 hover:bg-primary/90 transition-all active:scale-[0.98] flex items-center justify-center gap-2 ${isProcessing ? 'opacity-80 cursor-wait' : ''}`}
          >
            {isProcessing ? (
              <>
                <div className="size-5 rounded-full border-2 border-white/30 border-t-white animate-spin"></div>
                Processing...
              </>
            ) : (
              <>
                <span className="material-symbols-outlined filled">lock</span>
                Checkout Securely
              </>
            )}
          </button>
        </div>
      )}

      {/* Demo Modal */}
      {showDemoModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" onClick={() => setShowDemoModal(false)}></div>
          <div className="relative w-full max-w-sm bg-white dark:bg-[#1C1C1E] rounded-3xl p-6 shadow-2xl animate-fade-in text-center">
            <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-primary/10">
              <span className="material-symbols-outlined text-primary text-4xl">shopping_cart_checkout</span>
            </div>
            <h2 className="text-2xl font-extrabold text-slate-900 dark:text-white mb-2">This is a Demo App</h2>
            <p className="text-slate-600 dark:text-slate-300 text-sm leading-relaxed mb-6">
              The payment integration is simulated for demonstration purposes. To launch your own real marketplace and accept payments, purchase the source code.
            </p>
            
            <div className="flex flex-col gap-3">
              <button 
                onClick={() => navigate('/buy-code')}
                className="w-full bg-primary text-white font-bold py-3.5 rounded-xl shadow-lg shadow-primary/30 hover:bg-primary/90 transition-transform active:scale-95"
              >
                Buy Source Code ($399)
              </button>
              <button 
                onClick={() => setShowDemoModal(false)}
                className="w-full bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-white font-bold py-3.5 rounded-xl hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
              >
                Continue Exploring
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default CartScreen;
