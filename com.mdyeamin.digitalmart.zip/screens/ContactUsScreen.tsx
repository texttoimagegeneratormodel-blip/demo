
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useApp } from '../context/AppContext';

const ContactUsScreen: React.FC = () => {
  const navigate = useNavigate();
  const { user } = useApp();
  const [topic, setTopic] = useState('Billing');
  const [message, setMessage] = useState('');

  const handleSubmit = () => {
    // Mock submission logic
    if (!message.trim()) {
      alert("Please enter a message.");
      return;
    }
    // Use the toast system instead of alert if possible, but keeping minimal changes here
    alert(`Message sent regarding ${topic}! We will get back to you shortly.`);
    handleBack();
  };

  const handleBack = () => {
    if (window.history.state && window.history.state.idx > 0) {
      navigate(-1);
    } else {
      // Fallback if no history exists
      navigate('/help-support');
    }
  };

  return (
    <div className="relative flex h-auto min-h-screen w-full flex-col bg-background-light dark:bg-background-dark font-display">
      <div className="flex flex-col flex-1">
        {/* Top App Bar - Fixed Layout */}
        <div className="flex items-center bg-background-light dark:bg-background-dark p-4 pb-2 sticky top-0 z-20 border-b border-transparent dark:border-slate-800">
          <button 
            type="button"
            onClick={handleBack}
            className="flex size-10 shrink-0 items-center justify-center rounded-full text-slate-900 dark:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <span className="material-symbols-outlined text-xl">arrow_back_ios_new</span>
          </button>
          
          <h2 className="flex-1 text-center text-slate-900 dark:text-white text-lg font-bold leading-tight tracking-[-0.015em]">Contact Us</h2>
          
          <div className="size-10 shrink-0"></div>
        </div>

        {/* Body Text */}
        <p className="text-slate-600 dark:text-slate-400 text-base font-normal leading-normal pb-3 pt-1 px-4">
          Our team will get back to you within 24 hours.
        </p>

        {/* Topic/Subject Label */}
        <div className="px-4 py-3 pb-2">
          <p className="text-slate-900 dark:text-white text-base font-medium leading-normal">Topic</p>
        </div>

        {/* Segmented Buttons */}
        <div className="flex px-4 pt-0 pb-3">
          <div className="flex h-10 flex-1 items-center justify-center rounded-lg bg-slate-200 dark:bg-slate-800 p-1">
            {['Billing', 'Technical', 'Feedback'].map((item) => (
              <label key={item} className={`flex cursor-pointer h-full grow items-center justify-center overflow-hidden rounded-lg px-2 text-sm font-medium leading-normal transition-colors duration-200 ${
                topic === item 
                  ? 'bg-white dark:bg-background-dark shadow-sm text-slate-900 dark:text-white' 
                  : 'text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}>
                <span className="truncate">{item}</span>
                <input 
                  className="invisible w-0" 
                  name="support-topic" 
                  type="radio" 
                  value={item}
                  checked={topic === item}
                  onChange={() => setTopic(item)}
                />
              </label>
            ))}
          </div>
        </div>

        {/* Email Text Field */}
        <div className="flex w-full flex-wrap items-end gap-4 px-4 py-3">
          <label className="flex flex-col min-w-40 flex-1">
            <p className="text-slate-900 dark:text-white text-base font-medium leading-normal pb-2">Your Email</p>
            <div className="flex w-full flex-1 items-stretch rounded-lg">
              <input 
                className="form-input flex w-full min-w-0 flex-1 resize-none overflow-hidden rounded-lg text-slate-900 dark:text-white focus:outline-0 focus:ring-2 focus:ring-primary/50 border-slate-300 dark:border-slate-700 bg-slate-100 dark:bg-slate-800 focus:border-primary/50 h-14 placeholder:text-slate-500 dark:placeholder:text-slate-400 p-4 text-base font-normal leading-normal" 
                readOnly 
                value={user?.email || "user@example.com"}
              />
            </div>
          </label>
        </div>

        {/* Message Text Field */}
        <div className="flex w-full flex-wrap items-end gap-4 px-4 py-3">
          <label className="flex flex-col min-w-40 flex-1">
            <p className="text-slate-900 dark:text-white text-base font-medium leading-normal pb-2">Message</p>
            <textarea 
              className="form-input flex w-full min-w-0 flex-1 resize-none overflow-hidden rounded-lg text-slate-900 dark:text-white focus:outline-0 focus:ring-2 focus:ring-primary/50 border-slate-300 dark:border-slate-700 bg-slate-100 dark:bg-slate-800 focus:border-primary/50 min-h-36 placeholder:text-slate-500 dark:placeholder:text-slate-400 p-4 text-base font-normal leading-normal" 
              placeholder="Please describe your issue in detail..."
              value={message}
              onChange={(e) => setMessage(e.target.value)}
            ></textarea>
          </label>
        </div>
      </div>

      {/* Sticky Footer for Button and Privacy Note */}
      <div className="sticky bottom-0 bg-background-light dark:bg-background-dark pt-4 pb-6 px-4 border-t border-transparent dark:border-slate-800/50">
        {/* CTA Button */}
        <div className="flex flex-col items-stretch">
          <button 
            onClick={handleSubmit}
            className="flex items-center justify-center rounded-xl bg-primary h-14 text-white text-base font-bold leading-normal shadow-lg shadow-primary/25 hover:bg-primary/90 transition-transform active:scale-[0.98]"
          >
            Send Message
          </button>
        </div>
        {/* Privacy Note */}
        <p className="text-slate-500 dark:text-slate-500 text-xs text-center pt-4">
          Your information is handled with care. Read our <span className="font-medium text-primary/80 cursor-pointer hover:underline">Privacy Policy</span>.
        </p>
      </div>
    </div>
  );
};

export default ContactUsScreen;
