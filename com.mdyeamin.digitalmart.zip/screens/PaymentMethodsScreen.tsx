
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useApp } from '../context/AppContext';

const PaymentMethodsScreen: React.FC = () => {
  const navigate = useNavigate();
  const { paymentMethods, removePaymentMethod } = useApp();

  return (
    <div className="flex flex-col min-h-screen bg-background-light dark:bg-background-dark font-display">
      {/* Top App Bar */}
      <header className="flex items-center justify-between p-4 pb-2 sticky top-0 bg-background-light dark:bg-background-dark z-50">
        <button
          onClick={() => navigate(-1)}
          type="button"
          className="flex w-12 h-12 items-center justify-center text-slate-800 dark:text-white rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
        >
          <span className="material-symbols-outlined text-2xl">arrow_back_ios_new</span>
        </button>
        <h1 className="flex-1 text-center text-lg font-bold text-slate-900 dark:text-white">Payment Methods</h1>
        <div className="w-12 h-12"></div>
      </header>

      {/* Main Content */}
      <main className="flex-1 px-4 pt-2 pb-28">
        {paymentMethods.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-64 text-slate-500">
             <span className="material-symbols-outlined text-5xl mb-2 opacity-50">credit_card_off</span>
             <p>No payment methods added.</p>
          </div>
        ) : (
          <div className="space-y-6">
            <section>
              <h2 className="px-2 pb-2 text-sm font-medium text-slate-500 dark:text-slate-400">Your Methods</h2>
              <div className="divide-y divide-slate-200/50 rounded-xl bg-white dark:divide-slate-700/50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-800 overflow-hidden">
                {paymentMethods.map((method) => (
                  <div key={method.id} className="flex cursor-pointer items-center gap-4 p-4 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors group relative">
                    {method.iconType === 'image' ? (
                      <img
                        className="h-6 w-10 shrink-0 object-contain"
                        alt="Method logo"
                        src={method.iconValue}
                      />
                    ) : (
                      <div className="flex w-10 h-10 shrink-0 items-center justify-center rounded-lg bg-slate-100 dark:bg-slate-700">
                        <span className="material-symbols-outlined text-slate-600 dark:text-slate-300">{method.iconValue}</span>
                      </div>
                    )}
                    
                    <div className="flex-1">
                      <p className="font-medium text-slate-900 dark:text-white">{method.title}</p>
                      {method.subtitle && (
                        <p className={`text-sm font-medium ${method.isDefault ? 'text-green-500' : 'text-slate-500'}`}>
                          {method.isDefault ? 'Default' : method.subtitle}
                        </p>
                      )}
                    </div>
                    
                    <button 
                      onClick={(e) => {
                        e.stopPropagation();
                        removePaymentMethod(method.id);
                      }}
                      className="text-slate-400 hover:text-red-500 dark:text-slate-500 dark:hover:text-red-400 p-2"
                    >
                      <span className="material-symbols-outlined">delete</span>
                    </button>
                  </div>
                ))}
              </div>
            </section>
          </div>
        )}
      </main>

      {/* Footer with CTA Button */}
      <footer className="p-4 pt-2 fixed bottom-0 left-0 right-0 max-w-lg mx-auto bg-background-light/95 dark:bg-background-dark/95 backdrop-blur-sm z-50">
        <button 
          onClick={() => navigate('/add-payment-method')}
          className="flex h-12 w-full cursor-pointer items-center justify-center gap-2 overflow-hidden rounded-xl bg-primary text-base font-bold text-white transition-all hover:bg-primary/90 active:scale-[0.98] shadow-lg shadow-primary/25"
        >
          <span className="material-symbols-outlined">add_circle</span>
          <span className="truncate">Add New Payment Method</span>
        </button>
      </footer>
    </div>
  );
};

export default PaymentMethodsScreen;
