
import { Template, Creator, Review } from '../types';

export const CREATORS: Creator[] = [
  {
    id: '1',
    name: 'Olivia Chen',
    role: 'UI Designer',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&auto=format&fit=crop&w=200&q=80',
    followers: '1.2k',
    templatesCount: 34,
    likes: '1.8M',
    bio: 'I design beautiful and functional templates to help you build amazing products.'
  },
  {
    id: '2',
    name: 'UIUX Labs',
    role: 'Agency',
    avatar: 'https://images.unsplash.com/photo-1542601906990-b4d3fb778b09?ixlib=rb-1.2.1&auto=format&fit=crop&w=200&q=80',
    followers: '5.4k',
    templatesCount: 120,
    likes: '12k',
    bio: 'Premium UI kits and templates for startups and agencies.'
  },
  {
    id: '3',
    name: 'Pixel Perfect',
    role: 'Frontend Dev',
    avatar: 'https://images.unsplash.com/photo-1599566150163-29194dcaad36?ixlib=rb-1.2.1&auto=format&fit=crop&w=200&q=80',
    followers: '800',
    templatesCount: 12,
    likes: '4.5k',
    bio: 'Obsessed with clean code and pixel perfect designs.'
  }
];

const SAMPLE_REVIEWS: Review[] = [
  {
    id: 'r1',
    user: 'Sarah Jenkins',
    avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?ixlib=rb-1.2.1&auto=format&fit=crop&w=150&q=80',
    rating: 5,
    date: '2 days ago',
    content: 'This template saved me weeks of work! The code is clean and easy to customize. Highly recommended.'
  },
  {
    id: 'r2',
    user: 'Michael Ross',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?ixlib=rb-1.2.1&auto=format&fit=crop&w=150&q=80',
    rating: 4,
    date: '1 week ago',
    content: 'Great design quality. I just wish there were a few more color variations included by default, but overall excellent value.'
  },
  {
    id: 'r3',
    user: 'Jessica Lee',
    avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?ixlib=rb-1.2.1&auto=format&fit=crop&w=150&q=80',
    rating: 5,
    date: '2 weeks ago',
    content: 'Absolutely stunning. I used this for my portfolio and got hired within a month. Thank you Olivia!'
  }
];

export const TEMPLATES: Template[] = [
  {
    id: '101',
    title: 'Minimalist Portfolio',
    creator: CREATORS[0],
    price: 19.99,
    rating: 4.8,
    sales: 1200,
    category: 'Websites',
    thumbnail: 'https://images.unsplash.com/photo-1507238691740-187a5b1d37b8?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
    images: [
      'https://images.unsplash.com/photo-1507238691740-187a5b1d37b8?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1467232004584-a241de8bcf5d?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1460925895917-afdab827c52f?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80'
    ],
    description: 'A beautifully crafted, modern portfolio template designed for creatives. Fully responsive and built with clean code.',
    reviews: SAMPLE_REVIEWS
  },
  {
    id: '102',
    title: 'SaaS Landing Page',
    creator: CREATORS[1],
    price: 24.00,
    rating: 4.9,
    sales: 850,
    category: 'Websites',
    thumbnail: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
    images: [
      'https://images.unsplash.com/photo-1551288049-bebda4e38f71?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1551434678-e076c223a692?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80'
    ],
    description: 'High conversion landing page for SaaS products. Includes pricing tables, feature grids, and testimonial sliders.',
    reviews: [SAMPLE_REVIEWS[0], SAMPLE_REVIEWS[2]]
  },
  {
    id: '103',
    title: 'Pitch Deck Pro',
    creator: CREATORS[1],
    price: 29.99,
    rating: 4.7,
    sales: 500,
    category: 'Presentations',
    thumbnail: 'https://images.unsplash.com/photo-1557804506-669a67965ba0?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
    images: [
      'https://images.unsplash.com/photo-1557804506-669a67965ba0?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1556761175-5973dc0f32e7?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80'
    ],
    description: 'Professional pitch deck template with over 50 unique slides. Perfect for startups seeking investment.',
    reviews: [SAMPLE_REVIEWS[1]]
  },
  {
    id: '104',
    title: 'Dark Mode Dashboard',
    creator: CREATORS[2],
    price: 35.00,
    rating: 4.6,
    sales: 320,
    category: 'Websites',
    thumbnail: 'https://images.unsplash.com/photo-1555421689-492a1880deb4?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
    images: [
      'https://images.unsplash.com/photo-1555421689-492a1880deb4?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1551288049-bebda4e38f71?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80'
    ],
    description: 'A sleek dark mode dashboard UI kit. Includes charts, graphs, and data tables.'
  },
  {
    id: '105',
    title: 'Social UI Kit',
    creator: CREATORS[0],
    price: 15.00,
    rating: 4.5,
    sales: 210,
    category: 'Social',
    thumbnail: 'https://images.unsplash.com/photo-1611162617474-5b21e879e113?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
    images: [
      'https://images.unsplash.com/photo-1611162617474-5b21e879e113?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1611162616475-46b635cb6868?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80'
    ],
    description: 'Complete social media UI kit including feed, profile, and chat screens.'
  },
  {
    id: '106',
    title: 'Minimal Resume',
    creator: CREATORS[2],
    price: 12.00,
    rating: 4.9,
    sales: 2000,
    category: 'Resumes',
    thumbnail: 'https://images.unsplash.com/photo-1586281380349-632531db7ed4?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
    images: [
      'https://images.unsplash.com/photo-1586281380349-632531db7ed4?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80'
    ],
    description: 'Stand out from the crowd with this clean, minimalist resume template.'
  },
  // Dashboard Templates (Owned by current user)
  {
    id: '201',
    title: 'Minimalist Portfolio Website',
    creator: CREATORS[0],
    price: 25.00,
    rating: 4.8,
    sales: 150,
    category: 'Websites',
    thumbnail: 'https://images.unsplash.com/photo-1507238691740-187a5b1d37b8?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
    images: [
      'https://images.unsplash.com/photo-1507238691740-187a5b1d37b8?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80'
    ],
    description: 'A clean and minimal portfolio for showcasing your work. Includes Light and Dark modes.'
  },
  {
    id: '202',
    title: 'Modern CV Resume Template',
    creator: CREATORS[0],
    price: 15.00,
    rating: 0,
    sales: 0,
    category: 'Resumes',
    thumbnail: 'https://images.unsplash.com/photo-1586281380349-632531db7ed4?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
    images: [
      'https://images.unsplash.com/photo-1586281380349-632531db7ed4?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80'
    ],
    description: 'Get hired faster with this modern CV template. Easy to edit in Figma and Sketch.'
  },
  {
    id: '203',
    title: 'E-commerce Dashboard UI Kit',
    creator: CREATORS[0],
    price: 45.00,
    rating: 3.2,
    sales: 12,
    category: 'Websites',
    thumbnail: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
    images: [
      'https://images.unsplash.com/photo-1551288049-bebda4e38f71?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80'
    ],
    description: 'Comprehensive e-commerce dashboard kit with over 40 screens and 200 components.'
  }
];
