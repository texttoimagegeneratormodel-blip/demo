
export interface Template {
  id: string;
  title: string;
  creator: Creator;
  price: number;
  rating: number;
  sales: number;
  thumbnail: string;
  images: string[];
  description: string;
  category: string;
  reviews?: Review[];
}

export interface Review {
  id: string;
  user: string;
  avatar: string;
  rating: number;
  date: string;
  content: string;
}

export interface Creator {
  id: string;
  name: string;
  role: string;
  avatar: string;
  followers: string;
  templatesCount: number;
  likes: string;
  bio: string;
}

export interface CartItem {
  id: string; 
  template: Template;
}

export interface User {
  name: string;
  email: string;
  avatar: string;
  bio?: string;
  socialLinks?: {
    website?: string;
    instagram?: string;
    dribbble?: string;
  };
}

export interface PaymentMethod {
  id: string;
  type: string;
  title: string;
  subtitle?: string;
  isDefault: boolean;
  iconType: 'image' | 'icon';
  iconValue: string;
}
