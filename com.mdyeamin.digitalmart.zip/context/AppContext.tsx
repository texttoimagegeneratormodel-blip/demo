
import React, { createContext, useContext, useState, useEffect } from 'react';
import { User, Template, CartItem, Creator, PaymentMethod, Review } from '../types';
import { TEMPLATES, CREATORS } from '../data/mockData';

interface Toast {
  id: string;
  message: string;
  type: 'success' | 'error' | 'info';
}

interface AppContextType {
  user: User | null;
  login: (email: string) => void;
  logout: () => void;
  updateUser: (updatedData: Partial<User>) => void;
  
  templates: Template[];
  addReview: (templateId: string, review: Review) => void;
  creators: Creator[];
  
  cart: CartItem[];
  addToCart: (template: Template) => void;
  removeFromCart: (itemId: string) => void;
  clearCart: () => void;
  cartTotal: number;
  
  wishlist: string[];
  toggleWishlist: (templateId: string) => void;
  isInWishlist: (templateId: string) => boolean;

  following: string[];
  toggleFollow: (creatorId: string) => void;
  isFollowing: (creatorId: string) => boolean;

  paymentMethods: PaymentMethod[];
  addPaymentMethod: (method: PaymentMethod) => void;
  removePaymentMethod: (id: string) => void;

  toasts: Toast[];
  showToast: (message: string, type?: 'success' | 'error' | 'info') => void;
  removeToast: (id: string) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Initialize state from LocalStorage if available
  const [user, setUser] = useState<User | null>(() => {
    const saved = localStorage.getItem('dm_user');
    return saved ? JSON.parse(saved) : null;
  });

  // Make templates stateful to allow updates (like adding reviews)
  const [templates, setTemplates] = useState<Template[]>(() => {
    const saved = localStorage.getItem('dm_templates');
    return saved ? JSON.parse(saved) : TEMPLATES;
  });

  const [cart, setCart] = useState<CartItem[]>(() => {
    const saved = localStorage.getItem('dm_cart');
    return saved ? JSON.parse(saved) : [];
  });

  const [wishlist, setWishlist] = useState<string[]>(() => {
    const saved = localStorage.getItem('dm_wishlist');
    return saved ? JSON.parse(saved) : [];
  });

  const [following, setFollowing] = useState<string[]>(() => {
    const saved = localStorage.getItem('dm_following');
    return saved ? JSON.parse(saved) : [];
  });

  const [paymentMethods, setPaymentMethods] = useState<PaymentMethod[]>(() => {
    const saved = localStorage.getItem('dm_payment_methods');
    if (saved) return JSON.parse(saved);
    return [
      {
        id: '1',
        type: 'Card',
        title: 'Visa •••• 4242',
        subtitle: 'Expires 12/25',
        isDefault: true,
        iconType: 'image',
        iconValue: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAl-9zV61GmOyECwRElXv-nneuZvE8PINHzsiGf5VTrKKGmmE2t9BSVhYhkwG4ixEyUgEkHcWZMa9MY-Q9aLOz8d2D1_gqLdwRLOL7AT_EVCAsW4uufTMLFUEbn9QA_GDz6GmvE67ilC9j5LaqrhYhz0dBLGq3_xs3meUk8ytJ6ofKOVGLqyuUKb8RjyLIcUnID2n-1Z3N3Q5MFDmy27Ij1Q4QOIyQb6oBfY7GOhcuHzcQC7HDPvpzEojgyt-Hmaaiggej1k-3z4lDq'
      }
    ];
  });

  const [toasts, setToasts] = useState<Toast[]>([]);

  // Persistence Effects
  useEffect(() => {
    localStorage.setItem('dm_user', JSON.stringify(user));
  }, [user]);

  useEffect(() => {
    localStorage.setItem('dm_templates', JSON.stringify(templates));
  }, [templates]);

  useEffect(() => {
    localStorage.setItem('dm_cart', JSON.stringify(cart));
  }, [cart]);

  useEffect(() => {
    localStorage.setItem('dm_wishlist', JSON.stringify(wishlist));
  }, [wishlist]);

  useEffect(() => {
    localStorage.setItem('dm_following', JSON.stringify(following));
  }, [following]);

  useEffect(() => {
    localStorage.setItem('dm_payment_methods', JSON.stringify(paymentMethods));
  }, [paymentMethods]);


  // Actions
  const showToast = (message: string, type: 'success' | 'error' | 'info' = 'success') => {
    const id = Math.random().toString(36).substr(2, 9);
    setToasts((prev) => [...prev, { id, message, type }]);
    setTimeout(() => removeToast(id), 3000);
  };

  const removeToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  const login = (email: string) => {
    setUser({
      name: 'David Design',
      email: email,
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?ixlib=rb-1.2.1&auto=format&fit=crop&w=200&q=80',
      bio: 'Digital product designer and creative developer.',
      socialLinks: {
        website: 'www.daviddesign.com',
        instagram: '@david_design',
        dribbble: '@david_shots'
      }
    });
    showToast(`Welcome back!`);
  };

  const logout = () => {
    setUser(null);
    setCart([]);
    setWishlist([]);
    setFollowing([]);
    setPaymentMethods([]);
    setTemplates(TEMPLATES); // Reset templates to default on logout if desired, or keep edits
    localStorage.removeItem('dm_user');
    localStorage.removeItem('dm_cart');
    localStorage.removeItem('dm_wishlist');
    localStorage.removeItem('dm_following');
    localStorage.removeItem('dm_payment_methods');
    localStorage.removeItem('dm_templates');
    showToast('Logged out successfully', 'info');
  };

  const updateUser = (updatedData: Partial<User>) => {
    if (user) {
      setUser({ ...user, ...updatedData });
      showToast('Profile updated successfully');
    }
  };

  const addReview = (templateId: string, review: Review) => {
    setTemplates(prevTemplates => prevTemplates.map(t => {
      if (t.id === templateId) {
        const currentReviews = t.reviews || [];
        const newReviews = [review, ...currentReviews];
        
        // Recalculate average rating
        const totalRating = newReviews.reduce((acc, r) => acc + r.rating, 0);
        const newAverage = parseFloat((totalRating / newReviews.length).toFixed(1));

        return {
          ...t,
          reviews: newReviews,
          rating: newAverage
        };
      }
      return t;
    }));
    showToast('Review submitted successfully!');
  };

  const addToCart = (template: Template) => {
    if (cart.some(item => item.template.id === template.id)) {
      showToast('Item already in cart', 'info');
      return;
    }
    const newItem: CartItem = {
      id: Math.random().toString(36).substr(2, 9),
      template
    };
    setCart([...cart, newItem]);
    showToast('Added to cart');
  };

  const removeFromCart = (itemId: string) => {
    setCart(cart.filter(item => item.id !== itemId));
    showToast('Item removed from cart', 'info');
  };

  const clearCart = () => {
    setCart([]);
  };

  const cartTotal = cart.reduce((total, item) => total + item.template.price, 0);

  const toggleWishlist = (templateId: string) => {
    if (wishlist.includes(templateId)) {
      setWishlist(wishlist.filter(id => id !== templateId));
      showToast('Removed from wishlist', 'info');
    } else {
      setWishlist([...wishlist, templateId]);
      showToast('Added to wishlist');
    }
  };

  const isInWishlist = (templateId: string) => wishlist.includes(templateId);

  const toggleFollow = (creatorId: string) => {
    if (following.includes(creatorId)) {
      setFollowing(following.filter(id => id !== creatorId));
      showToast('Unfollowed creator', 'info');
    } else {
      setFollowing([...following, creatorId]);
      showToast('Following creator');
    }
  }

  const isFollowing = (creatorId: string) => following.includes(creatorId);

  const addPaymentMethod = (method: PaymentMethod) => {
    if (method.isDefault) {
      // Unset other defaults
      const updated = paymentMethods.map(p => ({ ...p, isDefault: false }));
      setPaymentMethods([...updated, method]);
    } else {
      setPaymentMethods([...paymentMethods, method]);
    }
  };

  const removePaymentMethod = (id: string) => {
    setPaymentMethods(paymentMethods.filter(p => p.id !== id));
    showToast('Payment method removed');
  };

  return (
    <AppContext.Provider value={{
      user,
      login,
      logout,
      updateUser,
      templates,
      addReview,
      creators: CREATORS,
      cart,
      addToCart,
      removeFromCart,
      clearCart,
      cartTotal,
      wishlist,
      toggleWishlist,
      isInWishlist,
      following,
      toggleFollow,
      isFollowing,
      paymentMethods,
      addPaymentMethod,
      removePaymentMethod,
      toasts,
      showToast,
      removeToast
    }}>
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
