
import React from 'react';
import { HashRouter, Routes, Route, useLocation, useNavigate } from 'react-router-dom';
import OnboardingScreen from './screens/OnboardingScreen';
import LoginScreen from './screens/LoginScreen';
import RegisterScreen from './screens/RegisterScreen';
import HomeScreen from './screens/HomeScreen';
import DetailsScreen from './screens/DetailsScreen';
import CreatorProfileScreen from './screens/CreatorProfileScreen';
import CartScreen from './screens/CartScreen';
import TemplateUploadScreen from './screens/TemplateUploadScreen';
import DashboardScreen from './screens/DashboardScreen';
import MessagesScreen from './screens/MessagesScreen';
import ChatDetailsScreen from './screens/ChatDetailsScreen';
import NotificationSettingsScreen from './screens/NotificationSettingsScreen';
import PaymentMethodsScreen from './screens/PaymentMethodsScreen';
import AddPaymentMethodScreen from './screens/AddPaymentMethodScreen';
import HelpSupportScreen from './screens/HelpSupportScreen';
import FAQScreen from './screens/FAQScreen';
import ContactUsScreen from './screens/ContactUsScreen';
import TermsPrivacyScreen from './screens/TermsPrivacyScreen';
import SettingsScreen from './screens/SettingsScreen';
import AccountSecurityScreen from './screens/AccountSecurityScreen';
import TwoFactorSetupScreen from './screens/TwoFactorSetupScreen';
import ChangePasswordScreen from './screens/ChangePasswordScreen';
import ManageSessionsScreen from './screens/ManageSessionsScreen';
import WishlistScreen from './screens/WishlistScreen';
import UserProfileScreen from './screens/UserProfileScreen';
import ProfileInfoScreen from './screens/ProfileInfoScreen';
import AboutScreen from './screens/AboutScreen';
import ExploreScreen from './screens/ExploreScreen';
import TrendingScreen from './screens/TrendingScreen';
import BuySourceCodeScreen from './screens/BuySourceCodeScreen';
import BottomNav from './components/BottomNav';
import { AppProvider, useApp } from './context/AppContext';

// Toast Component
const ToastContainer = () => {
  const { toasts, removeToast } = useApp();

  return (
    <div className="fixed bottom-32 left-0 right-0 z-[100] flex flex-col items-center gap-2 pointer-events-none px-4">
      {toasts.map((toast) => (
        <div 
          key={toast.id}
          onClick={() => removeToast(toast.id)}
          className={`pointer-events-auto flex items-center gap-3 px-4 py-3 rounded-xl shadow-xl backdrop-blur-md transform transition-all animate-fade-in cursor-pointer min-w-[300px] max-w-sm ${
            toast.type === 'error' ? 'bg-red-500/90 text-white' : 
            toast.type === 'info' ? 'bg-slate-800/90 text-white' : 
            'bg-green-600/90 text-white'
          }`}
        >
          <span className="material-symbols-outlined text-[20px]">
            {toast.type === 'error' ? 'error' : toast.type === 'info' ? 'info' : 'check_circle'}
          </span>
          <p className="text-sm font-medium flex-1">{toast.message}</p>
        </div>
      ))}
    </div>
  );
};

// Global Sales Banner
const SourceCodeBanner = () => {
  const navigate = useNavigate();
  const location = useLocation();
  
  if (location.pathname === '/buy-code') return null;

  return (
    <div className="fixed bottom-20 left-0 right-0 z-40 px-4 pb-2 pointer-events-none">
      <button 
        onClick={() => navigate('/buy-code')}
        className="pointer-events-auto w-full bg-gradient-to-r from-slate-900 to-slate-800 dark:from-slate-800 dark:to-slate-900 text-white shadow-xl shadow-black/20 rounded-full py-2.5 px-4 flex items-center justify-between border border-slate-700/50 backdrop-blur-md group"
      >
        <div className="flex items-center gap-2">
          <span className="flex items-center justify-center size-6 bg-primary rounded-full text-xs animate-pulse">🚀</span>
          <span className="text-xs font-bold">Get Source Code</span>
        </div>
        <div className="flex items-center gap-1">
          <span className="text-xs font-bold text-primary">$399</span>
          <span className="material-symbols-outlined text-sm group-hover:translate-x-1 transition-transform">arrow_forward</span>
        </div>
      </button>
    </div>
  );
}

const Layout = ({ children }: { children?: React.ReactNode }) => {
  const location = useLocation();

  // Specific check to hide bottom nav on detail, auth, and specific action screens
  const isDetailOrCartOrAuthOrUpload = 
    location.pathname === '/' || 
    location.pathname === '/login' || 
    location.pathname === '/register' ||
    location.pathname.startsWith('/details') || 
    location.pathname.startsWith('/cart') ||
    location.pathname === '/upload' ||
    location.pathname === '/dashboard' ||
    location.pathname === '/messages' ||
    location.pathname.startsWith('/messages/') ||
    location.pathname === '/notifications' ||
    location.pathname === '/payment-methods' ||
    location.pathname === '/add-payment-method' ||
    location.pathname === '/help-support' ||
    location.pathname === '/faq' ||
    location.pathname === '/contact-us' ||
    location.pathname === '/terms-privacy' ||
    location.pathname === '/settings' ||
    location.pathname === '/account-security' ||
    location.pathname === '/two-factor-setup' ||
    location.pathname === '/change-password' ||
    location.pathname === '/manage-sessions' ||
    location.pathname === '/trending' ||
    location.pathname === '/profile-info' ||
    location.pathname === '/about' ||
    location.pathname === '/buy-code';

  return (
    <div className="relative flex h-full min-h-screen w-full flex-col max-w-lg mx-auto bg-background-light dark:bg-background-dark shadow-2xl overflow-hidden">
      <div className="flex-1 overflow-y-auto no-scrollbar">
        {children}
      </div>
      <ToastContainer />
      {!isDetailOrCartOrAuthOrUpload && (
        <>
          <SourceCodeBanner />
          <BottomNav />
        </>
      )}
    </div>
  );
};

const App: React.FC = () => {
  return (
    <HashRouter>
      <AppProvider>
        <Layout>
          <Routes>
            <Route path="/" element={<OnboardingScreen />} />
            <Route path="/login" element={<LoginScreen />} />
            <Route path="/register" element={<RegisterScreen />} />
            <Route path="/home" element={<HomeScreen />} />
            <Route path="/explore" element={<ExploreScreen />} />
            <Route path="/trending" element={<TrendingScreen />} />
            <Route path="/details/:id" element={<DetailsScreen />} />
            <Route path="/creator/:id" element={<CreatorProfileScreen />} />
            <Route path="/cart" element={<CartScreen />} />
            <Route path="/upload" element={<TemplateUploadScreen />} />
            <Route path="/dashboard" element={<DashboardScreen />} />
            <Route path="/messages" element={<MessagesScreen />} />
            <Route path="/messages/:id" element={<ChatDetailsScreen />} />
            <Route path="/notifications" element={<NotificationSettingsScreen />} />
            <Route path="/payment-methods" element={<PaymentMethodsScreen />} />
            <Route path="/add-payment-method" element={<AddPaymentMethodScreen />} />
            <Route path="/help-support" element={<HelpSupportScreen />} />
            <Route path="/faq" element={<FAQScreen />} />
            <Route path="/contact-us" element={<ContactUsScreen />} />
            <Route path="/terms-privacy" element={<TermsPrivacyScreen />} />
            <Route path="/settings" element={<SettingsScreen />} />
            <Route path="/account-security" element={<AccountSecurityScreen />} />
            <Route path="/two-factor-setup" element={<TwoFactorSetupScreen />} />
            <Route path="/change-password" element={<ChangePasswordScreen />} />
            <Route path="/manage-sessions" element={<ManageSessionsScreen />} />
            <Route path="/wishlist" element={<WishlistScreen />} />
            <Route path="/profile" element={<UserProfileScreen />} />
            <Route path="/profile-info" element={<ProfileInfoScreen />} />
            <Route path="/about" element={<AboutScreen />} />
            <Route path="/buy-code" element={<BuySourceCodeScreen />} />
          </Routes>
        </Layout>
      </AppProvider>
    </HashRouter>
  );
};

export default App;
