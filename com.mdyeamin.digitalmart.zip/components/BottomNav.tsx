
import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';

const BottomNav: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();

  const isActive = (path: string) => location.pathname === path;

  return (
    <nav className="sticky bottom-0 left-0 right-0 h-20 bg-background-light/90 dark:bg-background-dark/90 backdrop-blur-md border-t border-slate-200 dark:border-slate-800 z-50">
      <div className="flex justify-around items-center h-full px-2">
        <button 
          onClick={() => navigate('/home')}
          className={`flex flex-col items-center justify-center gap-1 w-16 ${isActive('/home') ? 'text-primary' : 'text-slate-500 dark:text-slate-400'}`}
        >
          <span className={`material-symbols-outlined ${isActive('/home') ? 'filled' : ''}`}>home</span>
          <span className="text-[10px] font-bold">Home</span>
        </button>
        <button 
          onClick={() => navigate('/explore')} 
          className={`flex flex-col items-center justify-center gap-1 w-16 ${isActive('/explore') ? 'text-primary' : 'text-slate-500 dark:text-slate-400'}`}
        >
          <span className={`material-symbols-outlined ${isActive('/explore') ? 'filled' : ''}`}>search</span>
          <span className="text-[10px] font-medium">Explore</span>
        </button>
        <button 
          onClick={() => navigate('/dashboard')} 
          className={`flex flex-col items-center justify-center gap-1 w-16 ${isActive('/dashboard') ? 'text-primary' : 'text-slate-500 dark:text-slate-400'}`}
        >
          <span className={`material-symbols-outlined ${isActive('/dashboard') ? 'filled' : ''}`}>add_circle</span>
          <span className="text-[10px] font-medium">Sell</span>
        </button>
        <button 
           onClick={() => navigate('/wishlist')} 
           className={`flex flex-col items-center justify-center gap-1 w-16 ${isActive('/wishlist') ? 'text-primary' : 'text-slate-500 dark:text-slate-400'}`}
        >
          <span className={`material-symbols-outlined ${isActive('/wishlist') ? 'filled' : ''}`}>favorite</span>
          <span className="text-[10px] font-medium">Wishlist</span>
        </button>
        <button 
          onClick={() => navigate('/profile')} 
          className={`flex flex-col items-center justify-center gap-1 w-16 ${isActive('/profile') ? 'text-primary' : 'text-slate-500 dark:text-slate-400'}`}
        >
          <span className={`material-symbols-outlined ${isActive('/profile') ? 'filled' : ''}`}>person</span>
          <span className="text-[10px] font-medium">Account</span>
        </button>
      </div>
    </nav>
  );
};

export default BottomNav;
